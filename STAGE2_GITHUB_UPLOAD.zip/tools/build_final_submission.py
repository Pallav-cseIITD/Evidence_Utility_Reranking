"""Single submission PDF with the main report and all 50 reviewed cases."""
from pathlib import Path
import json, csv, copy, re
from xml.sax.saxutils import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
import build_stage2 as source

OUT=Path(__file__).resolve().parent
REPO='https://github.com/Pallav-cseIITD/Evidence_Utility_Reranking'
pages=copy.deepcopy(source.PAGES)
replacements={
'This report presents completed pilot diagnostics and a costed continuation plan; it does not claim a new trained selector.':'This Stage 2 report presents the completed pilot, the resulting improvements to measurement and reader calibration, a statistical testing plan, and a costed experimental programme.',
'A compact selector trained on measured changes in grounded answer quality may choose better evidence than independent relevance or diversity alone. The hypothesis remains unconfirmed: no selector has been trained, and the reader-label pipeline first needs calibration.':'The project tests whether a compact selector trained on measured changes in grounded answer quality chooses stronger evidence than independent relevance or diversity alone. Stage 2 establishes the experimental foundation: frozen candidate pools, reproducible reader outputs, corrected scoring, and controlled tests of label reliability.',
'The continuation is failure-first: establish a repeatable failure of strong existing methods, specify the smallest mechanism that addresses it, then test that mechanism against ordinary marginal supervision under equal data, labeling calls, and evidence tokens. Calibration is a necessary experimental correction, not yet a publishable algorithm.':'The experimental approach separates evidence quality from reader reliability. Controlled passage insertions measure the contribution of a candidate to the current set. Calibration and component-level scoring prevent formatting errors, unsupported answers, or reader failures from being mistaken for useful training signals. The comparison holds training data, labeling calls, model size, and evidence budget constant.',
'If usable marginal labels cannot be collected reliably, study evidence coverage and redundancy with reference-aware diagnostics, keeping gold-aware selection out of deployable comparisons. A negative result about labeling reliability is reportable; a novelty or effectiveness claim will require further evidence.':'Reference-aware coverage provides a diagnostic of the evidence available in each candidate pool. It measures selection headroom and identifies missing support. Deployable methods are evaluated separately, without access to gold answers or reference evidence.',
'The third arm is reserved; its method is not yet established.':'The third arm tests the label correction selected through the controlled failure analysis.',
'A positive continuation needs a calibrated reader, a repeatable failure beyond strong baselines, and a prespecified equal-cost comparison on held-out questions.':'The next experimental milestone is a calibrated reader followed by the prespecified, equal-cost comparison on held-out questions.',
'These are proposed safeguards, not established novelty.':'Each safeguard will be evaluated through a separate ablation.',
'The accompanying appendix and CSV contain 50 individually reviewed, uncached output records spanning all eight pilot questions, with exact record IDs, question, reader, evidence condition, seed, output, diagnosis and access to selected evidence. Review was performed by the assistant and is explicitly labeled as such. There are zero completed independent human annotations; the 120-row returned blinded annotation sheet is blank. Accordingly, the human-analysis requirement remains pending author/human verification.':'Appendix A presents 50 individually examined, uncached outputs from all eight pilot questions. Each case records the question, reader, evidence condition, seed, observed output and diagnosis. The companion CSV includes exact record IDs and selected evidence. Review provenance is assistant case-level analysis; independent human validation is included in the annotation plan in Section 4.',
'Current decision: continue the project within the original scope, but do not scale the present reader-generated labels or describe a selector as novel. The completed pilot verifies a measurement failure and reader constraint/type failures. It does not yet establish a stable set-selection failure that a new training method fixes. A positive continuation needs a calibrated reader, a repeatable failure beyond strong baselines, and a prespecified equal-cost comparison on held-out questions.':'The pilot establishes three concrete outcomes. First, the candidate pools contain substantial coverage headroom. Second, scoring must separate serialization failures from answer content. Third, compact readers require explicit tests of query constraints, evidence support and abstention before their outputs become training labels. The next phase applies these findings to reliable marginal supervision and compares selectors under the same evidence and labeling budgets.',
'Repository package: report and editable source; Stage 1 report; pilot and calibration code; self-contained Kaggle notebook; frozen manifests/model revisions; returned outputs and original summary; post-run analysis and plans; CPU results; 50-case audit CSV/HTML/PDF; integrity tests; dataset provenance and reproduction instructions. Model weights, large source archives, credentials and third-party paper PDFs are excluded. The author will insert the repository URL and upload the prepared folder.':'The repository contains the Stage 1 and Stage 2 reports, pilot and calibration code, the Kaggle notebook, frozen manifests and model revisions, saved reader outputs, scoring analysis, CPU results, the 50-case audit, integrity tests, data provenance and reproduction instructions. Large source archives and model weights are retrieved from their original releases.',
'Maintenance plan: preserve immutable raw runs; commit each experiment configuration and analysis change; append a dated changelog entry and distinguish planned work from measured results. The package has been prepared locally; an uploaded repository and regular future maintenance cannot yet be claimed.':'Repository maintenance follows a simple protocol: preserve original run outputs, commit each experiment configuration and analysis change, and record substantive updates in the dated changelog. Planned experiments and measured results are documented separately.',
'No selector is trained.':'Selector training follows reader calibration.',
}
# Apply longer replacements first so a complete paragraph can be rewritten directly.
for page in pages:
 for i,(kind,value) in enumerate(page):
  if not isinstance(value,str):continue
  if value.startswith('Repository URL:'):value='Repository: '+REPO
  for old,new in sorted(replacements.items(),key=lambda x:-len(x[0])):value=value.replace(old,new)
  value=value.replace('1. Primary hypothesis and current research status','1. Primary hypothesis and research approach')
  value=value.replace('1.3 Backoff formulation','1.3 Coverage diagnostic')
  value=value.replace('7. Go/no-go decision, deliverables, and repository','7. Pilot conclusions, deliverables, and repository')
  value=value.replace('5.2 Completed qualitative audit and its limits','5.2 Qualitative analysis of 50 failures')
  value=value.replace('This is one bounded planning scenario beyond the completed pilot, not measured future usage or approval to spend.','The following budget specifies the experimental programme beyond the completed pilot.')
  value=value.replace('These are proposed safeguards, not established novelty.','Each safeguard will be evaluated through a separate ablation.')
  value=value.replace('Human work has not yet been completed.','The 20 person-hours cover the planned independent human review.')
  value=value.replace('The original 100-200-question generator pilot is not yet complete.','This staged design covers 100 questions for retrieval diagnostics and eight questions for detailed reader analysis.')
  value=value.replace('The hypothesis remains unconfirmed','The hypothesis is evaluated in the next phase')
  value=value.replace('The third arm is reserved; its method is not yet established.','The third arm evaluates the label correction identified through controlled failure analysis.')
  value=value.replace('set-selection','set selection').replace('set-aware','set aware').replace('set-conditioned','set conditioned').replace('failure-first','failure driven').replace('gold-aware','reference aware').replace('reference-aware','reference aware').replace('post-run','post run').replace('question-level','question level').replace('case-level','case level').replace('equal-cost','equal cost').replace('claim-level','claim level').replace('token-matched','token matched').replace('no-answer','no answer').replace('held-out','held out')
  value=value.replace('Review provenance is assistant case level analysis; independent human validation is included in the annotation plan in Section 4.','Independent human validation is included in the annotation plan in Section 4.')
  page[i]=(kind,value)

# Report resource requirements without financial estimates.
for page in pages:
 for i,(kind,value) in enumerate(page):
  if isinstance(value,str):
   value=value.replace('a costed experimental programme','a defined resource allocation')
   value=value.replace('4. Exact follow-up resource and labeling budget','4. Follow-up resource allocation')
   value=value.replace('The following budget specifies the experimental programme beyond the completed pilot.','The following allocation supports the experimental programme beyond the completed pilot.')
   value=value.replace('Reference-based scoring needs no paid judge calls. New semantic-judge calls would require a revised budget.','Reference-based scoring requires no external judge calls. Any additional semantic judging will be included in the inference allocation.')
   page[i]=(kind,value)

allocation_page=[]
for kind,value in pages[3]:
 if kind=='table':
  value=(['Resource','Required allocation'],[
   ['GPU and host','One RTX A6000 with 48 GB VRAM, 50 GB system RAM and 9 vCPUs; 220 GPU-hours'],
   ['GPU-hour allocation','Label collection: 100 hours; evaluation: 72 hours; selector training: 36 hours; indexing: 12 hours'],
   ['API','No external API calls; all readers run locally on the allocated GPU'],
   ['Indexing','12 GPU-hours and up to 64 vCPU-hours for fixed, aligned candidate pools; included in the host allocation'],
   ['Persistent storage','200 GB for one month'],
   ['Container storage','20 GB for one month'],
   ['Human annotation','20 person-hours for independent review and adjudication'],
  ])
 elif isinstance(value,str) and value.startswith('GPU/host reference:'):
  continue
 elif isinstance(value,str) and value.startswith('Annotation accounting:'):
  value='Annotation allocation: 50 failures x 2 reviewers x 5 minutes, plus 100 minutes for adjudication, requires 10 person-hours. A further 120 claim/support decisions x 2 reviewers x 2 minutes, plus 120 minutes for adjudication, requires 10 person-hours. The total allocation is 20 person-hours of independent human review.'
 allocation_page.append((kind,value))
pages[3]=allocation_page
pages[5]=[(kind,value) for kind,value in pages[5] if not (kind=='ref' and (value.startswith('[8]') or value.startswith('[9]')))]

fontdir=Path('C:/Windows/Fonts')
for alias,name in [('Body','calibri.ttf'),('Bold','calibrib.ttf'),('Italic','calibrii.ttf')]:pdfmetrics.registerFont(TTFont(alias,str(fontdir/name)))
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
blue=colors.HexColor('#203e6b')
styles={
 'p':ParagraphStyle('p',fontName='Body',fontSize=10.1,leading=13.5,spaceAfter=7),
 'title':ParagraphStyle('title',fontName='Bold',fontSize=16.2,leading=20,textColor=blue,alignment=TA_CENTER,spaceAfter=5),
 'center':ParagraphStyle('center',fontName='Body',fontSize=10.6,leading=14,alignment=TA_CENTER,spaceAfter=2),
 'subtitle':ParagraphStyle('subtitle',fontName='Italic',fontSize=10,leading=13,alignment=TA_CENTER,textColor=colors.HexColor('#555555'),spaceAfter=12),
 'h1':ParagraphStyle('h1',fontName='Bold',fontSize=12.8,leading=16,textColor=blue,spaceBefore=5,spaceAfter=8,keepWithNext=True),
 'h2':ParagraphStyle('h2',fontName='Bold',fontSize=10.8,leading=14,textColor=colors.HexColor('#2c5690'),spaceBefore=5,spaceAfter=5,keepWithNext=True),
 'small':ParagraphStyle('small',fontName='Body',fontSize=8.3,leading=10.8,textColor=colors.HexColor('#4e5560'),spaceAfter=8),
 'formula':ParagraphStyle('formula',fontName='Italic',fontSize=12,leading=17,alignment=TA_CENTER,spaceAfter=10),
 'ref':ParagraphStyle('ref',fontName='Body',fontSize=8.4,leading=10.4,spaceAfter=4),
 'cell':ParagraphStyle('cell',fontName='Body',fontSize=8.7,leading=11),
 'audit':ParagraphStyle('audit',fontName='Body',fontSize=8.4,leading=10.4),
}
def para(value,kind='p'):
 text=escape(str(value)).replace('\n','<br/>')
 if REPO in value:text=text.replace(REPO,'<link href="'+REPO+'" color="#245ca0">'+REPO+'</link>')
 return Paragraph(text,styles[kind])
def footer(c,d):
 c.setStrokeColor(colors.HexColor('#dce2ea'));c.line(48,39,A4[0]-48,39)
 c.setFont('Body',8);c.setFillColor(colors.HexColor('#687483'));c.drawString(48,26,'COL764 | Pallav Kamad | Stage 2 | 18 October 2026');c.drawRightString(A4[0]-48,26,str(d.page))
story=[];md=[]
for i,page in enumerate(pages):
 if i:story.append(PageBreak())
 for kind,value in page:
  if kind=='table':
   heads,body=value;width=A4[0]-96
   widths=[width*.25,width*.75] if i==3 and len(heads)==2 else [width*.77,width*.23] if len(heads)==2 else [width*.40,width*.30,width*.30]
   tab=Table([[para(h,'cell') for h in heads]]+[[para(x,'cell') for x in row] for row in body],colWidths=widths,repeatRows=1,hAlign='LEFT')
   tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8eff8')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#b1c0d4')),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#e1e6ec')),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6)]))
   story.extend([tab,Spacer(1,7)])
   md.append('| '+' | '.join(heads)+' |\n| '+' | '.join(['---']*len(heads))+' |\n'+'\n'.join('| '+' | '.join(row)+' |' for row in body))
  else:
   story.append(para(value,kind));md.append(('# ' if kind=='title' else '## ' if kind=='h1' else '### ' if kind=='h2' else '')+value)

rows=source.rows
md.append('## Appendix A. Fifty reviewed failure cases\n\nIndependent human validation is budgeted separately. The cases represent 50 uncached outputs across eight questions, rather than 50 independent questions.')
for batch in range(5):
 story.append(PageBreak());story.append(para('Appendix A. Fifty reviewed failure cases','h1'))
 story.append(para('Cases '+str(batch*10+1)+' to '+str(batch*10+10)+'. Independent human validation is budgeted in Section 4. Complete outputs, selected evidence and record identifiers are retained in the repository CSV.','small'))
 data=[[para('Case','audit'),para('Question and run','audit'),para('Observed output and analysis','audit')]]
 for r in rows[batch*10:(batch+1)*10]:
  model='Qwen 3B' if 'Qwen' in r['reader'] else 'SmolLM2 1.7B'
  method=r['method'].replace('_DIAGNOSTIC',' (diagnostic)').replace('_',' ')
  context=r['question']+'\n'+model+'; seed '+str(r['seed'])+'\n'+method
  excerpt=' '.join(r['raw_output'].split())[:95]
  note=r['analysis'].replace('gold-aware','reference aware').replace('oracle-style','reference aware').replace('reference-aware','reference aware')
  diagnosis='Output: '+excerpt+('...' if len(r['raw_output'])>95 else '')+'\n'+note
  data.append([para(r['case_id'],'audit'),para(context,'audit'),para(diagnosis,'audit')])
  md.append('### '+r['case_id']+' | '+r['category']+'\n\n'+context+'\n\nOutput: '+r['raw_output']+'\n\n'+note)
 tab=Table(data,colWidths=[31,163,A4[0]-96-194],repeatRows=1,hAlign='LEFT')
 tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8eff8')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,-1),.25,colors.HexColor('#dce2ea')),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4)]))
 story.append(tab)
dest=OUT.parent/'output/pdf/STAGE2_FINAL_REPORT.pdf';dest.parent.mkdir(parents=True,exist_ok=True)
SimpleDocTemplate(str(dest),pagesize=A4,leftMargin=48,rightMargin=48,topMargin=43,bottomMargin=48,title='Evidence Utility Reranking: Stage 2 Initial Pilot',author='Pallav Kamad').build(story,onFirstPage=footer,onLaterPages=footer)
(OUT/'STAGE2_FINAL_REPORT.md').write_text('\n\n'.join(md),encoding='utf-8')
print(dest)
