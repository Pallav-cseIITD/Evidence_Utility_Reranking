"""Assemble a small, reproducible GitHub upload folder without credentials or weights."""
from pathlib import Path
import hashlib,json,shutil,zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'stage2_delivery'
BUNDLE=OUT/'STAGE2_GITHUB_UPLOAD'
BUNDLE.mkdir(exist_ok=True)

def copy(source,target):
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(source,target)

for p in (ROOT/'experiments').rglob('*'):
    if not p.is_file():continue
    rel=p.relative_to(ROOT)
    if '__pycache__' in rel.parts or p.suffix in ['.zip','.pyc','.png']:continue
    if 'failure_pilot/data/raw' in rel.as_posix() and p.name!='manifest.json':continue
    if p.stat().st_size>24_000_000:continue
    copy(p,BUNDLE/rel)
for p in ROOT.glob('*.md'):
    copy(p,BUNDLE/'reports/project_context'/p.name)
copy(ROOT/'stage1_proposal.pdf',BUNDLE/'reports/stage1_proposal.pdf')
for name in ['STAGE2_REPORT.pdf','STAGE2_REPORT.md','FAILURE_AUDIT_50.pdf','failure_audit_50.csv','failure_audit_50.html','failure_audit_summary.json']:
    copy(OUT/name,BUNDLE/'reports/stage2'/name)
for name in ['build_stage2.py','package_repository.py']:
    copy(OUT/name,BUNDLE/'tools'/name)
(BUNDLE/'README.md').write_text('''# Evidence Utility Reranking for Grounded Generation

Pallav Kamad | 2023CS51067 | COL764

**Repository URL:** add the actual GitHub URL here and in the Stage 2 report before submission.

## Stage 2 deliverables

- [Six-page initial pilot report](reports/stage2/STAGE2_REPORT.pdf), with [editable Markdown](reports/stage2/STAGE2_REPORT.md).
- [50-case qualitative audit](reports/stage2/FAILURE_AUDIT_50.pdf), [full evidence browser](reports/stage2/failure_audit_50.html), and [verification CSV](reports/stage2/failure_audit_50.csv).
- [Original Stage 1 proposal](reports/stage1_proposal.pdf).
- [Self-contained Kaggle notebook](experiments/failure_pilot/Evidence_Utility_Kaggle_Start.ipynb).

## What has actually run

100-question CPU coverage preflight; 8-question GPU smoke test with two compact readers, two generation seeds, 12 conditions; 384 logical records and 348 generated outputs. A separate 88-call controlled calibration is complete. Neither reader passes its calibration gate. No selector is trained. Post-run format sensitivity is disclosed and original strict scores are retained.

The 50-case audit is **assistant case-level review**, not independent human annotation or 50 independent questions. Human verification fields remain blank. The returned 120-row human-audit sheet is also unfilled. The author must verify/correct the cases; do not represent this package as completed human annotation.

## Reproduce saved-output checks locally

Python 3.10+ is sufficient for the standard-library diagnostics and analysis tests; GPU dependencies are needed only for inference. From the repository root:

```sh
cd experiments/failure_pilot
python -m unittest test_integrity test_returned_analysis -v
python analyze_returned_run.py --run-root runs/ir_run1_20261018
python local_diagnostic.py
```

The frozen 200-question pools, source manifests, exact model revisions, raw output records and original/post-run summaries are included. The local diagnostic reads these fixed pools. `prepare_data.py` recreates source downloads if needed; it does not silently substitute another sample. Review its source URLs and manifests before downloading. Large upstream raw retrieval archives are deliberately excluded.

## Run the GPU pilot

Upload `experiments/failure_pilot/Evidence_Utility_Kaggle_Start.ipynb` to a GPU notebook and follow its instructions. Its source and frozen eight-question payload are embedded. Read `KAGGLE_START_HERE.md` first. Model versions are pinned in `sources/model_revisions.json`; observed package versions are recorded in the returned run's `raw/environment.json`. The original run used transformers 4.51.3, accelerate 1.6.0, torch 2.11.0+cu128 and NumPy 2.1.3. Install the CUDA-compatible PyTorch build for the actual host rather than assuming this exact wheel works everywhere.

`calibration_v2.py` reproduces the additional controls; its original outputs are under `runs/ir_run1_20261018/calibration_v2/raw/`. GPU reproduction can consume substantial free quota. No paid API key is required.

## Data and scoring limits

Official QAMPARI release: https://github.com/samsam3232/qampari . Upstream data, retrieval snippets, model checkpoints and third-party metadata remain subject to their original terms; this repository does not relicense them. Included frozen passage excerpts support reproducibility. Model weights and third-party paper PDFs are not included. Exact proof-span overlap is a diagnostic rather than complete semantic entailment, and unmatched reference names are not automatically false answers. Natural sparse/dense cached corpus alignment still needs confirmation.

## Reports and maintenance

`reports/project_context/` preserves dated reasoning, budgets and rejected/unapproved ideas. Read `PROJECT_MEMORY.md` there for history. These historical files are not evidence of completed experiments; the Stage 2 report and immutable run artifacts record current measured results. Budget figures are planning estimates and are not authorization to spend.

Commit a dated entry to CHANGELOG.md with each substantive experiment or analysis change. Keep original raw logs immutable, retain a config/hash manifest, and never commit API keys, model caches, browser session links or credentials. Repository publication and future maintenance are performed by the author.

The document-build scripts in `tools/` are preserved as delivery-generation provenance; they assume the original workspace layout and Windows Calibri fonts. The report Markdown is portable and editable independently.
''',encoding='utf-8')
(BUNDLE/'requirements-gpu.txt').write_text('''# Install a CUDA-compatible torch build for your host separately.
transformers==4.51.3
accelerate==1.6.0
numpy==2.1.3
sentence-transformers>=3.0,<4.0
# The notebook itself records and installs its tested dependencies.
''',encoding='utf-8')
(BUNDLE/'requirements-report.txt').write_text('reportlab\npypdf\npdfplumber\npillow\n',encoding='utf-8')
(BUNDLE/'.gitignore').write_text('''__pycache__/
*.pyc
.venv/
.env
.env.*
!.env.example
.cache/
models/
*.safetensors
*.bin
*.pt
*.zip
experiments/failure_pilot/data/raw/*.gz
experiments/failure_pilot/data/raw/*.zip
''',encoding='utf-8')
(BUNDLE/'CHANGELOG.md').write_text('''# Changelog

## 2026-10-18 - Stage 2 preparation

- Preserved Stage 1 proposal and historical project notes.
- Prepared fixed QAMPARI pools and CPU coverage diagnostics.
- Imported completed Kaggle smoke outputs: 384 records, 348 actual generations.
- Recorded original strict scores and documented post-run structural extraction sensitivity.
- Added 88-call reader calibration; neither reader passes the capability gate.
- Prepared Stage 2 report, proposed budget, statistical plan and 50-case assistant-reviewed audit with human verification pending.
- Repository upload package assembled locally; author publication pending.
''',encoding='utf-8')
(BUNDLE/'DATA_PROVENANCE.md').write_text('''# Data provenance

QAMPARI upstream: https://github.com/samsam3232/qampari . See `experiments/failure_pilot/data/raw/manifest.json` for exact source members, checksums, sizes and partial-download provenance. Question sampling and split IDs are frozen in `data/sample_manifest.json`. The top-50 candidate pools are in `data/pools.jsonl`; only discovery outcomes have been analyzed.

Returned smoke ZIP SHA-256: fb7ccbbc8770ababddc3b1b091ff3113c9421573a116b64ac216a963055f1124 . See `runs/ir_run1_20261018/import_manifest.json` and the calibration import manifest for archive hashes and file integrity. Archives themselves are excluded to avoid redundant uploads; extracted original logs are included.

Source paper PDFs and pretrained weights are excluded. Third-party data and model licenses remain upstream. Cached retrieval snapshot alignment is not independently established. Reference-aware selections use gold information for diagnosis only.
''',encoding='utf-8')
(OUT/'BEFORE_SUBMISSION.md').write_text('''# Before submission

1. Use STAGE2_REPORT.pdf as the main six-page report. Add your actual GitHub URL in the report and repository README. The editable Markdown is also supplied.
2. The 50-case appendix is explicitly assistant-reviewed; independent human annotation has not been done. Review the cases yourself, record corrections/verification in the CSV, and disclose the actual reviewer and process. Do not change the report to claim human review unless it actually happened.
3. Unzip STAGE2_GITHUB_UPLOAD.zip and upload its CONTENTS to your repository. Do not merely upload this delivery ZIP as the entire repository.
4. Submit/link the failure appendix with the report, or keep it in reports/stage2/ in the repository. Both full-evidence HTML and CSV versions are supplied.
5. The report describes measured pilot limitations and a proposed future budget; no new selector, significant gain, paid spending, completed full pilot, or approved novelty is claimed.
''',encoding='utf-8')
manifest=[]
for p in sorted(BUNDLE.rglob('*')):
    if p.is_file():manifest.append({'path':p.relative_to(BUNDLE).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(BUNDLE/'UPLOAD_MANIFEST.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
zipname=OUT/'STAGE2_GITHUB_UPLOAD.zip'
with zipfile.ZipFile(zipname,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(BUNDLE.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(BUNDLE).as_posix())
dest=ROOT/'output/pdf';dest.mkdir(parents=True,exist_ok=True)
for name in ['STAGE2_REPORT.pdf','FAILURE_AUDIT_50.pdf']:copy(OUT/name,dest/name)
print(json.dumps({'repository_files':len(manifest)+1,'zip_bytes':zipname.stat().st_size,'zip':str(zipname),'largest_upload_file_bytes':max(x['bytes'] for x in manifest)},indent=2))
