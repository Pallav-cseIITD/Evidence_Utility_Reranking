"""Build the Stage 2 report and a traceable, explicitly assistant-reviewed audit."""
from pathlib import Path
from collections import Counter
import csv, hashlib, html, json, re, shutil, zipfile
from xml.sax.saxutils import escape

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'stage2_delivery'
RUN = ROOT / 'experiments/failure_pilot/runs/ir_run1_20261018'
records = [json.loads(s) for s in (RUN/'raw/generations.jsonl').read_text(encoding='utf-8').splitlines()]
analyses = {r['record_id']: r for r in [json.loads(s) for s in (RUN/'analysis/per_output.jsonl').read_text(encoding='utf-8').splitlines()]}
summary = json.loads((RUN/'analysis/summary.json').read_text(encoding='utf-8'))
ids = [0,10,14,25,28,34,42,52,54,59,81,96,98,102,108,113,114,122,126,148,158,160,172,184,186,
       50,62,64,67,266,268,274,192,194,196,202,204,208,218,220,224,248,254,264,270,288,290,312,338,362]
# These notes were assigned after inspecting the selected question/output records.
notes = {
0: 'Chelsea is present in a complete JSON list. The missing answers wrapper made the strict scorer report no answers; this is a format failure, not demonstrated abstention.',
10: 'The complete Chelsea answer object is followed by a stray quote. Strict JSON rejection erased the answer; semantic correctness is a separate question.',
14: 'A complete list names West Ham and Tottenham, followed by an extra closing brace. The original scorer loses both entries because of the wrapper/suffix.',
25: 'Thayiya Madilu has a citation, but a trailing quote invalidates strict JSON. The zero score cannot be read as an empty response.',
28: 'Sevanthi Sevanthi is returned with D03, followed by an unmatched quote. This case isolates suffix formatting from answer extraction.',
34: 'The diagnostic selector output contains Thayiya Madilu and D01 but ends with a quote. An oracle-style selection does not prevent the scoring failure.',
42: 'After the diversity insertion, Sevanthi Sevanthi is still present, but a trailing quote causes strict rejection. Do not infer a claim loss from that rejection.',
52: 'Palgrave and Weinstein appear in a complete cited object with a trailing quote. Reference-unmatched archivists are not automatically factual errors.',
54: 'Four named archivists are returned as a JSON list rather than an answers object. This is a schema failure; the names need separate support validation.',
59: 'Roberta Spire and Ernst Posner remain extractable before a stray quote. The format issue is established; reference incompleteness remains possible.',
81: 'Antioch College is present with D26, followed by a quote. This audit records the format failure without asserting that the educational relation is correct.',
96: 'All five reference film names are in a complete list. The strict object-only parser nevertheless gives zero, showing a material measurement failure.',
98: 'Elvis is returned in a list instead of the required object. The narrower answer set may be incomplete, but this entry only establishes schema rejection.',
102: 'Moulin Rouge! is returned with D13 followed by a stray quote. A formatting error should not be scored as genuine abstention.',
108: 'The proof-based diagnostic returns all five film names as a list. The strict scorer rejects the container despite retaining usable answer content.',
113: 'Elvis and Romeo + Juliet are present before a trailing quote. Strict parsing would hide both after insertion; this is not evidence of reader abstention.',
114: 'Moulin Rouge! is returned in a bare JSON list. The format contract fails; the causal benefit of the inserted passage remains unestablished.',
122: 'The cited watercolours/digital-art output ends with a quote. Format failure is certain; the Fred Barron entity ambiguity requires separate semantic review.',
126: 'The watercolours object ends with a quote. This is a measurement case, not a claim that the generated work satisfies the intended Fred Barron relation.',
148: 'Wrexham County Borough is returned before a stray quote. Strict parsing suppresses an explicit answer instead of flagging format failure separately.',
158: 'Conwy County Borough appears in a bare list. The container mismatch is observable independently of benchmark alias matching.',
160: 'Neath Port Talbot is present in a complete object with a trailing quote. The original zero is a parser outcome, not an empty answer list.',
172: 'Islands Protected Area is in a bare list. This case establishes schema failure only; the size threshold and identity need independent evidence checking.',
184: 'A convention title is returned in a bare list. Besides the format failure, a treaty title is not itself the requested protected area.',
186: 'Transboundary Protected Areas is in a bare list. It is also a generic category rather than one clearly identified qualifying protected area.',
50: 'Example entity is a template placeholder, not a named archivist. Valid JSON and a passage ID do not make this a supported answer.',
62: 'The two-passage state yields Example entity with two citations. Extra citations do not repair a placeholder answer.',
64: 'After relevance insertion, the reader still emits Example entity. The label would reflect reader failure rather than useful evidence coverage.',
67: 'After diversity insertion, Example entity remains the sole answer. This is a separate generated record, not a distinct question or independent failure type.',
266: 'Example entity is returned instead of an educational institution. There is also trailing instruction text; content extraction cannot repair placeholder semantics.',
268: 'Example entity repeats until the 512-token limit and leaves incomplete JSON. Neither structural extraction nor extra context recovers a valid answer.',
274: 'Four cited Example entity entries replace educational places. The reference-aware evidence set does not remove this reader failure.',
192: 'Chippa United is explicitly based in South Africa in D05, and Reading Town is in Reading in D03. Neither satisfies the requested London club condition.',
194: 'London is included as an answer although the question requests a club. Other club entries may be valid; this audit does not mark the entire response false.',
196: 'Gary Lineker is a person, not a club; the response also mixes leagues and locations. This is an answer-type/constraint failure, beyond JSON formatting.',
202: 'London and Stamford Bridge are included among club names. They are a city and a stadium, so the answer type is not enforced.',
204: 'Stamford Bridge and Premier League are returned as clubs. D01 identifies the former as a stadium; the latter is a league.',
208: 'The inserted stadium passage causes Stamford Bridge to appear as an answer. A relevant passage can supply the wrong answer type to this reader.',
218: 'S. A. Rajkumar is repeated as an answer to a film question. Citing the composer biography does not satisfy the requested film entity type.',
220: 'Both answer entries name S. A. Rajkumar rather than films. The model copies the constraint entity instead of finding entities satisfying the relation.',
224: 'S. A. Rajkumar repeats after an initial film until generation is truncated. This combines wrong entity type, duplication, and incomplete serialization.',
248: 'Archivist of the United States and The Archivist are returned alongside a person. An office/title is not a named person answering who; Charles Piot is not rejected.',
254: 'List of archivists and Archivist (disambiguation) are page titles, not individual people. The reader copies retrieved titles instead of extracting people.',
264: 'The output lists Ric Ocasek, Benjamin Orr and band names instead of educational institutions. Some citations point to unrelated passages as well.',
270: 'The response mixes institutions with Ric Ocasek, a dialect, a car model and an assassination. Only the demonstrably wrong entity types are flagged here.',
288: 'Craig Pearce and Baz Luhrmann are included as movie answers. Valid film entries elsewhere in the response do not justify these person entries.',
290: 'The response again includes the writer and director as movie names. The question constraints are being copied as answers.',
312: 'Fred Barron, James Clover, Harris Barron and Stephan Barron are people, not works of art. The response fails the requested output type.',
338: 'County borough, North Wales, and Counties of the United Kingdom are included as principal areas. The response mixes categories, region and governing body.',
362: 'Natural Park of the Coral Sea is repeated until the token limit, leaving incomplete JSON. This audit does not reject that park as a valid protected area.'
}
assert len(ids) == len(notes) == 50
rows = []
for n, idx in enumerate(ids, 1):
    r = records[idx]; a = analyses[r['record_id']]
    if n <= 25: category = 'format / measurement'
    elif idx in (268,224,362): category = 'repetition / truncation'
    elif n <= 32: category = 'placeholder answer'
    elif idx == 192: category = 'query constraint / location'
    else: category = 'wrong answer type'
    rows.append(dict(case_id=f'F{n:02d}', source_row_zero_based=idx, record_id=r['record_id'], qid=r['qid'],
        question=r['messages'][1]['content'].split('\n')[0].removeprefix('Question: '), reader=r['reader'],
        method=r['method'], seed=r['seed'], category=category, analysis=notes[idx], raw_output=r['output'],
        content_mode=a['content_mode'], selected_evidence='\n\n'.join(e['rendered'] for e in r['evidence']),
        reviewer='Codex assistant; case-level review; not independent human annotation',
        human_verified='', human_reviewer='', human_correction=''))
assert len({r['record_id'] for r in rows}) == 50
assert len({records[i]['cache_key'] for i in ids}) == 50
assert not any(records[i]['cache_hit'] for i in ids)
with (OUT/'failure_audit_50.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(OUT/'failure_audit_summary.json').write_text(json.dumps({'cases':50,'questions':8,'non_cached_generation_records':50,
    'categories':dict(Counter(r['category'] for r in rows)), 'reviewer':'Codex assistant',
    'independent_human_annotations_completed':0,'sampling':'Purposive diagnostic sample; not a prevalence estimate'},indent=2),encoding='utf-8')
cards=['<!doctype html><meta charset="utf-8"><title>50-case failure audit</title><style>body{font:16px/1.5 Arial;max-width:1000px;margin:35px auto}article{border-top:2px solid #234871;padding-top:20px;margin-bottom:45px}pre{white-space:pre-wrap;background:#f2f5f8;padding:12px}summary{cursor:pointer}h1,h2{color:#203e6b}</style><h1>Stage 2: 50-case qualitative audit</h1><p><b>Provenance:</b> assistant case-level review of 50 uncached generated outputs across eight questions. This is not independent human annotation, 50 independent questions, or a random failure-rate sample. Human verification fields in the CSV are blank. Cases F01-F25 establish format/measurement failures and do not by themselves establish factually wrong answers.</p>']
for r in rows:
    cards.append(f'<article><h2>{r["case_id"]}: {html.escape(r["category"])}</h2><p>{html.escape(r["question"])}</p><p>{html.escape(r["reader"])} | {html.escape(r["method"])} | seed {r["seed"]}</p><p><b>Analysis:</b> {html.escape(r["analysis"])}</p><pre>{html.escape(r["raw_output"])}</pre><details><summary>Inspect exact selected evidence and trace</summary><p>Record {r["record_id"]}</p><pre>{html.escape(r["selected_evidence"])}</pre></details></article>')
(OUT/'failure_audit_50.html').write_text('\n'.join(cards),encoding='utf-8')

# Main document: explicit page boundaries keep the Stage 1 hierarchy easy to scan.
PAGES = [
[
('title','Evidence Utility Reranking for Grounded Generation'),
('center','COL764 - Information Retrieval and Web Search'),
('center','Pallav Kamad | 2023CS51067'),
('subtitle','Stage 2: Initial Pilot | 18 October 2026'),
('small','Repository URL: ____________________________________ (author to insert before submission)'),
('h2','Core research question'),
('p','Can passages be selected by their marginal contribution to a grounded answer, at a fixed evidence budget, so that more answer claims are supported with less redundancy and contradiction? The original task and frozen top-50 selection setting are retained.'),
('formula','u(d | S, q) = F(S union {d}, q) - F(S, q)'),
('p','F measures grounded answer quality. The formula and greedy selection are established formulations, not claimed contributions. This report presents completed pilot diagnostics and a costed continuation plan; it does not claim a new trained selector.'),
('h1','1. Primary hypothesis and current research status'),
('h2','1.1 Hypothesis carried forward from Stage 1'),
('p','A compact selector trained on measured changes in grounded answer quality may choose better evidence than independent relevance or diversity alone. The hypothesis remains unconfirmed: no selector has been trained, and the reader-label pipeline first needs calibration.'),
('h2','1.2 Response to the novelty feedback'),
('p','RRPO already uses generation-quality rewards for successive selected sets; DynamicRAG optimizes retrieval decisions with downstream feedback; InfoGain-RAG studies information-gain-based selection; eRAG evaluates retrieval through document-conditioned downstream performance. UtilityQwen distills utility judgments into compact selectors. Therefore, downstream QA rewards, set conditioning, and teacher distillation are insufficient novelty claims [1-5].'),
('p','The continuation is failure-first: establish a repeatable failure of strong existing methods, specify the smallest mechanism that addresses it, then test that mechanism against ordinary marginal supervision under equal data, labeling calls, and evidence tokens. Calibration is a necessary experimental correction, not yet a publishable algorithm.'),
('h2','1.3 Backoff formulation'),
('p','If usable marginal labels cannot be collected reliably, study evidence coverage and redundancy with reference-aware diagnostics, keeping gold-aware selection out of deployable comparisons. A negative result about labeling reliability is reportable; a novelty or effectiveness claim will require further evidence.')
],
[
('h1','2. Benchmark, split plan, and completed pilot'),
('h2','2.1 Data preparation and scope'),
('p','The pilot uses the official QAMPARI development release and its natural BM25 and DPR retrieval caches. Reciprocal-rank fusion (constant 60) produces a frozen top-50 pool. Sparse and dense document IDs are namespaced; only exact normalized title/text duplicates are merged. Corpus-snapshot alignment is not independently verified, so these are cached-retrieval diagnostics, not a completed new indexing experiment [6].'),
('p','A deterministic hash sample fixes 200 questions: 100 discovery and 100 confirmation. CPU diagnostics cover the 100 discovery questions. GPU smoke tests use only the first eight discovery questions. Confirmation outcomes and the official test split remain unused. The original 100-200-question generator pilot is not yet complete.'),
('h2','2.2 CPU evidence-coverage diagnostic: 100 questions'),
('table',(['Selection, k=5','Answer-alias coverage','Exact proof-span coverage'],[
['Fused retrieval top-5','20.05%','6.70%'],['Lexical MMR, weight 0.5','17.75%','5.01%'],['Gold-aware alias greedy*','48.99%','13.66%'],['Gold-aware proof greedy*','30.52%','21.37%'],['All 50 passages (context only)','51.29%','21.94%']])),
('small','* Diagnostic uses reference information, unavailable to a deployable selector. Five passages are matched in count, not exact tokens. Alias appearance does not prove the requested relation; literal proof matching misses valid alternative evidence.'),
('p','Gold-aware proof selection exceeds fused top-5 literal proof coverage by 14.67 percentage points (question-bootstrap 95% interval: 11.11 to 18.42). This demonstrates proxy headroom in the candidate pool, not an improvement in generated answers. Greedy selection attains the exact optimum of the alias-coverage proxy on 99/100 questions, further limiting claims that greedy optimization itself is new.'),
('h2','2.3 Completed Kaggle smoke run'),
('p','The returned ir_run1 artifact contains 384 logical records: 8 questions x 12 conditions x 2 readers x 2 generation seeds. Caching reduces this to 348 actual generation calls. Both readers see the same selected evidence. Qwen2.5-3B-Instruct and SmolLM2-1.7B-Instruct run sequentially on one Tesla T4; the notebook allocation exposes two T4s but the code uses GPU 0.'),
('p','Conditions include fusion, MiniLM cross-encoder relevance, dense MMR weights 0.2/0.5/0.8, two gold-aware coverage diagnostics, a two-passage base and two three-passage insertions, closed-book and shuffled-context controls. Evidence is capped at 1,280 tokens under both tokenizers (maximum logged: 895). The run used 250,840 input and 23,124 output tokens; summed generation time was 778.14 seconds, excluding loading and other session overhead.')
],
[
('h1','3. Pilot findings and verified corrections'),
('h2','3.1 Separating format failure from answer failure'),
('p','The original parser requires an answers object. Complete answer lists and otherwise complete objects followed by punctuation were rejected and scored as empty. For example, Qwen returns all five reference film names for the Baz Luhrmann/Craig Pearce question in a JSON list; the original strict scorer assigns zero. This is a measurement defect, not evidence that those answers were absent.'),
('table',(['Reader, 192 records each','Strict schema valid','Content extractable*'],[
['Qwen2.5-3B','107/192 (55.73%)','174/192 (90.63%)'],['SmolLM2-1.7B','34/192 (17.71%)','160/192 (83.33%)']])),
('p','A documented post-run sensitivity analysis extracts complete typed JSON objects/lists without altering names, adding citations, repairing truncated JSON, or joining ambiguous multiple values. Original strict scores are preserved. Unextractable outputs remain zero in all-output metrics and are separately flagged. This correction improves measurement; it is not a selector improvement.'),
('h2','3.2 Exploratory answer results: eight questions only'),
('table',(['Selection','Qwen recall / attributed','Smol recall / attributed'],[
['Fusion top-5','17.50% / 11.25%','16.25% / 10.00%'],['Cross-encoder relevance','7.50% / 6.25%','11.25% / 6.88%'],['Dense MMR, weight 0.5','7.50% / 3.75%','11.25% / 8.13%'],['Gold-aware proof diagnostic','20.63% / 16.88%','18.75% / 12.50%']])),
('small','Macro reference-answer recall; attributed recall additionally requires an exact annotated proof in the cited evidence. Two seeds averaged within question; unextractable outputs score zero. All figures are exploratory post-run extraction sensitivity, not a significance result. Exact-proof attribution is a conservative proxy, not human-validated entailment.'),
('h2','3.3 Follow-up reader calibration: 88 additional calls'),
('p','Six handcrafted controls test direct answers, five-item enumeration, a two-step join, and three no-answer cases (irrelevant evidence, partial constraint, missing bridge). The gate was set before these runs: at least 5/6 exact answer-and-citation passes and all three negative controls. Two prompt variants, two readers, and 22 inputs per variant/reader yield 88 calls, including the eight real proof-selected and eight shuffled-context inputs.'),
('table',(['Reader','Original prompt','Instruction/examples/line-format bundle'],[
['Qwen2.5-3B','2/6; negatives 0/3','4/6; negatives 3/3'],['SmolLM2-1.7B','1/6; negatives 0/3','1/6; negatives 1/3']])),
('p','Neither reader passes. The revised prompt fixes Qwen negative controls but still misses the join and is not an isolated test of format alone. Closed-book smoke outputs are all unextractable, so a zero score cannot establish zero memorized knowledge. The immediate decision is to repair/replace and re-calibrate the label reader before collecting a large training set.')
],
[
('h1','4. Exact follow-up resource and labeling budget'),
('p','This is one bounded planning scenario beyond the completed pilot, not measured future usage or approval to spend. Scope: 500 training questions, 100 development questions, and 1,000 untouched official test questions. After the failure/method gate, budget three supervision arms: independent utility, ordinary marginal utility, and a candidate correction. The third arm is reserved; its method is not yet established.'),
('h2','4.1 Label requests and inference accounting'),
('p','Per training question/arm: sample five evidence states, compare four insertions at each state, and cache each baseline. This requires 5 x (1 + 4) = 25 reader calls for 20 marginal labels. Two generation seeds cost 50 calls. Three arms x 500 questions x 50 calls = 75,000 calls. Shared caching can reduce actual usage; no savings are assumed. Singleton supervision receives an equal call allocation. By contrast, exhaustive greedy selection of five from 50 costs 1 + 50 + 49 + 48 + 47 + 46 = 241 unique reader states per question/seed before judging.'),
('p','Four fixed systems plus three learned arms trained with three seeds give 13 configurations. Evaluate each on 100 dev + 1,000 test questions, two readers and two generation seeds: 13 x 1,100 x 2 x 2 = 57,200 calls. Total planned calls: 132,200; a 10% calibration/retry reserve adds 13,220, giving a 145,420-call ceiling. Reference-based scoring needs no paid judge calls. New semantic-judge calls would require a revised budget.'),
('h2','4.2 GPU, API, indexing, storage, and annotation'),
('table',(['Resource','Exact planned allocation','Estimated cash (USD)'],[
['GPU/host','1 RTX A6000 48 GB; 220 GPU-hours','220 x $0.59 = $129.80'],
['GPU-hour breakdown','Labels 100; evaluation 72; training 36; index 12','Included above'],
['API','0 paid requests; all readers self-hosted','$0.00'],
['Indexing','12 GPU-hours + up to 64 vCPU-hours; fixed aligned pools','Included host time'],
['Persistent storage','200 GB network volume x 1 month','$14.00'],
['Container storage','20 GB x 1 month (conservative allocation)','$2.00'],
['Human annotation','20 person-hours, project-member labor','$0 cash; 20 h labor'],
['Base / 20% financial reserve','$145.80 + $29.16','$174.96 total']])),
('small','GPU/host reference: 48 GB VRAM, 50 GB RAM, 9 vCPUs at $0.59/hour on Runpod public pricing, checked 18 Oct 2026. Network storage $0.07/GB/month; running container storage $0.10/GB/month [8,9]. Rates/availability can change. Budget is USD before tax/currency conversion; no rental or paid API has been launched.'),
('p','The 36 training hours allocate 4 hours to each of nine compact-selector runs. The generation allocation assumes roughly four seconds per request, including a reserve; it is not a throughput guarantee for an unqualified replacement reader. Index time assumes reusing released/prebuilt aligned indexes, not embedding all Wikipedia from scratch. Rebuilds or slower readers trigger a scope/budget amendment rather than hidden costs.'),
('p','Annotation accounting: 50 failures x 2 humans x 5 minutes + 100 minutes adjudication = 10 hours; 120 claim/support decisions x 2 humans x 2 minutes + 120 minutes adjudication = 10 hours. If paid at an assumed $10/hour, add $200 labor and its 20% reserve: total $414.96. This hourly rate is a planning assumption. Human work has not yet been completed.')
],
[
('h1','5. Statistical testing and 50-case failure analysis'),
('h2','5.1 Confirmatory testing plan'),
('p','Primary endpoint: per-question grounded answer-claim recall at a shared evidence-token cap (1,280 for the current configuration). Confirm the final scorer, reader, prompt, token cap, utility weights and method before opening confirmation/test results. Report answer recall, citation support, redundancy, contradiction, retrieval recall, tokens, latency and label cost separately. Literal proof overlap is diagnostic; semantic support requires independent validation.'),
('p','The statistical unit is the question, not a passage, seed or cached output. Average the two generation seeds within a question and report both readers separately. For learned systems, retain three training seeds, report mean/spread, and average seed outcomes within question for the primary paired comparison. Treat reader transfer as a prespecified replication, not an extra sample of questions.'),
('p','For the candidate versus tuned MMR, the strongest released utility selector, and ordinary marginal training, report paired mean differences, 95% question-bootstrap intervals (10,000 resamples), and a paired sign-flip randomization test (100,000 permutations, two-sided). Use Holm correction over the three primary comparisons at family-wise alpha 0.05. Include ties, disclose invalid outputs, and repeat scores with the frozen strict and structural-extraction policies as a sensitivity analysis.'),
('p','Before final testing, estimate paired question-level variance on development data and run a simulation-based power check for a 3 percentage-point gain. With 1,000 test questions, a simple unadjusted normal approximation has detectable effect about 2.8 x SD(delta)/sqrt(1,000), approximately 1.8 points if SD(delta)=0.20. This is an illustration, not a power estimate obtained from the eight-question smoke run. If power is inadequate, report uncertainty rather than claim no effect.'),
('h2','5.2 Completed qualitative audit and its limits'),
('p','The accompanying appendix and CSV contain 50 individually reviewed, uncached output records spanning all eight pilot questions, with exact record IDs, question, reader, evidence condition, seed, output, diagnosis and access to selected evidence. Review was performed by the assistant and is explicitly labeled as such. There are zero completed independent human annotations; the 120-row returned blinded annotation sheet is blank. Accordingly, the human-analysis requirement remains pending author/human verification.'),
('table',(['Primary diagnostic category','Reviewed output records'],[
['Format/measurement failure','25'],['Placeholder answer','6'],['Wrong answer type','15'],['Repetition/truncation','3'],['Query location constraint','1'],['Total; 8 questions, purposive sample','50']])),
('p','Examples: complete film lists rejected by the original parser; a South Africa-based club returned for a London-club question; writer/director names returned instead of movies; repeated placeholders or park names exhausting the token limit. Categories are assigned by the main observable issue; cases may have secondary issues. These counts describe the selected audit sample and cannot estimate population failure prevalence.'),
('p','Human validation protocol: two reviewers independently inspect the question, rendered evidence and answer while blinded to method identity; mark schema, entity type, all query constraints, support, omission, duplication and uncertainty. Retain corrections, resolve disagreements, and report raw agreement plus Cohen kappa on applicable categorical labels. Do not automatically mark reference-unmatched entities false, especially for the open-ended archivist question.')
],
[
('h1','6. Training-label plan and decisive next experiment'),
('p','Keep the Stage 1 insertion/deletion design. First calibrate a fixed reader on direct, conjunctive, multi-hop and abstention controls, then validate a reference-supported sample with humans. Freeze F and weights before large-scale labeling; record separate supported-claim gain, supported-claim loss, citation/support and contradiction components. Repeated seeds expose label instability, and uncertain pairs may be abstained from with their cost recorded. These are proposed safeguards, not established novelty.'),
('p','The decisive comparison will use the same candidate pools, compact selector, training questions, teacher-call budget and evidence-token budget for independent utility, ordinary marginal utility and the chosen correction. Compare with tuned relevance, dense MMR, deployable coverage selection and a released utility selector. Add the closest feasible RRPO/DynamicRAG-style outcome-reward control where required by the final mechanism; a budgeted adaptation must be labeled as such, not a full reproduction.'),
('h1','7. Go/no-go decision, deliverables, and repository'),
('p','Current decision: continue the project within the original scope, but do not scale the present reader-generated labels or describe a selector as novel. The completed pilot verifies a measurement failure and reader constraint/type failures. It does not yet establish a stable set-selection failure that a new training method fixes. A positive continuation needs a calibrated reader, a repeatable failure beyond strong baselines, and a prespecified equal-cost comparison on held-out questions.'),
('p','Repository package: report and editable source; Stage 1 report; pilot and calibration code; self-contained Kaggle notebook; frozen manifests/model revisions; returned outputs and original summary; post-run analysis and plans; CPU results; 50-case audit CSV/HTML/PDF; integrity tests; dataset provenance and reproduction instructions. Model weights, large source archives, credentials and third-party paper PDFs are excluded. The author will insert the repository URL and upload the prepared folder.'),
('p','Maintenance plan: preserve immutable raw runs; commit each experiment configuration and analysis change; append a dated changelog entry and distinguish planned work from measured results. The package has been prepared locally; an uploaded repository and regular future maintenance cannot yet be claimed.'),
('h1','8. Key references'),
('ref','[1] RRPO, ACL 2026. https://aclanthology.org/2026.acl-long.1406/'),
('ref','[2] DynamicRAG, NeurIPS 2025. https://arxiv.org/abs/2505.07233'),
('ref','[3] InfoGain-RAG, EMNLP 2025. https://aclanthology.org/2025.emnlp-main.365/'),
('ref','[4] eRAG, SIGIR 2024. https://arxiv.org/abs/2404.13781'),
('ref','[5] Zhang et al. Distilling a Small Utility-Based Passage Selector to Enhance Retrieval-Augmented Generation, SIGIR-AP 2025. https://arxiv.org/abs/2507.19102'),
('ref','[6] QAMPARI official data, code and retrieval caches. https://github.com/samsam3232/qampari'),
('ref','[7] Reader checkpoints: https://huggingface.co/Qwen/Qwen2.5-3B-Instruct ; https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct'),
('ref','[8] Runpod GPU/host pricing, checked 18 October 2026. https://www.runpod.io/pricing'),
('ref','[9] Runpod storage pricing, checked 18 October 2026. https://docs.runpod.io/pods/pricing')
]
]

def write_markdown():
    chunks=[]
    for page in PAGES:
        for kind,value in page:
            if kind=='table':
                headers,body=value; chunks.append('| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+'\n'.join('| '+' | '.join(row)+' |' for row in body))
            elif kind in ['title','h1','h2']: chunks.append(('# ' if kind=='title' else '## ' if kind=='h1' else '### ')+value)
            else: chunks.append(value)
        chunks.append('<!-- page boundary -->')
    (OUT/'STAGE2_REPORT.md').write_text('\n\n'.join(chunks),encoding='utf-8')

def build_pdfs():
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.lib.pagesizes import A4
    fontdir=Path('C:/Windows/Fonts')
    for alias,filename in [('Body','calibri.ttf'),('Bold','calibrib.ttf'),('Italic','calibrii.ttf')]:
        pdfmetrics.registerFont(TTFont(alias,str(fontdir/filename)))
    pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Italic',boldItalic='Bold')
    styles={
        'p':ParagraphStyle('p',fontName='Body',fontSize=10.1,leading=13.5,spaceAfter=7),
        'title':ParagraphStyle('title',fontName='Bold',fontSize=16.2,leading=20,textColor=colors.HexColor('#203e6b'),alignment=TA_CENTER,spaceAfter=5),
        'center':ParagraphStyle('center',fontName='Body',fontSize=10.6,leading=14,alignment=TA_CENTER,spaceAfter=2),
        'subtitle':ParagraphStyle('subtitle',fontName='Italic',fontSize=10,leading=13,alignment=TA_CENTER,textColor=colors.HexColor('#555555'),spaceAfter=12),
        'h1':ParagraphStyle('h1',fontName='Bold',fontSize=12.8,leading=16,textColor=colors.HexColor('#203e6b'),spaceBefore=5,spaceAfter=8,keepWithNext=True),
        'h2':ParagraphStyle('h2',fontName='Bold',fontSize=10.8,leading=14,textColor=colors.HexColor('#2c5690'),spaceBefore=5,spaceAfter=5,keepWithNext=True),
        'small':ParagraphStyle('small',fontName='Body',fontSize=8.3,leading=10.8,textColor=colors.HexColor('#4e5560'),spaceAfter=8),
        'formula':ParagraphStyle('formula',fontName='Italic',fontSize=12,leading=17,alignment=TA_CENTER,spaceAfter=10),
        'ref':ParagraphStyle('ref',fontName='Body',fontSize=8.4,leading=10.4,spaceAfter=4),
        'cell':ParagraphStyle('cell',fontName='Body',fontSize=8.7,leading=11),
        'audit':ParagraphStyle('audit',fontName='Body',fontSize=8.7,leading=11.1,spaceAfter=3),
    }
    def para(t,style='p'): return Paragraph(escape(str(t)).replace('\n','<br/>'),styles[style])
    def footer(c,d):
        c.setStrokeColor(colors.HexColor('#dce2ea'));c.line(48,39,A4[0]-48,39)
        c.setFont('Body',8);c.setFillColor(colors.HexColor('#687483'));c.drawString(48,26,'COL764 | Pallav Kamad | Stage 2 | 18 October 2026');c.drawRightString(A4[0]-48,26,str(d.page))
    story=[]
    for i,page in enumerate(PAGES):
        if i: story.append(PageBreak())
        for kind,value in page:
            if kind=='table':
                heads,body=value
                width=A4[0]-96
                if len(heads)==2: widths=[width*.77,width*.23]
                elif i==3: widths=[width*.21,width*.52,width*.27]
                else: widths=[width*.40,width*.30,width*.30]
                data=[[Paragraph('<b>'+escape(x)+'</b>',styles['cell']) for x in heads]]+[[para(x,'cell') for x in row] for row in body]
                tab=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
                tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e8eff8')),('VALIGN',(0,0),(-1,-1),'TOP'),('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#b1c0d4')),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#e1e6ec')),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6)]))
                story.extend([tab,Spacer(1,7)])
            else: story.append(para(value,kind))
    doc=SimpleDocTemplate(str(OUT/'STAGE2_REPORT.pdf'),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=43,bottomMargin=48,title='Evidence Utility Reranking - Stage 2 Initial Pilot',author='Pallav Kamad')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    audit=[]
    for chunk in range(10):
        if chunk:audit.append(PageBreak())
        audit.append(para('Appendix: 50-case qualitative failure audit','h1'))
        audit.append(para('Assistant-reviewed outputs; independent human validation pending. Eight questions, 50 uncached generated records. Purposive sample; no prevalence estimate. Full outputs/evidence and verification fields are in the companion CSV/HTML.','small'))
        for r in rows[chunk*5:(chunk+1)*5]:
            title=f'{r["case_id"]} | Q {r["qid"].split("__")[0]} | {r["reader"].split("/")[-1]} | seed {r["seed"]} | {r["category"]}'
            method=r['method'].replace('reference_','ref_').replace('_DIAGNOSTIC','*')
            excerpt=' '.join(r['raw_output'].split())[:145]
            block=[para(title,'h2'),para('Condition: '+method+'; source row '+str(r['source_row_zero_based'])+'.','audit'),
                   para('Observed: '+excerpt+(' ...' if len(r['raw_output'])>145 else ''),'audit'),para(r['analysis'],'audit'),Spacer(1,5)]
            audit.append(KeepTogether(block))
    SimpleDocTemplate(str(OUT/'FAILURE_AUDIT_50.pdf'),pagesize=A4,rightMargin=48,leftMargin=48,topMargin=39,bottomMargin=47,title='50-case qualitative failure audit',author='Pallav Kamad; assistant review disclosed').build(audit,onFirstPage=footer,onLaterPages=footer)

if __name__=='__main__':
    write_markdown(); build_pdfs()
    print(json.dumps({'report':str(OUT/'STAGE2_REPORT.pdf'),'audit_cases':len(rows),'audit_categories':dict(Counter(r['category'] for r in rows))},indent=2))
