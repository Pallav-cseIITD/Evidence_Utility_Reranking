# Data provenance

QAMPARI upstream: https://github.com/samsam3232/qampari . See `experiments/failure_pilot/data/raw/manifest.json` for exact source members, checksums, sizes and partial-download provenance. Question sampling and split IDs are frozen in `data/sample_manifest.json`. The top-50 candidate pools are in `data/pools.jsonl`; only discovery outcomes have been analyzed.

Returned smoke ZIP SHA-256: fb7ccbbc8770ababddc3b1b091ff3113c9421573a116b64ac216a963055f1124 . See `runs/ir_run1_20261018/import_manifest.json` and the calibration import manifest for archive hashes and file integrity. Archives themselves are excluded to avoid redundant uploads; extracted original logs are included.

Source paper PDFs and pretrained weights are excluded. Third-party data and model licenses remain upstream. Cached retrieval snapshot alignment is not independently established. Reference-aware selections use gold information for diagnosis only.
