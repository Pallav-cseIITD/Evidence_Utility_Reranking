# Changelog

## 2026-10-18 - Stage 2 preparation

- Preserved Stage 1 proposal and historical project notes.
- Prepared fixed QAMPARI pools and CPU coverage diagnostics.
- Imported completed Kaggle smoke outputs: 384 records, 348 actual generations.
- Recorded original strict scores and documented post-run structural extraction sensitivity.
- Added 88-call reader calibration; neither reader passes the capability gate.
- Prepared Stage 2 report, proposed budget, statistical plan and 50-case assistant-reviewed audit with human verification pending.
- Repository upload package assembled locally; author publication pending.
