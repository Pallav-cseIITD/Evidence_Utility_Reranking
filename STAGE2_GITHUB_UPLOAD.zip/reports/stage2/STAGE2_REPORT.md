# Evidence Utility Reranking for Grounded Generation

COL764 - Information Retrieval and Web Search

Pallav Kamad | 2023CS51067

Stage 2: Initial Pilot | 18 October 2026

Repository URL: ____________________________________ (author to insert before submission)

### Core research question

Can passages be selected by their marginal contribution to a grounded answer, at a fixed evidence budget, so that more answer claims are supported with less redundancy and contradiction? The original task and frozen top-50 selection setting are retained.

u(d | S, q) = F(S union {d}, q) - F(S, q)

F measures grounded answer quality. The formula and greedy selection are established formulations, not claimed contributions. This report presents completed pilot diagnostics and a costed continuation plan; it does not claim a new trained selector.

## 1. Primary hypothesis and current research status

### 1.1 Hypothesis carried forward from Stage 1

A compact selector trained on measured changes in grounded answer quality may choose better evidence than independent relevance or diversity alone. The hypothesis remains unconfirmed: no selector has been trained, and the reader-label pipeline first needs calibration.

### 1.2 Response to the novelty feedback

RRPO already uses generation-quality rewards for successive selected sets; DynamicRAG optimizes retrieval decisions with downstream feedback; InfoGain-RAG studies information-gain-based selection; eRAG evaluates retrieval through document-conditioned downstream performance. UtilityQwen distills utility judgments into compact selectors. Therefore, downstream QA rewards, set conditioning, and teacher distillation are insufficient novelty claims [1-5].

The continuation is failure-first: establish a repeatable failure of strong existing methods, specify the smallest mechanism that addresses it, then test that mechanism against ordinary marginal supervision under equal data, labeling calls, and evidence tokens. Calibration is a necessary experimental correction, not yet a publishable algorithm.

### 1.3 Backoff formulation

If usable marginal labels cannot be collected reliably, study evidence coverage and redundancy with reference-aware diagnostics, keeping gold-aware selection out of deployable comparisons. A negative result about labeling reliability is reportable; a novelty or effectiveness claim will require further evidence.

<!-- page boundary -->

## 2. Benchmark, split plan, and completed pilot

### 2.1 Data preparation and scope

The pilot uses the official QAMPARI development release and its natural BM25 and DPR retrieval caches. Reciprocal-rank fusion (constant 60) produces a frozen top-50 pool. Sparse and dense document IDs are namespaced; only exact normalized title/text duplicates are merged. Corpus-snapshot alignment is not independently verified, so these are cached-retrieval diagnostics, not a completed new indexing experiment [6].

A deterministic hash sample fixes 200 questions: 100 discovery and 100 confirmation. CPU diagnostics cover the 100 discovery questions. GPU smoke tests use only the first eight discovery questions. Confirmation outcomes and the official test split remain unused. The original 100-200-question generator pilot is not yet complete.

### 2.2 CPU evidence-coverage diagnostic: 100 questions

| Selection, k=5 | Answer-alias coverage | Exact proof-span coverage |
| --- | --- | --- |
| Fused retrieval top-5 | 20.05% | 6.70% |
| Lexical MMR, weight 0.5 | 17.75% | 5.01% |
| Gold-aware alias greedy* | 48.99% | 13.66% |
| Gold-aware proof greedy* | 30.52% | 21.37% |
| All 50 passages (context only) | 51.29% | 21.94% |

* Diagnostic uses reference information, unavailable to a deployable selector. Five passages are matched in count, not exact tokens. Alias appearance does not prove the requested relation; literal proof matching misses valid alternative evidence.

Gold-aware proof selection exceeds fused top-5 literal proof coverage by 14.67 percentage points (question-bootstrap 95% interval: 11.11 to 18.42). This demonstrates proxy headroom in the candidate pool, not an improvement in generated answers. Greedy selection attains the exact optimum of the alias-coverage proxy on 99/100 questions, further limiting claims that greedy optimization itself is new.

### 2.3 Completed Kaggle smoke run

The returned ir_run1 artifact contains 384 logical records: 8 questions x 12 conditions x 2 readers x 2 generation seeds. Caching reduces this to 348 actual generation calls. Both readers see the same selected evidence. Qwen2.5-3B-Instruct and SmolLM2-1.7B-Instruct run sequentially on one Tesla T4; the notebook allocation exposes two T4s but the code uses GPU 0.

Conditions include fusion, MiniLM cross-encoder relevance, dense MMR weights 0.2/0.5/0.8, two gold-aware coverage diagnostics, a two-passage base and two three-passage insertions, closed-book and shuffled-context controls. Evidence is capped at 1,280 tokens under both tokenizers (maximum logged: 895). The run used 250,840 input and 23,124 output tokens; summed generation time was 778.14 seconds, excluding loading and other session overhead.

<!-- page boundary -->

## 3. Pilot findings and verified corrections

### 3.1 Separating format failure from answer failure

The original parser requires an answers object. Complete answer lists and otherwise complete objects followed by punctuation were rejected and scored as empty. For example, Qwen returns all five reference film names for the Baz Luhrmann/Craig Pearce question in a JSON list; the original strict scorer assigns zero. This is a measurement defect, not evidence that those answers were absent.

| Reader, 192 records each | Strict schema valid | Content extractable* |
| --- | --- | --- |
| Qwen2.5-3B | 107/192 (55.73%) | 174/192 (90.63%) |
| SmolLM2-1.7B | 34/192 (17.71%) | 160/192 (83.33%) |

A documented post-run sensitivity analysis extracts complete typed JSON objects/lists without altering names, adding citations, repairing truncated JSON, or joining ambiguous multiple values. Original strict scores are preserved. Unextractable outputs remain zero in all-output metrics and are separately flagged. This correction improves measurement; it is not a selector improvement.

### 3.2 Exploratory answer results: eight questions only

| Selection | Qwen recall / attributed | Smol recall / attributed |
| --- | --- | --- |
| Fusion top-5 | 17.50% / 11.25% | 16.25% / 10.00% |
| Cross-encoder relevance | 7.50% / 6.25% | 11.25% / 6.88% |
| Dense MMR, weight 0.5 | 7.50% / 3.75% | 11.25% / 8.13% |
| Gold-aware proof diagnostic | 20.63% / 16.88% | 18.75% / 12.50% |

Macro reference-answer recall; attributed recall additionally requires an exact annotated proof in the cited evidence. Two seeds averaged within question; unextractable outputs score zero. All figures are exploratory post-run extraction sensitivity, not a significance result. Exact-proof attribution is a conservative proxy, not human-validated entailment.

### 3.3 Follow-up reader calibration: 88 additional calls

Six handcrafted controls test direct answers, five-item enumeration, a two-step join, and three no-answer cases (irrelevant evidence, partial constraint, missing bridge). The gate was set before these runs: at least 5/6 exact answer-and-citation passes and all three negative controls. Two prompt variants, two readers, and 22 inputs per variant/reader yield 88 calls, including the eight real proof-selected and eight shuffled-context inputs.

| Reader | Original prompt | Instruction/examples/line-format bundle |
| --- | --- | --- |
| Qwen2.5-3B | 2/6; negatives 0/3 | 4/6; negatives 3/3 |
| SmolLM2-1.7B | 1/6; negatives 0/3 | 1/6; negatives 1/3 |

Neither reader passes. The revised prompt fixes Qwen negative controls but still misses the join and is not an isolated test of format alone. Closed-book smoke outputs are all unextractable, so a zero score cannot establish zero memorized knowledge. The immediate decision is to repair/replace and re-calibrate the label reader before collecting a large training set.

<!-- page boundary -->

## 4. Exact follow-up resource and labeling budget

This is one bounded planning scenario beyond the completed pilot, not measured future usage or approval to spend. Scope: 500 training questions, 100 development questions, and 1,000 untouched official test questions. After the failure/method gate, budget three supervision arms: independent utility, ordinary marginal utility, and a candidate correction. The third arm is reserved; its method is not yet established.

### 4.1 Label requests and inference accounting

Per training question/arm: sample five evidence states, compare four insertions at each state, and cache each baseline. This requires 5 x (1 + 4) = 25 reader calls for 20 marginal labels. Two generation seeds cost 50 calls. Three arms x 500 questions x 50 calls = 75,000 calls. Shared caching can reduce actual usage; no savings are assumed. Singleton supervision receives an equal call allocation. By contrast, exhaustive greedy selection of five from 50 costs 1 + 50 + 49 + 48 + 47 + 46 = 241 unique reader states per question/seed before judging.

Four fixed systems plus three learned arms trained with three seeds give 13 configurations. Evaluate each on 100 dev + 1,000 test questions, two readers and two generation seeds: 13 x 1,100 x 2 x 2 = 57,200 calls. Total planned calls: 132,200; a 10% calibration/retry reserve adds 13,220, giving a 145,420-call ceiling. Reference-based scoring needs no paid judge calls. New semantic-judge calls would require a revised budget.

### 4.2 GPU, API, indexing, storage, and annotation

| Resource | Exact planned allocation | Estimated cash (USD) |
| --- | --- | --- |
| GPU/host | 1 RTX A6000 48 GB; 220 GPU-hours | 220 x $0.59 = $129.80 |
| GPU-hour breakdown | Labels 100; evaluation 72; training 36; index 12 | Included above |
| API | 0 paid requests; all readers self-hosted | $0.00 |
| Indexing | 12 GPU-hours + up to 64 vCPU-hours; fixed aligned pools | Included host time |
| Persistent storage | 200 GB network volume x 1 month | $14.00 |
| Container storage | 20 GB x 1 month (conservative allocation) | $2.00 |
| Human annotation | 20 person-hours, project-member labor | $0 cash; 20 h labor |
| Base / 20% financial reserve | $145.80 + $29.16 | $174.96 total |

GPU/host reference: 48 GB VRAM, 50 GB RAM, 9 vCPUs at $0.59/hour on Runpod public pricing, checked 18 Oct 2026. Network storage $0.07/GB/month; running container storage $0.10/GB/month [8,9]. Rates/availability can change. Budget is USD before tax/currency conversion; no rental or paid API has been launched.

The 36 training hours allocate 4 hours to each of nine compact-selector runs. The generation allocation assumes roughly four seconds per request, including a reserve; it is not a throughput guarantee for an unqualified replacement reader. Index time assumes reusing released/prebuilt aligned indexes, not embedding all Wikipedia from scratch. Rebuilds or slower readers trigger a scope/budget amendment rather than hidden costs.

Annotation accounting: 50 failures x 2 humans x 5 minutes + 100 minutes adjudication = 10 hours; 120 claim/support decisions x 2 humans x 2 minutes + 120 minutes adjudication = 10 hours. If paid at an assumed $10/hour, add $200 labor and its 20% reserve: total $414.96. This hourly rate is a planning assumption. Human work has not yet been completed.

<!-- page boundary -->

## 5. Statistical testing and 50-case failure analysis

### 5.1 Confirmatory testing plan

Primary endpoint: per-question grounded answer-claim recall at a shared evidence-token cap (1,280 for the current configuration). Confirm the final scorer, reader, prompt, token cap, utility weights and method before opening confirmation/test results. Report answer recall, citation support, redundancy, contradiction, retrieval recall, tokens, latency and label cost separately. Literal proof overlap is diagnostic; semantic support requires independent validation.

The statistical unit is the question, not a passage, seed or cached output. Average the two generation seeds within a question and report both readers separately. For learned systems, retain three training seeds, report mean/spread, and average seed outcomes within question for the primary paired comparison. Treat reader transfer as a prespecified replication, not an extra sample of questions.

For the candidate versus tuned MMR, the strongest released utility selector, and ordinary marginal training, report paired mean differences, 95% question-bootstrap intervals (10,000 resamples), and a paired sign-flip randomization test (100,000 permutations, two-sided). Use Holm correction over the three primary comparisons at family-wise alpha 0.05. Include ties, disclose invalid outputs, and repeat scores with the frozen strict and structural-extraction policies as a sensitivity analysis.

Before final testing, estimate paired question-level variance on development data and run a simulation-based power check for a 3 percentage-point gain. With 1,000 test questions, a simple unadjusted normal approximation has detectable effect about 2.8 x SD(delta)/sqrt(1,000), approximately 1.8 points if SD(delta)=0.20. This is an illustration, not a power estimate obtained from the eight-question smoke run. If power is inadequate, report uncertainty rather than claim no effect.

### 5.2 Completed qualitative audit and its limits

The accompanying appendix and CSV contain 50 individually reviewed, uncached output records spanning all eight pilot questions, with exact record IDs, question, reader, evidence condition, seed, output, diagnosis and access to selected evidence. Review was performed by the assistant and is explicitly labeled as such. There are zero completed independent human annotations; the 120-row returned blinded annotation sheet is blank. Accordingly, the human-analysis requirement remains pending author/human verification.

| Primary diagnostic category | Reviewed output records |
| --- | --- |
| Format/measurement failure | 25 |
| Placeholder answer | 6 |
| Wrong answer type | 15 |
| Repetition/truncation | 3 |
| Query location constraint | 1 |
| Total; 8 questions, purposive sample | 50 |

Examples: complete film lists rejected by the original parser; a South Africa-based club returned for a London-club question; writer/director names returned instead of movies; repeated placeholders or park names exhausting the token limit. Categories are assigned by the main observable issue; cases may have secondary issues. These counts describe the selected audit sample and cannot estimate population failure prevalence.

Human validation protocol: two reviewers independently inspect the question, rendered evidence and answer while blinded to method identity; mark schema, entity type, all query constraints, support, omission, duplication and uncertainty. Retain corrections, resolve disagreements, and report raw agreement plus Cohen kappa on applicable categorical labels. Do not automatically mark reference-unmatched entities false, especially for the open-ended archivist question.

<!-- page boundary -->

## 6. Training-label plan and decisive next experiment

Keep the Stage 1 insertion/deletion design. First calibrate a fixed reader on direct, conjunctive, multi-hop and abstention controls, then validate a reference-supported sample with humans. Freeze F and weights before large-scale labeling; record separate supported-claim gain, supported-claim loss, citation/support and contradiction components. Repeated seeds expose label instability, and uncertain pairs may be abstained from with their cost recorded. These are proposed safeguards, not established novelty.

The decisive comparison will use the same candidate pools, compact selector, training questions, teacher-call budget and evidence-token budget for independent utility, ordinary marginal utility and the chosen correction. Compare with tuned relevance, dense MMR, deployable coverage selection and a released utility selector. Add the closest feasible RRPO/DynamicRAG-style outcome-reward control where required by the final mechanism; a budgeted adaptation must be labeled as such, not a full reproduction.

## 7. Go/no-go decision, deliverables, and repository

Current decision: continue the project within the original scope, but do not scale the present reader-generated labels or describe a selector as novel. The completed pilot verifies a measurement failure and reader constraint/type failures. It does not yet establish a stable set-selection failure that a new training method fixes. A positive continuation needs a calibrated reader, a repeatable failure beyond strong baselines, and a prespecified equal-cost comparison on held-out questions.

Repository package: report and editable source; Stage 1 report; pilot and calibration code; self-contained Kaggle notebook; frozen manifests/model revisions; returned outputs and original summary; post-run analysis and plans; CPU results; 50-case audit CSV/HTML/PDF; integrity tests; dataset provenance and reproduction instructions. Model weights, large source archives, credentials and third-party paper PDFs are excluded. The author will insert the repository URL and upload the prepared folder.

Maintenance plan: preserve immutable raw runs; commit each experiment configuration and analysis change; append a dated changelog entry and distinguish planned work from measured results. The package has been prepared locally; an uploaded repository and regular future maintenance cannot yet be claimed.

## 8. Key references

[1] RRPO, ACL 2026. https://aclanthology.org/2026.acl-long.1406/

[2] DynamicRAG, NeurIPS 2025. https://arxiv.org/abs/2505.07233

[3] InfoGain-RAG, EMNLP 2025. https://aclanthology.org/2025.emnlp-main.365/

[4] eRAG, SIGIR 2024. https://arxiv.org/abs/2404.13781

[5] Zhang et al. Distilling a Small Utility-Based Passage Selector to Enhance Retrieval-Augmented Generation, SIGIR-AP 2025. https://arxiv.org/abs/2507.19102

[6] QAMPARI official data, code and retrieval caches. https://github.com/samsam3232/qampari

[7] Reader checkpoints: https://huggingface.co/Qwen/Qwen2.5-3B-Instruct ; https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct

[8] Runpod GPU/host pricing, checked 18 October 2026. https://www.runpod.io/pricing

[9] Runpod storage pricing, checked 18 October 2026. https://docs.runpod.io/pods/pricing

<!-- page boundary -->