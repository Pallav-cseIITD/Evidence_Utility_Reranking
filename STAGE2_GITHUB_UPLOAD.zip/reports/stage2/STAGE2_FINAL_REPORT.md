# Evidence Utility Reranking for Grounded Generation

COL764 - Information Retrieval and Web Search

Pallav Kamad | 2023CS51067

Stage 2: Initial Pilot | 18 October 2026

Repository: https://github.com/Pallav-cseIITD/Evidence_Utility_Reranking

### Core research question

Can passages be selected by their marginal contribution to a grounded answer, at a fixed evidence budget, so that more answer claims are supported with less redundancy and contradiction? The original task and frozen top-50 selection setting are retained.

u(d | S, q) = F(S union {d}, q) - F(S, q)

F measures grounded answer quality. The formula and greedy selection are established formulations, not claimed contributions. This Stage 2 report presents the completed pilot, the resulting improvements to measurement and reader calibration, a statistical testing plan, and a defined resource allocation.

## 1. Primary hypothesis and research approach

### 1.1 Hypothesis carried forward from Stage 1

The project tests whether a compact selector trained on measured changes in grounded answer quality chooses stronger evidence than independent relevance or diversity alone. Stage 2 establishes the experimental foundation: frozen candidate pools, reproducible reader outputs, corrected scoring, and controlled tests of label reliability.

### 1.2 Response to the novelty feedback

RRPO already uses generation-quality rewards for successive selected sets; DynamicRAG optimizes retrieval decisions with downstream feedback; InfoGain-RAG studies information-gain-based selection; eRAG evaluates retrieval through document-conditioned downstream performance. UtilityQwen distills utility judgments into compact selectors. Therefore, downstream QA rewards, set conditioning, and teacher distillation are insufficient novelty claims [1-5].

The experimental approach separates evidence quality from reader reliability. Controlled passage insertions measure the contribution of a candidate to the current set. Calibration and component-level scoring prevent formatting errors, unsupported answers, or reader failures from being mistaken for useful training signals. The comparison holds training data, labeling calls, model size, and evidence budget constant.

### 1.3 Coverage diagnostic

Reference-aware coverage provides a diagnostic of the evidence available in each candidate pool. It measures selection headroom and identifies missing support. Deployable methods are evaluated separately, without access to gold answers or reference evidence.

## 2. Benchmark, split plan, and completed pilot

### 2.1 Data preparation and scope

The pilot uses the official QAMPARI development release and its natural BM25 and DPR retrieval caches. Reciprocal-rank fusion (constant 60) produces a frozen top-50 pool. Sparse and dense document IDs are namespaced; only exact normalized title/text duplicates are merged. Corpus-snapshot alignment is not independently verified, so these are cached-retrieval diagnostics, not a completed new indexing experiment [6].

A deterministic hash sample fixes 200 questions: 100 discovery and 100 confirmation. CPU diagnostics cover the 100 discovery questions. GPU smoke tests use only the first eight discovery questions. Confirmation outcomes and the official test split remain unused. This staged design covers 100 questions for retrieval diagnostics and eight questions for detailed reader analysis.

### 2.2 CPU evidence-coverage diagnostic: 100 questions

| Selection, k=5 | Answer-alias coverage | Exact proof-span coverage |
| --- | --- | --- |
| Fused retrieval top-5 | 20.05% | 6.70% |
| Lexical MMR, weight 0.5 | 17.75% | 5.01% |
| Gold-aware alias greedy* | 48.99% | 13.66% |
| Gold-aware proof greedy* | 30.52% | 21.37% |
| All 50 passages (context only) | 51.29% | 21.94% |

* Diagnostic uses reference information, unavailable to a deployable selector. Five passages are matched in count, not exact tokens. Alias appearance does not prove the requested relation; literal proof matching misses valid alternative evidence.

Gold-aware proof selection exceeds fused top-5 literal proof coverage by 14.67 percentage points (question-bootstrap 95% interval: 11.11 to 18.42). This demonstrates proxy headroom in the candidate pool, not an improvement in generated answers. Greedy selection attains the exact optimum of the alias-coverage proxy on 99/100 questions, further limiting claims that greedy optimization itself is new.

### 2.3 Completed Kaggle smoke run

The returned ir_run1 artifact contains 384 logical records: 8 questions x 12 conditions x 2 readers x 2 generation seeds. Caching reduces this to 348 actual generation calls. Both readers see the same selected evidence. Qwen2.5-3B-Instruct and SmolLM2-1.7B-Instruct run sequentially on one Tesla T4; the notebook allocation exposes two T4s but the code uses GPU 0.

Conditions include fusion, MiniLM cross-encoder relevance, dense MMR weights 0.2/0.5/0.8, two reference aware coverage diagnostics, a two-passage base and two three-passage insertions, closed-book and shuffled-context controls. Evidence is capped at 1,280 tokens under both tokenizers (maximum logged: 895). The run used 250,840 input and 23,124 output tokens; summed generation time was 778.14 seconds, excluding loading and other session overhead.

## 3. Pilot findings and verified corrections

### 3.1 Separating format failure from answer failure

The original parser requires an answers object. Complete answer lists and otherwise complete objects followed by punctuation were rejected and scored as empty. For example, Qwen returns all five reference film names for the Baz Luhrmann/Craig Pearce question in a JSON list; the original strict scorer assigns zero. This is a measurement defect, not evidence that those answers were absent.

| Reader, 192 records each | Strict schema valid | Content extractable* |
| --- | --- | --- |
| Qwen2.5-3B | 107/192 (55.73%) | 174/192 (90.63%) |
| SmolLM2-1.7B | 34/192 (17.71%) | 160/192 (83.33%) |

A documented post run sensitivity analysis extracts complete typed JSON objects/lists without altering names, adding citations, repairing truncated JSON, or joining ambiguous multiple values. Original strict scores are preserved. Unextractable outputs remain zero in all-output metrics and are separately flagged. This correction improves measurement; it is not a selector improvement.

### 3.2 Exploratory answer results: eight questions only

| Selection | Qwen recall / attributed | Smol recall / attributed |
| --- | --- | --- |
| Fusion top-5 | 17.50% / 11.25% | 16.25% / 10.00% |
| Cross-encoder relevance | 7.50% / 6.25% | 11.25% / 6.88% |
| Dense MMR, weight 0.5 | 7.50% / 3.75% | 11.25% / 8.13% |
| Gold-aware proof diagnostic | 20.63% / 16.88% | 18.75% / 12.50% |

Macro reference-answer recall; attributed recall additionally requires an exact annotated proof in the cited evidence. Two seeds averaged within question; unextractable outputs score zero. All figures are exploratory post run extraction sensitivity, not a significance result. Exact-proof attribution is a conservative proxy, not human-validated entailment.

### 3.3 Follow-up reader calibration: 88 additional calls

Six handcrafted controls test direct answers, five-item enumeration, a two-step join, and three no answer cases (irrelevant evidence, partial constraint, missing bridge). The gate was set before these runs: at least 5/6 exact answer-and-citation passes and all three negative controls. Two prompt variants, two readers, and 22 inputs per variant/reader yield 88 calls, including the eight real proof-selected and eight shuffled-context inputs.

| Reader | Original prompt | Instruction/examples/line-format bundle |
| --- | --- | --- |
| Qwen2.5-3B | 2/6; negatives 0/3 | 4/6; negatives 3/3 |
| SmolLM2-1.7B | 1/6; negatives 0/3 | 1/6; negatives 1/3 |

Neither reader passes. The revised prompt fixes Qwen negative controls but still misses the join and is not an isolated test of format alone. Closed-book smoke outputs are all unextractable, so a zero score cannot establish zero memorized knowledge. The immediate decision is to repair/replace and re-calibrate the label reader before collecting a large training set.

## 4. Follow-up resource allocation

The following allocation supports the experimental programme beyond the completed pilot. Scope: 500 training questions, 100 development questions, and 1,000 untouched official test questions. After the failure/method gate, budget three supervision arms: independent utility, ordinary marginal utility, and a candidate correction. The third arm tests the label correction selected through the controlled failure analysis.

### 4.1 Label requests and inference accounting

Per training question/arm: sample five evidence states, compare four insertions at each state, and cache each baseline. This requires 5 x (1 + 4) = 25 reader calls for 20 marginal labels. Two generation seeds cost 50 calls. Three arms x 500 questions x 50 calls = 75,000 calls. Shared caching can reduce actual usage; no savings are assumed. Singleton supervision receives an equal call allocation. By contrast, exhaustive greedy selection of five from 50 costs 1 + 50 + 49 + 48 + 47 + 46 = 241 unique reader states per question/seed before judging.

Four fixed systems plus three learned arms trained with three seeds give 13 configurations. Evaluate each on 100 dev + 1,000 test questions, two readers and two generation seeds: 13 x 1,100 x 2 x 2 = 57,200 calls. Total planned calls: 132,200; a 10% calibration/retry reserve adds 13,220, giving a 145,420-call ceiling. Reference-based scoring requires no external judge calls. Any additional semantic judging will be included in the inference allocation.

### 4.2 GPU, API, indexing, storage, and annotation

| Resource | Required allocation |
| --- | --- |
| GPU and host | One RTX A6000 with 48 GB VRAM, 50 GB system RAM and 9 vCPUs; 220 GPU-hours |
| GPU-hour allocation | Label collection: 100 hours; evaluation: 72 hours; selector training: 36 hours; indexing: 12 hours |
| API | No external API calls; all readers run locally on the allocated GPU |
| Indexing | 12 GPU-hours and up to 64 vCPU-hours for fixed, aligned candidate pools; included in the host allocation |
| Persistent storage | 200 GB for one month |
| Container storage | 20 GB for one month |
| Human annotation | 20 person-hours for independent review and adjudication |

The 36 training hours allocate 4 hours to each of nine compact-selector runs. The generation allocation assumes roughly four seconds per request, including a reserve; it is not a throughput guarantee for an unqualified replacement reader. Index time assumes reusing released/prebuilt aligned indexes, not embedding all Wikipedia from scratch. Rebuilds or slower readers trigger a scope/budget amendment rather than hidden costs.

Annotation allocation: 50 failures x 2 reviewers x 5 minutes, plus 100 minutes for adjudication, requires 10 person-hours. A further 120 claim/support decisions x 2 reviewers x 2 minutes, plus 120 minutes for adjudication, requires 10 person-hours. The total allocation is 20 person-hours of independent human review.

## 5. Statistical testing and 50-case failure analysis

### 5.1 Confirmatory testing plan

Primary endpoint: per-question grounded answer-claim recall at a shared evidence-token cap (1,280 for the current configuration). Confirm the final scorer, reader, prompt, token cap, utility weights and method before opening confirmation/test results. Report answer recall, citation support, redundancy, contradiction, retrieval recall, tokens, latency and label cost separately. Literal proof overlap is diagnostic; semantic support requires independent validation.

The statistical unit is the question, not a passage, seed or cached output. Average the two generation seeds within a question and report both readers separately. For learned systems, retain three training seeds, report mean/spread, and average seed outcomes within question for the primary paired comparison. Treat reader transfer as a prespecified replication, not an extra sample of questions.

For the candidate versus tuned MMR, the strongest released utility selector, and ordinary marginal training, report paired mean differences, 95% question-bootstrap intervals (10,000 resamples), and a paired sign-flip randomization test (100,000 permutations, two-sided). Use Holm correction over the three primary comparisons at family-wise alpha 0.05. Include ties, disclose invalid outputs, and repeat scores with the frozen strict and structural-extraction policies as a sensitivity analysis.

Before final testing, estimate paired question level variance on development data and run a simulation-based power check for a 3 percentage-point gain. With 1,000 test questions, a simple unadjusted normal approximation has detectable effect about 2.8 x SD(delta)/sqrt(1,000), approximately 1.8 points if SD(delta)=0.20. This is an illustration, not a power estimate obtained from the eight-question smoke run. If power is inadequate, report uncertainty rather than claim no effect.

### 5.2 Qualitative analysis of 50 failures

Appendix A presents 50 individually examined, uncached outputs from all eight pilot questions. Each case records the question, reader, evidence condition, seed, observed output and diagnosis. The companion CSV includes exact record IDs and selected evidence. Independent human validation is included in the annotation plan in Section 4.

| Primary diagnostic category | Reviewed output records |
| --- | --- |
| Format/measurement failure | 25 |
| Placeholder answer | 6 |
| Wrong answer type | 15 |
| Repetition/truncation | 3 |
| Query location constraint | 1 |
| Total; 8 questions, purposive sample | 50 |

Examples: complete film lists rejected by the original parser; a South Africa-based club returned for a London-club question; writer/director names returned instead of movies; repeated placeholders or park names exhausting the token limit. Categories are assigned by the main observable issue; cases may have secondary issues. These counts describe the selected audit sample and cannot estimate population failure prevalence.

Human validation protocol: two reviewers independently inspect the question, rendered evidence and answer while blinded to method identity; mark schema, entity type, all query constraints, support, omission, duplication and uncertainty. Retain corrections, resolve disagreements, and report raw agreement plus Cohen kappa on applicable categorical labels. Do not automatically mark reference-unmatched entities false, especially for the open-ended archivist question.

## 6. Training-label plan and decisive next experiment

Keep the Stage 1 insertion/deletion design. First calibrate a fixed reader on direct, conjunctive, multi-hop and abstention controls, then validate a reference-supported sample with humans. Freeze F and weights before large-scale labeling; record separate supported-claim gain, supported-claim loss, citation/support and contradiction components. Repeated seeds expose label instability, and uncertain pairs may be abstained from with their cost recorded. Each safeguard will be evaluated through a separate ablation.

The decisive comparison will use the same candidate pools, compact selector, training questions, teacher-call budget and evidence-token budget for independent utility, ordinary marginal utility and the chosen correction. Compare with tuned relevance, dense MMR, deployable coverage selection and a released utility selector. Add the closest feasible RRPO/DynamicRAG-style outcome-reward control where required by the final mechanism; a budgeted adaptation must be labeled as such, not a full reproduction.

## 7. Pilot conclusions, deliverables, and repository

The pilot establishes three concrete outcomes. First, the candidate pools contain substantial coverage headroom. Second, scoring must separate serialization failures from answer content. Third, compact readers require explicit tests of query constraints, evidence support and abstention before their outputs become training labels. The next phase applies these findings to reliable marginal supervision and compares selectors under the same evidence and labeling budgets.

The repository contains the Stage 1 and Stage 2 reports, pilot and calibration code, the Kaggle notebook, frozen manifests and model revisions, saved reader outputs, scoring analysis, CPU results, the 50-case audit, integrity tests, data provenance and reproduction instructions. Large source archives and model weights are retrieved from their original releases.

Repository maintenance follows a simple protocol: preserve original run outputs, commit each experiment configuration and analysis change, and record substantive updates in the dated changelog. Planned experiments and measured results are documented separately.

## 8. Key references

[1] RRPO, ACL 2026. https://aclanthology.org/2026.acl-long.1406/

[2] DynamicRAG, NeurIPS 2025. https://arxiv.org/abs/2505.07233

[3] InfoGain-RAG, EMNLP 2025. https://aclanthology.org/2025.emnlp-main.365/

[4] eRAG, SIGIR 2024. https://arxiv.org/abs/2404.13781

[5] Zhang et al. Distilling a Small Utility-Based Passage Selector to Enhance Retrieval-Augmented Generation, SIGIR-AP 2025. https://arxiv.org/abs/2507.19102

[6] QAMPARI official data, code and retrieval caches. https://github.com/samsam3232/qampari

[7] Reader checkpoints: https://huggingface.co/Qwen/Qwen2.5-3B-Instruct ; https://huggingface.co/HuggingFaceTB/SmolLM2-1.7B-Instruct

## Appendix A. Fifty reviewed failure cases

Independent human validation is budgeted separately. The cases represent 50 uncached outputs across eight questions, rather than 50 independent questions.

### F01 | format / measurement

Which club that plays in premier league stadiums is found in London?
Qwen 3B; seed 17
fusion top5

Output: [{"answer":"Chelsea","citations":["D01","D02"]}]

Chelsea is present in a complete JSON list. The missing answers wrapper made the strict scorer report no answers; this is a format failure, not demonstrated abstention.

### F02 | format / measurement

Which club that plays in premier league stadiums is found in London?
Qwen 3B; seed 17
reference alias greedy (diagnostic)

Output: {"answers":[{"answer":"Chelsea","citations":["D01","D16"]}]}"

The complete Chelsea answer object is followed by a stray quote. Strict JSON rejection erased the answer; semantic correctness is a separate question.

### F03 | format / measurement

Which club that plays in premier league stadiums is found in London?
Qwen 3B; seed 17
probe base2

Output: [{"answer":"West Ham United F.C.","citations":["D09"]}, {"answer":"Tottenham Hotspur F.C.","citations":["D29"]}]}

A complete list names West Ham and Tottenham, followed by an extra closing brace. The original scorer loses both entries because of the wrapper/suffix.

### F04 | format / measurement

S. A. Rajkumar composed the music for which film directed by S. Narayan?
Qwen 3B; seed 29
fusion top5

Output: {"answers":[{"answer":"Thayiya Madilu","citations":["D01"]}]}"

Thayiya Madilu has a citation, but a trailing quote invalidates strict JSON. The zero score cannot be read as an empty response.

### F05 | format / measurement

S. A. Rajkumar composed the music for which film directed by S. Narayan?
Qwen 3B; seed 17
dense mmr 0.2

Output: {"answers":[{"answer":"Sevanthi Sevanthi","citations":["D03"]}]}"

Sevanthi Sevanthi is returned with D03, followed by an unmatched quote. This case isolates suffix formatting from answer extraction.

### F06 | format / measurement

S. A. Rajkumar composed the music for which film directed by S. Narayan?
Qwen 3B; seed 17
reference alias greedy (diagnostic)

Output: {"answers":[{"answer":"Thayiya Madilu","citations":["D01"]}]}"

The diagnostic selector output contains Thayiya Madilu and D01 but ends with a quote. An reference aware selection does not prevent the scoring failure.

### F07 | format / measurement

S. A. Rajkumar composed the music for which film directed by S. Narayan?
Qwen 3B; seed 17
probe add diverse3

Output: {"answers":[{"answer":"Sevanthi Sevanthi","citations":["D03"]}]}"

After the diversity insertion, Sevanthi Sevanthi is still present, but a trailing quote causes strict rejection. Do not infer a claim loss from that rejection.

### F08 | format / measurement

Who was an archivist ?
Qwen 3B; seed 17
dense mmr 0.2

Output: {"answers":[{"answer":"Francis Palgrave","citations":["D34"]},{"answer":"Allen Weinstein","citations":["D08"]}]}"

Palgrave and Weinstein appear in a complete cited object with a trailing quote. Reference-unmatched archivists are not automatically factual errors.

### F09 | format / measurement

Who was an archivist ?
Qwen 3B; seed 17
dense mmr 0.5

Output: [{"answer":"Allen Weinstein","citations":["D08"]}, {"answer":"Taronda Spencer","citations":["D33"]}, {"answer":"Francis Palgrave","citations":["D34"]}, {"answer":"Charles Samaran","citations":["D43", "D49"]}]

Four named archivists are returned as a JSON list rather than an answers object. This is a schema failure; the names need separate support validation.

### F10 | format / measurement

Who was an archivist ?
Qwen 3B; seed 29
reference alias greedy (diagnostic)

Output: {"answers":[{"answer":"Roberta Spire","citations":["D02"]},{"answer":"Ernst Posner","citations":["D35"]}]}"

Roberta Spire and Ernst Posner remain extractable before a stray quote. The format issue is established; reference incompleteness remains possible.

### F11 | format / measurement

A member of The Cars had what educational place?
Qwen 3B; seed 29
dense mmr 0.8

Output: {"answers":[{"answer":"Antioch College","citations":["D26"]}]}"

Antioch College is present with D26, followed by a quote. This audit records the format failure without asserting that the educational relation is correct.

### F12 | format / measurement

Baz Luhrmann directed and Craig Pearce screen wrote what movie?
Qwen 3B; seed 17
fusion top5

Output: [{"answer":"Strictly Ballroom","citations":["D03"]}, {"answer":"Romeo + Juliet","citations":["D01"]}, {"answer":"Moulin Rouge!","citations":["D01"]}, {"answer":"The Great Gatsby","citations":["D01"]}, {"answer":"Elvis","citations":["D05"]}]

All five reference film names are in a complete list. The strict object-only parser nevertheless gives zero, showing a material measurement failure.

### F13 | format / measurement

Baz Luhrmann directed and Craig Pearce screen wrote what movie?
Qwen 3B; seed 17
relevance ce top5

Output: [{"answer":"Elvis","citations":["D05"]}]

Elvis is returned in a list instead of the required object. The narrower answer set may be incomplete, but this entry only establishes schema rejection.

### F14 | format / measurement

Baz Luhrmann directed and Craig Pearce screen wrote what movie?
Qwen 3B; seed 17
dense mmr 0.5

Output: {"answers":[{"answer":"Moulin Rouge!","citations":["D13"]}]}"

Moulin Rouge! is returned with D13 followed by a stray quote. A formatting error should not be scored as genuine abstention.

### F15 | format / measurement

Baz Luhrmann directed and Craig Pearce screen wrote what movie?
Qwen 3B; seed 17
reference proof greedy (diagnostic)

Output: [{"answer":"Strictly Ballroom","citations":["D02"]}, {"answer":"Romeo + Juliet","citations":["D21"]}, {"answer":"Moulin Rouge!","citations":["D01"]}, {"answer":"The Great Gatsby","citations":["D01"]}, {"answer":"Elvis","citations":["D05"]}]

The proof-based diagnostic returns all five film names as a list. The strict scorer rejects the container despite retaining usable answer content.

### F16 | format / measurement

Baz Luhrmann directed and Craig Pearce screen wrote what movie?
Qwen 3B; seed 29
probe add ce3

Output: {"answers":[{"answer":"Elvis","citations":["D05"]},{"answer":"Romeo + Juliet","citations":["D21"]}]}"

Elvis and Romeo + Juliet are present before a trailing quote. Strict parsing would hide both after insertion; this is not evidence of reader abstention.

### F17 | format / measurement

Baz Luhrmann directed and Craig Pearce screen wrote what movie?
Qwen 3B; seed 17
probe add diverse3

Output: [{"answer":"Moulin Rouge!","citations":["D01"]}]

Moulin Rouge! is returned in a bare JSON list. The format contract fails; the causal benefit of the inserted passage remains unestablished.

### F18 | format / measurement

What work of art was created by artist Fred Barron?
Qwen 3B; seed 17
relevance ce top5

Output: {"answers":[{"answer":"watercolours","citations":["D29"]},{"answer":"digital matte art work","citations":["D39"]}]}"

The cited watercolours/digital-art output ends with a quote. Format failure is certain; the Fred Barron entity ambiguity requires separate semantic review.

### F19 | format / measurement

What work of art was created by artist Fred Barron?
Qwen 3B; seed 17
dense mmr 0.5

Output: {"answers":[{"answer":"watercolours","citations":["D29"]}]}"

The watercolours object ends with a quote. This is a measurement case, not a claim that the generated work satisfies the intended Fred Barron relation.

### F20 | format / measurement

Which of the Welsh principal areas is a county borough?
Qwen 3B; seed 17
dense mmr 0.2

Output: {"answers":[{"answer":"Wrexham County Borough","citations":["D19"]}]}"

Wrexham County Borough is returned before a stray quote. Strict parsing suppresses an explicit answer instead of flagging format failure separately.

### F21 | format / measurement

Which of the Welsh principal areas is a county borough?
Qwen 3B; seed 17
probe base2

Output: [{"answer":"Conwy County Borough","citations":["D19"]}]

Conwy County Borough appears in a bare list. The container mismatch is observable independently of benchmark alias matching.

### F22 | format / measurement

Which of the Welsh principal areas is a county borough?
Qwen 3B; seed 17
probe add ce3

Output: {"answers":[{"answer":"Neath Port Talbot","citations":["D03"]}]}"

Neath Port Talbot is present in a complete object with a trailing quote. The original zero is a parser outcome, not an empty answer list.

### F23 | format / measurement

What are the protected areas with an area larger than 250000 km squared ?
Qwen 3B; seed 17
dense mmr 0.2

Output: [{"answer":"Islands Protected Area","citations":["D06"]}]

Islands Protected Area is in a bare list. This case establishes schema failure only; the size threshold and identity need independent evidence checking.

### F24 | format / measurement

What are the protected areas with an area larger than 250000 km squared ?
Qwen 3B; seed 17
probe add ce3

Output: [{"answer":"Convention for the Conservation of Antarctic Marine Living Resources","citations":["D06"]}]

A convention title is returned in a bare list. Besides the format failure, a treaty title is not itself the requested protected area.

### F25 | format / measurement

What are the protected areas with an area larger than 250000 km squared ?
Qwen 3B; seed 17
probe add diverse3

Output: [{"answer":"Transboundary Protected Areas","citations":["D47"]}]

Transboundary Protected Areas is in a bare list. It is also a generic category rather than one clearly identified qualifying protected area.

### F26 | placeholder answer

Who was an archivist ?
Qwen 3B; seed 17
relevance ce top5

Output: {"answers":[{"answer":"Example entity","citations":["D01"]}]}

Example entity is a template placeholder, not a named archivist. Valid JSON and a passage ID do not make this a supported answer.

### F27 | placeholder answer

Who was an archivist ?
Qwen 3B; seed 17
probe base2

Output: {"answers":[{"answer":"Example entity","citations":["D01","D43"]}]}

The two-passage state yields Example entity with two citations. Extra citations do not repair a placeholder answer.

### F28 | placeholder answer

Who was an archivist ?
Qwen 3B; seed 17
probe add ce3

Output: {"answers":[{"answer":"Example entity","citations":["D01","D43"]}]}

After relevance insertion, the reader still emits Example entity. The label would reflect reader failure rather than useful evidence coverage.

### F29 | placeholder answer

Who was an archivist ?
Qwen 3B; seed 29
probe add diverse3

Output: {"answers":[{"answer":"Example entity","citations":["D01"]}]}

After diversity insertion, Example entity remains the sole answer. This is a separate generated record, not a distinct question or independent failure type.

### F30 | placeholder answer

A member of The Cars had what educational place?
SmolLM2 1.7B; seed 17
relevance ce top5

Output: {"answers":[{"answer":"Example entity","citations":["D01"]}]}. Include every supported answer without duplicates.

Example entity is returned instead of an educational institution. There is also trailing instruction text; content extraction cannot repair placeholder semantics.

### F31 | repetition / truncation

A member of The Cars had what educational place?
SmolLM2 1.7B; seed 17
dense mmr 0.2

Output: {"answers":[{"answer":"Example entity","citations":["D11"]},{"answer":"Example entity","citations":["D17"]},{"answer":"Example entity","citations":["D19"]},{"answer":"Example entity","citations":["D26"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29"]},{"answer":"Example entity","citations":["D29

Example entity repeats until the 512-token limit and leaves incomplete JSON. Neither structural extraction nor extra context recovers a valid answer.

### F32 | placeholder answer

A member of The Cars had what educational place?
SmolLM2 1.7B; seed 17
reference alias greedy (diagnostic)

Output: {"answers":[{"answer":"Example entity","citations":["D01"]},{"answer":"Example entity","citations":["D02"]},{"answer":"Example entity","citations":["D03"]},{"answer":"Example entity","citations":["D04"]}]}.

Four cited Example entity entries replace educational places. The reference aware evidence set does not remove this reader failure.

### F33 | query constraint / location

Which club that plays in premier league stadiums is found in London?
SmolLM2 1.7B; seed 17
fusion top5

Output: {"answers":[{"answer":"Reading Town Football Club","citations":["D03"]},{"answer":"Chippa United F.C.","citations":["D05"]}]}. Include every supported answer without duplicates.

Chippa United is explicitly based in South Africa in D05, and Reading Town is in Reading in D03. Neither satisfies the requested London club condition.

### F34 | wrong answer type

Which club that plays in premier league stadiums is found in London?
SmolLM2 1.7B; seed 17
relevance ce top5

Output: {"answers":[{"answer":"Chelsea","citations":["D01"]},{"answer":"Tottenham Hotspur","citations":["D29"]},{"answer":"West Ham United","citations":["D09"]},{"answer":"London","citations":["D01","D16"]}]}.

London is included as an answer although the question requests a club. Other club entries may be valid; this audit does not mark the entire response false.

### F35 | wrong answer type

Which club that plays in premier league stadiums is found in London?
SmolLM2 1.7B; seed 17
dense mmr 0.2

Output: {"answers":[{"answer":"Arsenal","citations":["D02"]},{"answer":"Aston Villa","citations":["D02"]},{"answer":"Brentford","citations":["D05"]},{"answer":"Chippa United F.C.","citations":["D07"]},{"answer":"Chippa","citations":["D07"]},{"answer":"Chelsea","citations":["D02"]},{"answer":"Everton","citations":["D02"]},{"answer":"Fulham","citations":["D02"]},{"answer":"Gary Lineker","citations":["D09"]},{"answer":"Haringey Hornets","citations":["D07"]},{"answer":"Haringey Mbekweni Cosmos","citations":["D05"]},{"answer":"Liverpool","citations":["D02"]},{"answer":"Manchester City","citations":["D02"]},{"answer":"Manchester United","citations":["D02"]},{"answer":"Newcastle United","citations":["D02"]},{"answer":"Norwich City","citations":["D02"]},{"answer":"Ole Gunnar Solskjær","citations":["D09"]},{"answer":"Premier League","citations":["D02"]},{"answer":"Rugby League","citations":["D07"]},{"answer":"Swansea City","citations":["D05"]},{"answer":"Tottenham Hotspur","citations":["D02"]},{"answer":"Watford","citations":["D02"]},{"answer":"West Ham United F.C.","citations":["D02"]}]}.

Gary Lineker is a person, not a club; the response also mixes leagues and locations. This is an answer-type/constraint failure, beyond JSON formatting.

### F36 | wrong answer type

Which club that plays in premier league stadiums is found in London?
SmolLM2 1.7B; seed 17
reference alias greedy (diagnostic)

Output: {"answers":[{"answer":"Brentford F.C.","citations":["D16","D17"]},{"answer":"Chelsea Football Club","citations":["D01"]},{"answer":"Fulham F.C.","citations":["D16","D17"]},{"answer":"London","citations":["D01","D16"]},{"answer":"Queens Park Rangers","citations":["D01"]},{"answer":"Stamford Bridge","citations":["D01"]}]}.

London and Stamford Bridge are included among club names. They are a city and a stadium, so the answer type is not enforced.

### F37 | wrong answer type

Which club that plays in premier league stadiums is found in London?
SmolLM2 1.7B; seed 17
reference proof greedy (diagnostic)

Output: {"answers":[{"answer":"Stamford Bridge","citations":["D01"]},{"answer":"Premier League","citations":["D02"]},{"answer":"West Ham United F.C.","citations":["D09"]},{"answer":"Brentford F.C.","citations":["D17"]},{"answer":"Tottenham Hotspur F.C.","citations":["D29"]}]}.

Stamford Bridge and Premier League are returned as clubs. D01 identifies the former as a stadium; the latter is a league.

### F38 | wrong answer type

Which club that plays in premier league stadiums is found in London?
SmolLM2 1.7B; seed 17
probe add ce3

Output: {"answers":[{"answer":"Stamford Bridge","citations":["D01"]},{"answer":"Tottenham Hotspur F.C.","citations":["D29"]},{"answer":"West Ham United F.C.","citations":["D09"]}]}.

The inserted stadium passage causes Stamford Bridge to appear as an answer. A relevant passage can supply the wrong answer type to this reader.

### F39 | wrong answer type

S. A. Rajkumar composed the music for which film directed by S. Narayan?
SmolLM2 1.7B; seed 17
relevance ce top5

Output: {"answers":[{"answer":"Thayiya Madilu","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"Sevanthi Sevanthi","citations":["D03"]},{"answer":"S. A. Rajkumar","citations":["D03"]},{"answer":"Thavarina Thottilu","citations":["D12"]},{"answer":"Navakoti Narayana","citations":["D17"]},{"answer":"S. A. Rajkumar","citations":["D12"]},{"answer":"S. A. Rajkumar","citations":["D13"]},{"answer":"Sevanthi Sevanthi","citations":["D12"]},{"answer":"Thavarina Thottilu","citations":["D12"]},{"answer":"S. A. Rajkumar","citations":["D13"]},{"answer":"S. A. Rajkumar","citations":["D17"]}]}.

S. A. Rajkumar is repeated as an answer to a film question. Citing the composer biography does not satisfy the requested film entity type.

### F40 | wrong answer type

S. A. Rajkumar composed the music for which film directed by S. Narayan?
SmolLM2 1.7B; seed 17
dense mmr 0.2

Output: {"answers":[{"answer":"S. A. Rajkumar","citations":["D03","D27"]},{"answer":"S. A. Rajkumar","citations":["D09","D25"]}]}.

Both answer entries name S. A. Rajkumar rather than films. The model copies the constraint entity instead of finding entities satisfying the relation.

### F41 | repetition / truncation

S. A. Rajkumar composed the music for which film directed by S. Narayan?
SmolLM2 1.7B; seed 17
dense mmr 0.8

Output: {"answers":[{"answer":"Thayiya Madilu","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajkumar","citations":["D01"]},{"answer":"S. A. Rajk

S. A. Rajkumar repeats after an initial film until generation is truncated. This combines wrong entity type, duplication, and incomplete serialization.

### F42 | wrong answer type

Who was an archivist ?
SmolLM2 1.7B; seed 17
dense mmr 0.8

Output: {"answers":[{"answer":"Charles Piot","citations":["D21"]},{"answer":"Archivist of the United States","citations":["D30"]},{"answer":"The Archivist","citations":["D43"]}]}.

Archivist of the United States and The Archivist are returned alongside a person. An office/title is not a named person answering who; Charles Piot is not rejected.

### F43 | wrong answer type

Who was an archivist ?
SmolLM2 1.7B; seed 17
probe base2

Output: {"answers":[{"answer":"List of archivists","citations":["D01"]},{"answer":"Archivist (disambiguation)","citations":["D43"]}]}.

List of archivists and Archivist (disambiguation) are page titles, not individual people. The reader copies retrieved titles instead of extracting people.

### F44 | wrong answer type

A member of The Cars had what educational place?
SmolLM2 1.7B; seed 17
fusion top5

Output: {"answers":[{"answer":"Ric Ocasek","citations":["D01"]},{"answer":"Benjamin Orr","citations":["D01"]},{"answer":"Jonathan Richman","citations":["D01"]},{"answer":"Greg Hawkes","citations":["D02"]},{"answer":"Richard and the Rabbits","citations":["D02"]},{"answer":"The Cars","citations":["D03"]}]}.

The output lists Ric Ocasek, Benjamin Orr and band names instead of educational institutions. Some citations point to unrelated passages as well.

### F45 | wrong answer type

A member of The Cars had what educational place?
SmolLM2 1.7B; seed 17
dense mmr 0.5

Output: {"answers":[{"answer":"MIT","citations":["D06"]},{"answer":"Boston University School of Management","citations":["D06"]},{"answer":"University of Texas","citations":["D17"]},{"answer":"Santa Rosa Rancheria","citations":["D19"]},{"answer":"Tachi Yokuts dialect","citations":["D26"]},{"answer":"Ric Ocasek","citations":["D29"]},{"answer":"Emile Buffon","citations":["D29"]},{"answer":"Assassination of Emile Buffon","citations":["D29"]},{"answer":"Chateau de la Motte","citations":["D29"]},{"answer":"Nervasport","citations":["D29"]},{"answer":"Cars","citations":["D29"]}]}.

The response mixes institutions with Ric Ocasek, a dialect, a car model and an assassination. Only the demonstrably wrong entity types are flagged here.

### F46 | wrong answer type

Baz Luhrmann directed and Craig Pearce screen wrote what movie?
SmolLM2 1.7B; seed 17
fusion top5

Output: {"answers":[{"answer":"Craig Pearce","citations":["D01","D02"]},{"answer":"Baz Luhrmann","citations":["D01","D02"]},{"answer":"Strictly Ballroom","citations":["D01"]},{"answer":"Moulin Rouge!", "citations":["D01"]},{"answer":"Romeo + Juliet","citations":["D01"]},{"answer":"The Great Gatsby","citations":["D01"]},{"answer":"The Seventh Floor","citations":["D01"]},{"answer":"Elvis","citations":["D05"]}]}.

Craig Pearce and Baz Luhrmann are included as movie answers. Valid film entries elsewhere in the response do not justify these person entries.

### F47 | wrong answer type

Baz Luhrmann directed and Craig Pearce screen wrote what movie?
SmolLM2 1.7B; seed 17
relevance ce top5

Output: {"answers":[{"answer":"Craig Pearce","citations":["D01","D02"]},{"answer":"Baz Luhrmann","citations":["D01","D02"]},{"answer":"Romeo + Juliet","citations":["D01","D02"]}]}.

The response again includes the writer and director as movie names. The question constraints are being copied as answers.

### F48 | wrong answer type

What work of art was created by artist Fred Barron?
SmolLM2 1.7B; seed 17
fusion top5

Output: {"answers":[{"answer":"Fred Barron","citations":["D01"]},{"answer":"James Clover","citations":["D01","D02"]},{"answer":"Harris Barron","citations":["D01","D02"]},{"answer":"Stéphan Barron","citations":["D05"]}]}.

Fred Barron, James Clover, Harris Barron and Stephan Barron are people, not works of art. The response fails the requested output type.

### F49 | wrong answer type

Which of the Welsh principal areas is a county borough?
SmolLM2 1.7B; seed 17
relevance ce top5

Output: {"answers":[{"answer":"Neath Port Talbot","citations":["D03"]},{"answer":"County borough","citations":["D11"]},{"answer":"North Wales","citations":["D19"]},{"answer":"Counties of the United Kingdom","citations":["D31"]},{"answer":"Caerphilly County Borough Council","citations":["D46"]}]}.

County borough, North Wales, and Counties of the United Kingdom are included as principal areas. The response mixes categories, region and governing body.

### F50 | repetition / truncation

What are the protected areas with an area larger than 250000 km squared ?
SmolLM2 1.7B; seed 17
relevance ce top5

Output: {"answers":[{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Pacific Remote Islands Marine National Monument","citations":["D34"]},{"answer":"Coral Sea Commonwealth Marine Reserve","citations":["D34"]},{"answer":"South Georgia and the South Sandwich Islands Marine Protected Area","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea","citations":["D34"]},{"answer":"Natural Park of the Coral Sea

Natural Park of the Coral Sea is repeated until the token limit, leaving incomplete JSON. This audit does not reject that park as a valid protected area.