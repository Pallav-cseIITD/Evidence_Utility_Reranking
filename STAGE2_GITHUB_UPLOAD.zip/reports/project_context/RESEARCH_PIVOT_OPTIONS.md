# Research directions after the Stage 1 novelty feedback

18 October 2026. Recommendation for discussion, not an approved replacement proposal. No pilot, model training, dataset download, or paid API request has been performed for these directions.

## Decision

The user explicitly permits a substantial change from the submitted Stage 1 proposal. The original evidence-utility motivation remains useful, but neither that PDF nor the earlier selective-labeling revision constrains the new contribution.

Recommended pilot: **Selecting evidence that preserves answer-critical conditions and exceptions under a token budget.** The research question is whether an evidence selector can preserve the qualifications needed to make an answer valid, especially when a highly relevant general rule competes with a less obviously relevant condition or exception.

This recommendation reflects clarity of the failure, available supervision, experimental separation of selection from reasoning, and manageable cost. It is not a verified first-in-literature claim. Conditional reasoning, evidence bundles, document structure, contrastive training, and constrained selection all have prior work.

## Options considered

| Direction | Research question | Advantage | Main risk | Recommendation |
|---|---|---|---|---|
| Condition and exception retention | Does selection drop the clause that changes or qualifies the answer? | Specific failure; direct evidence audit; existing annotations can reduce rollout labeling | Conditional-QA and structured-retrieval baselines must be taken seriously | First pilot |
| Robustness to copied and overlapping evidence | Does the chosen semantic evidence change when the same information is replicated or rechunked? | Controlled perturbations; directly connected to redundancy | Deduplication/MMR and existing redundancy studies may explain all gains | Backup diagnostic study |
| Joint evidence beyond greedy choices | When do individually weak passages become useful together, and can limited lookahead recover them? | Direct test of complementarity | Set selection, graphs and joint multi-hop retrieval are crowded; expensive joint labels | Pursue only after identifying a measurable gap |
| Selective utility labeling | Can targeted labels reduce training cost? | Reuses the previous proposed pipeline | Standard active learning alone gives weak methodological novelty | Treat as an optional technique, not the project identity |

## Why condition retention changes the research question

Fictional example:

- Rule: Employees may work remotely.
- Qualification: Staff with on-site duties must attend in person on the assigned day.
- Scenario: I have on-site duties on Friday; may I work remotely on Friday?

A selected context can contain many correct, relevant statements about remote work while omitting the applicable qualification. Counting the number of covered claims does not necessarily prefer the decisive clause. A valid exception is also not simply a false or harmful document to penalize as a contradiction.

The proposed unit of selection is therefore a supported rule together with the applicable conditions, exceptions, and any definition needed to interpret it. A condition can be satisfied, contradicted, or unspecified by the scenario. The selected evidence must allow the reader to distinguish those cases; a conditional answer can be the correct output.

## Prior work and the remaining boundary

- [ConditionalQA, ACL 2022](https://aclanthology.org/2022.acl-long.253/): existing task/data foundation, with human support and condition annotations and document structure. Selecting conditions is already part of the task. Native data concerns a known policy document; selecting chunks from that document is a document-grounded selection experiment, not evidence of open-domain retrieval performance.
- [Chain of Condition, Findings EMNLP 2024](https://aclanthology.org/2024.findings-emnlp.968/): already identifies and reasons over conditions. Its prompting comparison uses oracle evidence sections; it also tests retrieval settings and reports missing conditions as a limitation. Our target would be budgeted evidence selection with a fixed downstream reasoning procedure. We must include its retrieved-evidence setting or a transparent adaptation, not imply it only uses an oracle.
- DocHopper already uses hierarchical, iterative evidence gathering and appears among ConditionalQA's baselines. Inspect its released implementation before defining the new selector; structure-aware retrieval is not new.
- [InsLogicBench, ACL 2026](https://aclanthology.org/2026.acl-long.1035/): abstract-level check only; covers insurance reasoning with exceptions and clause-grounded traces. Possible later transfer task, not required for the first experiment. Audit the full method, annotations, language, and release before adopting it.
- RRPO, DynamicRAG, UtilityQwen, SetR and SCARLet remain related work. Neither conditional rewards nor a new dataset automatically avoids their conceptual overlap.

Candidate contribution: a selector trained and evaluated to retain answer-critical qualifications, plus controlled experiments establishing when ordinary relevance, diversity, and utility selection lose them under equal budgets. A broader conditional-retrieval audit, including recent KG-based CQA work, remains necessary before claiming priority.

## Concrete method to test

1. Split policy documents into clauses/chunks with stable source offsets and heading paths. Preserve the connective language and antecedents needed to interpret a clause.
2. Retrieve a shared candidate pool for every method. In the initial experiment, use the associated policy document and identify this scope explicitly. Measure whether required evidence is present in that pool.
3. Use an initial relevance scorer to find candidate answer-bearing rules. A small query/scenario-conditioned model predicts which candidate clauses qualify those rules and whether they are applicable or still unresolved.
4. Assemble alternative rule-and-qualification bundles and choose among them under a common evidence-token limit. Begin with bounded beam search or a simple constrained selector; these optimization tools are not the novelty.
5. Pass selected original text to a frozen reader with a common answer-and-conditions prompt. Keep the reasoning procedure identical across compared selectors.
6. If the pilot supports learning, train the relation/scoring component from existing training annotations plus a small audited set. Critical-clause deletion creates useful incomplete-set examples, but deletions must be checked for alternative valid support.

No gold conditions or answers are available to the deployed selector. Gold evidence serves training and evaluation only. Do not require a guessed full logical proof parser before testing whether simpler structural expansion solves the problem.

## First pilot

Use roughly 100 development questions to audit errors and 30-50 carefully checked paired scenarios as a diagnostic subset. The paired subset must genuinely change applicability or required qualifications; it is a controlled diagnostic and must not replace natural-distribution evaluation. The original dataset already includes scenario modifications, so paired scenarios themselves are not a novelty claim.

Compare at least relevance selection, tuned MMR, relevance plus nearby/heading-related clause expansion, a strong utility or setwise selector, and the proposed bundle selector. Neighbor expansion is essential: if it solves the failure at equal cost, a learned model may be unnecessary.

Use the same selected text with two fixed readers, one of which supplies no training feedback. Keep any conditional reasoning prompt fixed. Add full-document and annotated-evidence settings as diagnostics, with their larger budgets/oracle status disclosed.

Measure:

- Required-condition/exception recall and complete-support rate on the audited subset.
- Official answer-with-conditions quality, ordinary answer quality, and unsupported unconditional answers.
- Appropriate response to meaningful scenario changes and stability to irrelevant changes.
- Actual selected tokens, preprocessing/model calls, annotation work and runtime.

Accept alternative valid evidence bundles rather than treating one annotation as the only possible proof. Incomplete annotations require an audit before a complete-support metric is trustworthy. Split by source document, keeping scenario variants together, and reserve an untouched local evaluation split if the public test annotations cannot be used.

Proceed only if baseline errors are attributable to missing qualifications, the candidates contain those qualifications, and a common reader improves when they are restored. If failures persist with complete evidence, the bottleneck is reasoning and the proposed selector may not help. If simple expansion matches the proposed selector, report that result rather than adding unnecessary training.

## Resource assumptions

Avoid exhaustive reader-generated marginal labels and online RL initially. Existing annotated evidence lowers the potential label burden, although checking answer-critical exceptions and relation labels still requires work.

A pilot with 100 questions, five selectors, two evidence budgets and two readers entails up to 2,000 answer generations, before scenario diagnostics, preprocessing, repetitions or audits. Selector/teacher prompts are additional and must be counted. Cache model outputs and reuse fixed annotations.

Planning assumption: one 24 GB GPU is a plausible starting point for a compact encoder and separately scheduled quantized 7-8B reader inference. Full training of that reader and simultaneous residency are not assumed. Verify memory with the actual sequence lengths and software before promising a fit. API spending cannot be inferred from request count; price actual input/output tokens for the selected provider/model before any paid run.

## What remains undecided

The user has authorized exploring a new direction, not approved this pivot. No existing proposal PDF has been changed. The next concrete decision should follow a small error audit and a focused comparison with conditional retrieval methods, rather than another broad novelty assertion.
