# Learning evidence interactions under a limited annotation budget

**Proposed revision to the COL764 Stage 1 project**  
Pallav Kamad | 2023CS51067 | 15 October 2026

Status: research proposal, not an experimental result or a claim of established novelty. The submitted PDF remains the historical Stage 1 submission.

**18 October update:** the user approved a failure-first investigation before selecting the revised method. The selective-labeling direction below remains a historical candidate, not a verified contribution. Follow [the prospective pilot plan](experiments/failure_pilot/PLAN.md) and [current experimental status](experiments/failure_pilot/STATUS.md). The prepared Kaggle smoke test has not yet run; no improved method should be claimed from the local retrieval diagnostics.

## 1. Revised research question

At a fixed evidence budget and a fixed cost of obtaining supervision, can a compact selector learn when a passage becomes useful or redundant **because of evidence already selected**, and improve grounded multi-answer generation over independent outcome-supervised ranking and tuned diversity selection?

The proposed contribution is a controlled study and a selective-labeling method for learning these interactions efficiently. Success requires a quality-versus-cost advantage, verified grounding, and useful performance with an unseen reader. Merely replacing teacher judgments with measured answer-quality labels is insufficient.

## 2. Position relative to existing work

Outcome-supervised retrieval, utility distillation, information gain and context-aware selection are established. The project retains them as foundations and baselines.

| Prior work | Boundary relevant to this revision |
|---|---|
| eRAG, supplied Paper 2 | Already observes answer quality from individual passages. Test the added value of conditioning on S over a singleton-based predictor. |
| UtilityQwen, supplied Paper 7 | Already distills utility selection and propagates selected passages between windows. Compare against its released model and disclose fixed-budget adaptations. |
| Risk-aware reranking, supplied Paper 10 | Already balances beneficial and harmful document effects. A risk penalty alone is not a new contribution. |
| CRUX, supplied Paper 8 | Already caches passage/aspect judgments and constructs coverage-oriented subsets. Coverage caching is a baseline/tool, not the novelty. |
| [RRPO](https://aclanthology.org/2026.acl-long.1406/) | Already learns from prefix-answer quality. Its published scoring equations are pointwise; explicit state conditioning is a testable comparison, not a claim that set-aware learning is unprecedented. |
| [DynamicRAG](https://proceedings.neurips.cc/paper_files/paper/2025/hash/f69d2246a85e28c3e63dee3daf8d4af8-Abstract-Conference.html) | Already optimizes generated ordered subsets using output-quality feedback. Its training and variable selection budget differ from this controlled setup. |
| [InfoGain-RAG](https://aclanthology.org/2025.emnlp-main.365/) | Already trains on with/without-document confidence changes. Distinguish confidence, singleton answer quality and grounded set-conditioned quality. |
| [EBCAR](https://openreview.net/forum?id=OBMcxeSK5U) | Already models cross-passage dependencies efficiently. A compact interaction architecture alone is insufficient novelty. |

For fixed S, `argmax_d [F(S+d)-F(S)] = argmax_d F(S+d)`. Subtraction supplies a convenient marginal target, but does not create a new within-state ranking principle. Across trajectories, cumulative prefix scores and telescoping marginal sums can differ; the project should not call these training objectives identical.

The defensible prospective claim is narrow: **selecting which context-conditioned comparisons to label can improve grounded QA per annotation token, and the benefit is concentrated in questions with reproducible context-dependent passage preferences.** This must survive comparisons with random acquisition and state-hidden models. A broader literature check is still needed before any priority claim or publication submission.

## 3. Hypotheses and falsification

**H1: Interactions matter.** For a meaningful subset of questions, the preferred next passage changes with the selected evidence, and this change survives repeated measurement. A passage pair whose ranking reverses between two partial contexts is particularly informative.

**H2: Explicit conditioning helps.** A selector observing `(q,S,d)` improves grounded-answer F1 over the same backbone trained on the same marginal examples but observing only `(q,d)`.

**H3: Selective annotation helps.** Uncertainty/disagreement-based acquisition improves the quality-cost curve over uniform candidate sampling with the same state bank, labeling machinery and budget constraints.

Cross-reader performance and latency are evaluation requirements. If H2 fails, do not claim an interaction-learning benefit. If H3 fails but H2 holds, narrow the contribution to a supervised interaction study. If neither holds, produce a diagnostic account of when cheaper independent/diversity selection suffices.

## 4. Fixed pipeline and evidence budget

Retrieve one immutable top-50 pool per question. Use BM25+dense fusion when compatible corpus snapshots and passage IDs are available. If indexing this pipeline would consume the pilot budget, begin with one frozen BM25 pool and identify fusion as a later robustness experiment. All methods within an experiment must use precisely the same pool.

The main setting selects five distinct passages directly from the 50. Preprocess passages identically with a declared reference tokenizer, with at most 256 content tokens per passage and an evidence-content cap of 1,280 tokens. Declare whether titles and citation markers count toward the cap and apply the same rule everywhere. This equalizes maximum budget, not actual consumed tokens; report both. A secondary comparison selects up to the same total token allowance without requiring five passages.

Freeze the answer generator, prompts and decoding settings during each experiment. Canonically order a selected set by original pool rank for the primary experiment. Labels then measure membership changes under that rendering rule. Test selection order and shuffled order separately.

The primary reader G1 supplies training feedback and test responses. Reader G2 is from a different model family, supplies no training feedback and is not used to tune the selector. Use exactly the same selected passages with both readers. Repeated seeds for one reader are a noise test; they do not substitute for a second reader.

## 5. Operational training target

Use QAMPARI's entity/alias structure to avoid an unspecified weighted mixture of many metrics. The generator returns distinct answer items with passage citations. Normalize aliases and remove duplicate predictions before scoring.

For query q and evidence S, let:

- A be the set of canonical gold answer entities;
- P be the distinct predicted entities;
- T be the predicted entities that match A **and** have cited evidence supporting their query-specific answer relationship.

Define grounded precision `|T|/|P|`, grounded recall `|T|/|A|`, and F as their harmonic mean. Set F to zero when there are no supported correct predictions. A gold-matching answer without evidential support receives no grounded credit. Verify the relationship asked by the question, not just an entity mention. Composition/intersection questions may require joint support across multiple cited passages.

Use a local support checker A for training labels, with a fixed support threshold validated on held-out development examples. Audit extraction, aliases and relation-support judgments before generating substantial training data. Retain per-item support decisions, cited spans and uncertainty. If the checker cannot reliably validate multi-passage relationships, narrow the claim to the audited subset or improve the checker before scaling.

F measures benchmark-relative grounded quality. Gold lists can be incomplete: do not describe every unmatched prediction as factually false. Audit apparently supported unmatched entities, report the enriched QAMPARI subset separately if available, and apply any alternative scoring consistently across all methods.

For a fixed rendering and generator setup, collect:

`delta(q,S,d) = F(q,S union {d}) - F(q,S)`.

Use deterministic decoding initially. Repeat a sampled fraction, particularly near-zero or reversed comparisons, with controlled stochastic decoding to estimate sign stability. Do not pretend paired seeds eliminate generation noise. Retain weak differences as ties/uncertain labels instead of forcing confident preferences.

Report answer precision/recall/F1, evidence coverage, citation precision/recall, unsupported-answer rate and contradiction separately. A contradiction component may be added only as a prespecified ablation after label reliability is established.

## 6. Method and selective labeling

Train a compact scorer `f_theta(q,S,d)` to predict the measured marginal target. Use a backbone that can actually fit the selected context and candidate, with a verified input limit of roughly 2,048 tokens. A 512-token cross-encoder that silently truncates S is not a valid implementation. An embedding/set-pooling variant can be an efficiency ablation, with its representation limitations stated.

Train with regression on measured deltas and/or within-state pairwise preferences whose difference exceeds the validated noise margin. At inference, rescore every remaining candidate after each selection until five have been chosen. This entails 240 candidate scores for n=50,k=5, versus 50 for a single independent ranking; batch scoring and report the actual latency cost.

For supervision, construct a common training-state bank with one partial context of each size 0,1,2,3,4 per question. Use a mixture of relevance, MMR and randomly sampled prefixes so training is not restricted to a single greedy path. Gold information may evaluate a training state but must not be an input to the deployed selector. Keep the state bank identical between acquisition controls.

For each state, label four candidate additions. The selective policy prioritizes uncertainty and disagreement between an initial independent scorer and a state-conditioned scorer near the selection boundary, while reserving 20% of candidate choices for uniform exploration. Use a shared initial random warm-up, then acquire labels in rounds. Freeze acquisition rules on development data. The uniform policy receives the same number of questions, state sizes, and candidate slots.

These are standard acquisition ingredients; their application is not assumed novel. The experiment tests whether they find useful interactions more cheaply. Log acquisition scores and sampling probabilities so selection bias and poor coverage can be diagnosed. Any on-policy state refresh must replace allocated labeling slots or be charged as extra work.

## 7. Dataset and split plan

QAMPARI remains primary because many-answer questions make coverage and redundancy operational. Its [official release](https://github.com/samsam3232/qampari) describes 61,911 train, 1,000 development and 1,000 test questions, with manually checked/rephrased development and test data. Use an initial subset of 1,000 training questions, with nested smaller training-label budgets. Freeze exact IDs and remove cross-split duplicates before labeling.

Use development questions for the pilot, evaluator calibration and selector tuning, recording all uses. Separate calibration and tuning subsets where feasible. Keep test questions and their evidence/answers inaccessible to label acquisition, prompt selection and stopping decisions. Run final evaluation only after freezing the protocol.

HotpotQA fullwiki is secondary. Either tune using a held-out part of its training split and reserve development for evaluation, or presplit development into disjoint tuning/evaluation portions. Check the mapping from annotated supporting facts to retrieved chunks and the coverage available in the natural top-50 pool.

ASQA and CRUX are optional transfer/diagnostic tasks. Do not make their addition a prerequisite for the main experiment. A public train/dev structure can still support a valid untouched local evaluation split.

## 8. Baselines and adaptations

The budgeted main comparison comprises ten systems:

1. Fused retriever top-five.
2. BM25 ranking within the shared candidate pool.
3. Independent neural relevance reranker.
4. Tuned MMR, with its relevance/diversity tradeoff selected on development data.
5. Released UtilityQwen with an explicitly identified fixed-five adaptation.
6. Independent outcome-supervised model trained from singleton answer-quality labels, inspired by eRAG.
7. State-conditioned marginal scorer with uniform acquisition.
8. State-conditioned marginal scorer with selective acquisition.
9. The same marginal supervision/backbone with S hidden, isolating the value of the state input.
10. An RRPO-adapted pointwise policy trained with the common grounded reward and common pools/budgets, with every departure from the published setup disclosed.

For UtilityQwen, retain its final selected queue order, truncate if more than five are selected, and fill from the unused shared relevance ordering if fewer are selected. Freeze this rule before testing; include a fill-order sensitivity check. Report its native variable-count behavior separately. Do not label the adaptation a reproduction of its native operating point.

For the RRPO adaptation, preserve its published policy/optimization structure as far as possible and charge reference-trajectory generations as well as policy trajectories. If its work-in-progress release prevents faithful execution, identify the implemented comparator as RRPO-inspired and limit claims accordingly. A stronger claim against the published method requires a credible reproduction or usable released checkpoint.

InfoGain-RAG and DynamicRAG remain mandatory related work. Add their released systems when usable under the controlled setup, or clearly document a missing empirical comparison. A singleton answer-quality control is not an exact InfoGain-RAG reproduction; a fixed-budget variant of DynamicRAG is not its native pipeline.

Measured greedy selection and reference-coverage selection are diagnostic analyses. A reference-driven coverage selector must not be presented as a deployed system using test gold answers. Any learned coverage baseline must obtain reference supervision from training only.

## 9. Pilot and decision criteria

Start with 100 development questions, not exhaustive labeling of all 50-to-five decisions. Record candidate coverage first. For each question, use sampled states and additions to inspect deltas, supported answer changes, redundancy, and context-dependent passage preferences.

On a smaller prespecified subset, obtain both repeated measurements and multiple contexts of the same size. This separates evidence-content effects from merely seeing a longer prefix. If affordable, run measured greedy on 20 questions, or exhaustive small-pool selection as a separate artificial diagnostic. Neither is a general upper bound.

Before the pilot, record practical thresholds for checker accuracy, preference stability and a worthwhile grounded-F1 gain. A reasonable starting decision rule is a two-percentage-point grounded-F1 improvement worth investigating, with interval estimates rather than a promise of significance from 100 questions. The exact checker threshold and noise margin must be justified by the audit rather than invented after seeing test results.

Proceed to learning only if candidate evidence permits improvement, the labels pass the support audit, and there is an interaction signal beyond noise/diversity. Scale selective annotation only if it improves a held-out development quality-cost curve over uniform acquisition. Failure is an informative result and triggers a narrower diagnostic study.

## 10. Evaluation and analysis

Primary outcome: mean per-question grounded answer F1, reported alongside ordinary QAMPARI answer scores. Use an independent support checker B for final automatic grounding evaluation and a blinded human sample. Checker A's score alone cannot validate a method trained to optimize checker A.

Report paired question-level confidence intervals, preferably bootstrap intervals resampling questions. Repeated labels from one question are not independent samples. For trained offline models, use multiple training seeds while reusing their fixed annotation data. Additional RL training seeds consume extra reader calls and must be budgeted separately.

Analyze cases by candidate coverage, question type, evidence overlap and measured preference reversals. Distinguish an actual contradiction from redundant or unsupported content. Use closed-book, shuffled-context and evidence-deletion controls on a prespecified subset; a supported answer is evidence-grounded, while a deletion effect is a separate measure of reader dependence.

Plot quality against actual teacher requests, annotation tokens/dollars and selector latency. Equal call counts do not equal equal costs, because longer S costs more. Report both fixed-call comparisons and token/cost Pareto comparisons, with the same maximum constraints. Do not claim a cost reduction establishes equal quality without testing it.

## 11. Resource plan and deliverables

The sparse starting design requires at most `5*(1+4)=25` generator evaluations per training question, before repetitions and other runs. Full cached greedy labeling requires 241. This is a roughly 9.6-fold reduction in requests **for that labeling design**, not an established improvement in learning efficiency.

The full comparison budget must include separate active, uniform, singleton-supervised and RL label campaigns, development runs, both test readers and auditing. See `RESOURCE_BUDGET.md` for the explicit ledger, GPU memory estimate, dated provider prices and proposed spending limits.

Release frozen split IDs and candidate pools, the state/label protocol and cost ledger, selector checkpoints/configurations, fixed-reader outputs, evaluator audit details, and an error analysis. The eventual paper/report should lead with the result actually supported: interaction learning, cost improvement, or a carefully bounded negative finding.
