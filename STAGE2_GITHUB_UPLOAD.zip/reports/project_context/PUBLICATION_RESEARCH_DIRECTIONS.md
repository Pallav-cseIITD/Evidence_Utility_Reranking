# Three research directions within the evidence-utility project

Prepared 18 October 2026. These are ranked research hypotheses for discussion with the professor. They are not approved replacement proposals, observed results, verified first-in-literature claims, or assurances of conference acceptance. The literature checks are targeted, not exhaustive.

**Subsequent user correction:** The user rejects making incomplete answer references the central project direction and reasserts the professor's original evidence-selection pipeline. The recommendation/ranking below is preserved as historical exploration and is superseded by that scope correction. See section 8 of `PROJECT_MEMORY.md`. None of these options has been approved.

All three retain the professor's scope: frozen top-50 candidates, a fixed evidence-token budget, a compact selector, grounded multi-claim generation on QAMPARI/ASQA, optional HotpotQA, independent evaluation, and at least two readers. None requires a conditional-QA or yes/no-only task.

## Recommendation and ranking

| Rank | Direction | Proposed contribution | Main uncertainty |
|---|---|---|---|
| 1 | Learn evidence utility from incomplete answer references | Diagnose distorted marginal labels, then learn useful selection without treating every unlisted claim as wrong | How often missing references actually change selection decisions |
| 2 | Optimize evidence selection for a change of reader | A training objective and selector that trade off reader-specific gains to improve performance on unseen readers | Whether utility preferences disagree enough to justify robust optimization |
| 3 | Limit losses relative to a strong evidence baseline | A policy that gains claim coverage while controlling a defined measure of baseline-relative harm | Avoiding a trivial fallback solution and distinguishing existing risk-control/gating methods |

The first option has the clearest new problem relative to the earlier proposal. The second is more directly a method-and-generalization project. The third combines retrieval decisions with statistical calibration but requires the most care with prior work and guarantees. These rankings are judgments about research clarity and feasibility, not acceptance probabilities.

## 1. Learning evidence utility from incomplete answer references

### Presentable question

Can we learn reliable marginal evidence utility when the reference answer omits valid claims, without exhaustively annotating every possible answer?

### Mechanism of the failure

Suppose the reference lists five valid entities. An evidence set enables the reader to return those five, so reference F1 is 1. A new passage supports a sixth genuinely valid answer. Returning all six gives precision 5/6, recall 1, and F1 10/11 under the incomplete reference. The measured marginal reward is negative despite additional useful evidence. With an expanded six-answer reference, the direction reverses: the five-answer output has F1 10/11 and the six-answer output has F1 1. A recall-only reward may give the new answer zero credit rather than a negative reward, but still misses its contribution.

This arithmetic is illustrative, not a new theorem or empirical result. The research issue is its prevalence, which methods it affects, and whether a cost-effective learner can correct it. Preserve benchmark aliases and relation-specific support checks; an entity mention alone is not a valid new answer.

### Candidate method

1. Construct training states and candidate additions from shared pools. Cache answers and candidate claims.
2. Give claims three statuses: verified relevant/supported, verified invalid or unsupported, and unresolved. Reference absence alone cannot assign a negative label.
3. Use an independent relation-support checker and a prespecified, randomly sampled human audit. Audit claim factual validity separately where needed; source entailment alone is not truth.
4. Represent unresolved claim correctness with utility intervals or uncertainty, and use within-state preferences only when the comparison is sufficiently identified. Request additional verification for ambiguous comparisons near the selection boundary.
5. Train a compact state-conditioned selector and charge all additional verification to its label budget.

The three-way states, intervals, partial-label learning, and selective verification are established ingredients. A new method would need an explicit objective/acquisition rule and credible comparisons. Do not simply rebrand standard positive-unlabeled learning.

### Experiment that could justify a paper

First audit natural QAMPARI errors. Pool answers/claims from several systems, blind annotators to their origin, and construct an expanded reference relative to that evaluated pool. Do not call it an exhaustive inventory of all true answers. On a subset with reliable expanded labels, hide labels at controlled rates while keeping questions and retrieved evidence fixed. Include both random omissions and structured omissions of rare or multi-hop answers.

Measure utility-label sign/preference changes, downstream selected-claim coverage, and training degradation under missing references. Compare ordinary reference-supervised utility, simple training-only reference expansion, a support-only proxy, a partial-label baseline, and the proposed uncertainty-aware learner at equal annotation cost. Evaluate on untouched, independently audited questions; never repair training labels using held-out test answers.

The scientific contribution would connect missing answer annotations to the reliability of marginal training decisions, then offer a remedy. Showing only that a benchmark has missing answers would be insufficient.

### Closest work and novelty boundary

- [QAMPARI, GEM 2023](https://aclanthology.org/2023.gem-1.9/): explicitly documents incomplete answers and provides ExtendedSet. Its original experiments report unchanged system ordering after reference expansion. Therefore do not assume the proposed training failure is large or that all rankings reverse.
- [Evaluating D-MERIT of Partial-annotation on Information Retrieval, EMNLP 2024](https://aclanthology.org/2024.emnlp-main.171/): studies partial relevance judgments and retrieval evaluation. Our candidate concerns marginal answer-utility supervision and subsequent learning, rather than merely evaluating retrieval under incomplete qrels.
- eRAG, InfoGain-RAG and RRPO already supply downstream utility/confidence supervision. The proposed question concerns supervision validity when answer claims are only partially observed.

Existing partial-label/positive-unlabeled ranking methods and reference-free factuality rewards require a focused audit before a priority claim. A strong support-checking baseline could remove the need for a complicated learner.

### Go/no-go

Proceed only if missing references change a material number of training preferences beyond measurement noise and this affects selections. If ambiguity intervals overlap almost everywhere, or simple reference expansion solves the problem at the same cost, narrow the method claim. Missing-answer noise may otherwise be a useful smaller diagnostic result.

## 2. Evidence selection that survives a change of reader

### Presentable question

Can we optimize an evidence selector for reliable improvement across reader models, instead of training it for one reader and only checking transfer afterward?

### Candidate method

Measure the same sampled evidence additions/sets with two different training readers. Learn both a shared evidence-support component and reader-dependent utility predictions, or use a single scorer with a robust multi-reader objective. Optimize worst-reader improvement or a prespecified regret objective relative to a common strong selection baseline. Compare with simple mean-reward training using exactly the same reader feedback.

Keep raw grounded quality, baseline-relative gain, and regret distinct. Very weak readers, different score ceilings, or arbitrary normalization can dominate a minimax objective; prespecify the chosen normalization and include sensitivity controls. Do not advertise a guarantee for arbitrary unseen readers.

### Experiment that could justify a paper

Use at least two readers for training feedback and hold out a different model family for evaluation; a second held-out reader would strengthen the result. Fix the selected set across evaluated readers. Compare single-reader utility training, average-ensemble training, robust training, MMR and released utility selectors. Match both supervision cost and model capacity. Report worst-reader and mean quality plus per-reader losses, alongside independent evidence coverage.

The key diagnostic is reproducible preference disagreement: an addition or selection that helps one reader and harms another. If observed disagreement is mostly generation noise, robust selection has little reason to help.

### Closest work and novelty boundary

- [RRPO, ACL 2026](https://aclanthology.org/2026.acl-long.1406/): already reports transfer across multiple readers. Transfer evaluation, a smaller teacher, or multiple reader results is not new.
- UtilityQwen and InfoGain-RAG also evaluate different generators.
- Group/distributionally robust optimization and multi-teacher distillation are established. The candidate contribution is an effective method for optimizing reader-relative evidence utility and demonstrating generalization under controlled reader changes. A generic minimum of two losses is unlikely to be enough alone.

### Go/no-go

Proceed if disagreements are stable and a stronger selection diagnostic can improve the tradeoff. Stop if robust training simply matches an equally funded mean-reward baseline or if single-reader RRPO-like training already transfers adequately.

## 3. Controlling losses relative to a strong evidence baseline

### Presentable question

Can a utility selector improve average grounded coverage while limiting the frequency or magnitude of queries made worse than tuned MMR?

### Candidate method

Let S0(q) be the baseline evidence and S_pi(q) the proposed set. With grounded quality F in [0,1], define loss h(q) = max(0, F(S0,q) - F(S_pi,q)). Alternatively define an epsilon-degradation indicator. Choose one risk before calibration; mean positive loss and probability of degradation are different targets.

Train an evidence-set edit or selection policy together with a baseline-relative harm predictor. Calibrate the final policy on separate paired outcomes; retain S0 when intervention is unsupported. Every chosen set must fit the same evidence budget. Try constrained edits that preserve verified baseline support, but do not confuse evidence-support retention with guaranteed reader-output retention.

Any finite-sample risk guarantee must name the bounded loss, confidence level, calibration protocol, fixed policy/parameter family and distributional assumptions. Ordinary held-out bounds do not imply every query improves, and unmodeled reader or query shifts can invalidate them. LLM-judged labels yield control of that judged metric unless further human-validity assumptions are established.

### Experiment that could justify a paper

Compare always-rerank, always-baseline, confidence gating, ordinary risk-penalized training, and the calibrated policy. Plot quality against baseline-relative harm and intervention frequency. A policy that always falls back is a trivial risk solution; it must retain meaningful gains. Include actual labeling, calibration and inference cost.

### Closest work and novelty boundary

- [Robust Ranking Models via Risk-Sensitive Optimization, SIGIR 2012](https://www.cs.cmu.edu/~pbennett/papers/wang-et-al-sigir-2012.pdf) and [risk-sensitive ranking with multiple baselines, SIGIR 2016](https://eprints.gla.ac.uk/119285/): baseline-relative harm is established IR research.
- [CAR, arXiv:2605.04495](https://arxiv.org/abs/2605.04495): already uses confidence-based conservative correction and a query gate. A simple confidence fallback is insufficient novelty.
- [C-RAG, ICML 2024](https://arxiv.org/abs/2402.03181): already certifies general bounded generation risks and configurations. Applying an existing bound to a renamed loss is insufficient novelty.
- Supplied Paper 10 already balances beneficial/harmful passages. The proposed distinction would be set-level, baseline-relative grounded-coverage losses, an effective constrained selection/edit policy, and calibrated intervention behavior. This is a demanding novelty boundary, not an established gap.

### Go/no-go

Proceed if current utility selectors produce substantial, reproducible query-level losses while still improving means. A paper needs a nontrivial gain-harm frontier improvement beyond CAR-style gating and standard risk-sensitive objectives. If a generic calibrated gate fully solves it, characterize the result honestly rather than claiming a new theory.

## Shared pilot, cost and publication path

Begin with a shared diagnostic on 100-200 development questions, not three full systems. Generate a baseline set and three alternative evidence sets for each question. With two readers this requires 800-1,600 answer generations before repeats, claim extraction and independent verification. Reuse these same sets for missing-label, reader-disagreement and baseline-loss analyses. Dataset retrieval, claim audits, and downstream training are additional work; request counts are not dollar costs.

Planning assumption only: one 24 GB GPU can plausibly support compact selector work and separately scheduled quantized 7-8B reader inference; verify actual memory before execution. Reader ensembles multiply inference time and annotation effort even when they share the GPU. No paid run is authorized by this note.

Select one direction after the pilot. For a conference research submission, develop a coherent package: a precisely established failure, a technically justified method, strong controlled comparisons, independently validated grounding, uncertainty estimates, cross-reader/task tests, and released artifacts where permitted. A 100-question pilot is not automatically a sufficient final evaluation. Positive performance, completeness of the literature audit, and acceptance remain unknown.

Do not lead with small models, pair selection, before/after subtraction, uncertainty sampling or using an LLM judge as novelty. Those are tools. Lead with the specific problem that existing supervision or selection does not adequately solve, and support that claim empirically.
