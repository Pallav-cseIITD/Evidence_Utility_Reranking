# GPU access, label cost and proposed API budget

Planning date: **15 October 2026**. Currency: USD. These are estimates, not measured throughput, purchases, allocations or permission to spend. No deadline is assumed.

## Recommendation

For the proposed study, plan for **one NVIDIA GPU with 48 GB VRAM**, **80-120 rented GPU-hours** when answer generation is API-assisted, **32-64 GB host RAM**, and approximately **200 GB SSD** if using compatible prebuilt retrieval indexes. A 24 GB GPU is a workable minimum for a compact selector and sequential, quantized reader inference, with smaller batches. Multiple 80 GB GPUs are not necessary for the proposed starting scope.

Set an initial **$25 API pilot cap**. If its measured token usage and label reliability support scaling, plan **$350 for the core API campaign** and approximately **$500 total compute/API/storage cash budget**. This includes multiple offline selector seeds and one budgeted RL baseline training run. A full three-seed RL comparison merits an API ceiling around **$450-500** and a total ceiling around **$600**.

These ceilings depend on validating the input/output lengths below. If the pilot needs longer reasoning, a stronger teacher, more repetitions or new full-corpus indexing, recalculate before enlarging the campaign.

## 1. How many answer generations does labeling require?

For n candidates and k greedy selections, exhaustive next-candidate assessment evaluates

`sum(t=0..k-1)(n-t) = k*n - k*(k-1)/2`

candidate additions. For n=50,k=5, this is 240 marginal comparisons. With one cached initial F(empty) and reuse of the chosen candidate's already computed score at the next step, it requires **241 unique answer generations per question** for one reader and one generation repetition. Naively computing both sides of every delta would use 480; caching avoids this waste.

This count assumes the same evidence rendering, prompt, generator and decoding configuration. If those change, outputs cannot be silently reused. Extra evaluator calls are separate.

| Questions | Full cached greedy generations | With two generation repetitions | Sampled design generations, one repetition |
|---:|---:|---:|---:|
| 100 | 24,100 | 48,200 | 2,500 |
| 200 | 48,200 | 96,400 | 5,000 |
| 1,000 | 241,000 | 482,000 | 25,000 |
| 2,000 | 482,000 | 964,000 | 50,000 |

The sampled design uses five contexts of sizes 0-4 and four additions per context: **20 delta labels plus five baseline scores = at most 25 generations/question**. Some outputs may overlap, but the estimate does not depend on that saving. It does not find the best next passage among all 50 and does not replace the measured full-greedy diagnostic with an equivalent oracle.

For the independent singleton control, 24 singletons plus a no-evidence baseline also fit within 25 generations/question. RL consumes its allowance on policy and reference trajectories; count actual requests, rather than treating one trajectory as one request.

## 2. Token-cost assumptions and verified prices

Use the general cost equation:

`API cost = input_tokens/1e6 * input_rate + billed_output_tokens/1e6 * output_rate`.

For initial planning, assume **3,500 input tokens and 250 billed output tokens per answer-generation request**. This is a conservative prompt/evidence allowance, not a measurement of the supplied PDFs or a proven mean for QAMPARI. Billed output must include any charged reasoning tokens. Support checking is planned locally; a hosted judge for every generated claim would add a separate, potentially large bill.

The following rates were checked on official provider pages on the planning date:

| Service | Standard text input / million tokens | Standard output / million tokens | Assumed cost per request |
|---|---:|---:|---:|
| Gemini 3.1 Flash-Lite, possible G1 | $0.25 | $1.50 | $0.00125 |
| Claude Haiku 4.5, possible independent G2 | $1.00 | $5.00 | $0.00475 |

Sources: [Google Gemini API pricing](https://ai.google.dev/gemini-api/docs/pricing), [Anthropic API pricing](https://platform.claude.com/docs/en/about-claude/pricing). These are pricing examples, not evidence that either model is an accurate support judge. Validate the chosen teacher and pin its exact model version before labeling. Eligible batch requests have lower listed rates; the budget does not depend on batch discounts, caching discounts or free quotas.

### Cost of just one labeling campaign

| Design, 1,000 training questions | Requests | Input tokens | Output tokens | At G1 example rates |
|---|---:|---:|---:|---:|
| Full cached greedy | 241,000 | 843.5M | 60.25M | $301.25 |
| Sampled marginal design | 25,000 | 87.5M | 6.25M | $31.25 |

Two repetitions approximately double these figures. Multiple different training-label campaigns must be added; the proposed method's $31.25 is not the cost of the whole research study.

### Sensitivity to actual token lengths

For 100,000 G1 requests, costs are:

| Mean input / billed output | Estimated API cost |
|---|---:|
| 1,500 / 150 | $60.00 |
| 3,500 / 250 | $125.00 |
| 7,000 / 750 | $287.50 |

The last row can invalidate the recommended $350 core ceiling once evaluation and auditing are included. The pilot must measure token distributions, not just request counts.

## 3. Full campaign ledger

The initial scale is 1,000 training questions, 100 development questions for a frozen evaluation snapshot, 1,000 test questions and ten main systems. Development tuning beyond that snapshot must be charged separately. Training learning-curve points should be nested subsets of the same annotation campaigns, not newly regenerated copies.

| Item | Requests or allowance | Expected API spend |
|---|---:|---:|
| Selective marginal-label campaign | 25,000 G1 requests | $31.25 |
| Uniform marginal-label campaign | 25,000 G1 requests | $31.25 |
| Independent singleton-label campaign | 25,000 G1 requests | $31.25 |
| RRPO-adapted baseline, policy + reference feedback combined | 25,000 G1 requests total | $31.25 |
| Test: ten systems, G1 | 10,000 G1 requests | $12.50 |
| Test: identical evidence, G2 | 10,000 G2 requests | $47.50 |
| Development snapshot: ten systems, both readers | 1,000 G1 + 1,000 G2 | $6.00 |
| Pilot: sampled labels plus roughly 25% repeat allowance | 3,125 G1 requests | $3.91 |
| Optional measured greedy diagnostic on 20 pilot questions | 4,820 G1 requests | $6.03 |
| Independent hosted checks/extra pilot reader comparisons | cash allowance | $10.00 |
| **One training run per learned system, subtotal** | | **$210.93** |

Four offline models are trained from the fixed annotation campaigns: selective, uniform, independent singleton, and state-hidden ablation. Running three training seeds for those models reuses the labels, but can change selected evidence and therefore requires fresh test responses:

| Replication addition | Additional work | API spend |
|---|---|---:|
| Two extra seeds for each of four offline selectors | 8,000 G1 + 8,000 G2 test generations | $48.00 |
| **Core campaign subtotal** | three offline seeds, one RL seed | **$258.93** |
| 25% reserve for failures, token variation and limited extra development | | **$64.73** |
| **Core planning estimate** | | **$323.66** |

Round to a **$350 API ceiling**, subject to the pilot. Actual support-check API work must stay within the explicit allowance or trigger a revised estimate. Reusing identical evidence outputs across methods may save money, but savings are not assumed.

For three RL seeds, add up to 50,000 G1 training-feedback requests ($62.50) and 2,000 G1 + 2,000 G2 test generations ($12.00). Including the same reserve gives approximately **$416.79**; round to **$450-500**. This budgeted baseline is a controlled adaptation at limited scale, not the original authors' complete training campaign. Extra reward variants, DynamicRAG retraining, a larger training set and full secondary-dataset runs are not included.

## 4. GPU memory and rental estimate

The memory estimates are engineering allowances. Actual peaks depend on architecture, sequence length, quantization implementation, batch size, optimizer, attention kernels and adapters; measure them on a small run.

| Component | Approximate requirement | Practical choice |
|---|---|---|
| Compact 100-400M selector training with selected context | 8-20 GB with small batches/checkpointing | 24 GB minimum; 48 GB comfortable |
| Released 1.7B selector inference | usually fits within 8-16 GB at moderate context/batch | run sequentially on the same GPU |
| Local 3-8B reader inference | roughly 10-24 GB quantized; BF16 7-8B weights alone use about 14-16 GB, plus cache/runtime | 24 GB for modest batches; 48 GB for batching |
| Two local readers plus checker | avoid simultaneous loading initially | load sequentially; a second GPU is optional |
| Local support checkers and embedding inference | modest batches on the shared GPU | include their runtime in the ledger |

A 1.7B student fine-tuning experiment should use adapters/quantization if needed rather than assuming full optimizer-state training fits in 24 GB. The proposed small-selector scope does not require reproducing Paper 7's eight-GPU teacher-distillation training setup.

[Runpod's current pricing page](https://www.runpod.io/pricing), updated 8 October 2026 and checked on 15 October, lists RTX A6000 48 GB at $0.59/hour, RTX 4090 24 GB at $0.89/hour, and A100 PCIe 80 GB at $1.79/hour. These listed instances differ in availability, memory and throughput. A lower hourly price does not imply a lower cost per completed experiment.

At the A6000 listing, **80-120 hours cost $47.20-$70.80**. Add a **$20-30 storage/miscellaneous allowance**, to be replaced by the actual provider quote. Together with the $350 core API ceiling, approximately **$450** is plausible; rounding the total ceiling to **$500** leaves room for setup and measured overruns. Buying hardware is unnecessary for this plan.

The 80-120-hour API-assisted allowance covers several compact selector fits, local checkers, preprocessing and released-baseline inference. The RL job may pay for GPU idle time while waiting on API responses; measure this and use asynchronous collection/batching where compatible with the training algorithm. Full-corpus embedding/index construction is excluded. Prefer compatible prebuilt indexes or cached pools; if they are unavailable, estimate that construction separately.

## 5. Local-model alternative

If institutional GPU access is available, main labeling can be done with a frozen local reader and the API cash bill can be reduced to approximately **$0-30** for limited independent checks. Do not assume a small local teacher has adequate label quality; apply the same pilot audit.

For the core approximately 146,000 generation requests after offline-seed evaluation, development and pilot work, a rough **180-400 GPU-hour** allowance is reasonable to investigate. This is not a measured benchmark. One illustrative calculation uses roughly 511M input and 36.5M output tokens: aggregate prefill at 1,000-3,000 tokens/second and batched decoding at 100-250 tokens/second gives approximately 88-244 generation hours before selector training, checking and overhead. Performance outside those assumptions changes the estimate substantially.

At $0.59/hour, 180-400 rented hours cost about **$106-$236**; with storage and a small API allowance, a **$300** starting cash ceiling is plausible for this local-reader version. Full RL replication can require roughly 300-650 hours and a larger ceiling. A university GPU removes the rental charge but not GPU-hour usage or annotation labor.

Do not compare these local-reader and hosted-reader outcomes as though only the billing method changed: reader identity and label quality can change too. Freeze the chosen teacher within each controlled experiment.

## 6. Human validation and cost controls

Budget an audit of 120 claim/evidence decisions, each independently assessed by two people. At two minutes per assignment, this is eight annotator-hours, plus roughly two hours for disagreement resolution: **about ten person-hours**, subject to a measured annotation pilot. Multi-hop cases can take longer. If only one person audits, report that limitation and do not claim inter-annotator agreement.

This labor is separate from API/GPU cash. Paid external annotation would require an additional quoted labor budget; the cash totals above assume project-member effort, not free professional annotators. No claim is made that a 120-decision audit guarantees evaluation accuracy.

For every run, log question/state IDs, ordered passage IDs, model/version/prompt hashes, retries, actual billed tokens, support-check work, GPU elapsed time, peak memory and cash cost. Cache only identical configurations. Stop the pilot at its own spending cap; expand only after its quality and resource measurements support the next stage. No account, GPU instance or paid labeling job has been started by this review.
