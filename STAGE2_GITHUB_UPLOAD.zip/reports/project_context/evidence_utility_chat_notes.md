# Supplementary Discussion Notes: Evidence-Utility Reranking

These notes collect clarifications and conclusions from our discussion that are not repeated in the original project description or the final proposal document.

## 1. Clarifying the selection pipeline

- The initial retrieval system returns a fixed pool of n candidate passages.
- The selector chooses k directly from those n. There is no required intermediate step that first keeps a smaller top-K set by relevance.
- Selection is sequential: after choosing a passage, the selector scores the remaining candidates in the context of the passages already chosen.
- The first selected passage is scored with an empty selected set. The second is scored given the first, the third given the first two, and so on until k have been selected.

## 2. What the quality function F means

`F(S, q)` means the overall quality score of the evidence set `S` for question `q`. It is a score used to compare evidence sets; it is not necessarily the answer text itself.

A possible score could reward claims supported by evidence and correctly attributed answers, while penalizing contradictions. The exact components and weights must be chosen and validated rather than assumed to be correct.

The marginal utility of a candidate passage `d` is:

`u(d | S, q) = F(S ∪ {d}, q) - F(S, q)`

For example, suppose the question asks who founded a company and in which year it was founded:

- Passage A gives the founders.
- Passage B repeats the founders.
- Passage C gives the founding year.

If A has already been selected, B may add little new support, while C may support a missing claim. If a new passage adds useful information but also introduces a serious contradiction, the overall `F` score could fall. The point is to measure the net change, not to assume that every added passage helps.

## 3. What a training label looks like

One training instance can be written as `(q, S, d)`:

- `q`: the question;
- `S`: the passages already selected;
- `d`: a candidate passage being considered;
- label: the measured change in quality when `d` is added to `S`.

For example, if `S` supports two answer claims and `S + d` supports three, `d` has added support for one more claim. If adding another candidate changes nothing, its marginal contribution to that component is zero.

These labels are created before training and stored as training data. The training set must contain many different questions, selected sets, and candidate passages. The selector should learn a pattern that works on unseen questions, rather than memorizing a particular question.

## 4. Why selection is called greedy

“Greedy” means choosing the candidate with the highest predicted marginal utility at each step, then repeating with the updated selected set.

It is a practical approximation. For example, With 50 candidates, there are `C(50,5) = 2,118,760` possible five-passage sets. Exhaustively testing every set would be expensive, especially if each quality measurement requires running a generator. Greedy selection avoids evaluating every complete set, but it is not guaranteed to find the globally best set for every possible quality function.

## 5. Which components use an LLM?

The selector and the answer generator are separate components:

- **Retriever:** produces the n candidates.
- **Small selector:** predicts a candidate's marginal utility from the question, selected passages, and candidate passage.
- **Fixed generator/reader:** produces an answer from the selected evidence during evaluation.

The selector itself does not have to be a large language model. A small cross-encoder or similar model may be enough. However, an LLM may still be used while creating labels or evaluating answers. The proposed distinction is not simply “LLM versus no LLM”; it is the kind of training target used.

The label-generation stage may be the expensive part, because it may require measuring quality before and after adding passages. Once trained, the small selector should be much cheaper to run than repeatedly calling a large teacher model, although the actual cost depends on model size and implementation.

## 6. What we can and cannot claim about Paper 7

Paper 7 already uses a large LLM as a teacher and distils its utility-selection behavior into a smaller selector. Its selection process also carries previously selected passages forward, so later decisions are not simply independent rankings.

Therefore, we should **not** claim that our work is new merely because it:

- selects passages based on utility;
- considers previously selected passages;
- trains a small selector; or
- chooses a subset rather than ranking passages independently.

The proposed difference to investigate is whether training on **measured before/after changes in grounded-answer quality** provides a better supervision signal than the existing teacher-generated utility labels. This is still a hypothesis, not an established novelty claim. We must inspect Paper 7's actual label-construction method and released materials before deciding that the targets are meaningfully different.

Paper 2, *Evaluating Retrieval Quality in Retrieval-Augmented Generation* (eRAG), is also important to inspect closely because it evaluates passages through downstream QA performance. It may overlap with parts of the proposed measurement idea. The report's novelty claim should be narrowed if either paper already uses an equivalent target.

## 7. Cross-generator transfer

A selector might learn what works particularly well for one generator rather than what makes evidence broadly useful. To test this, train or label the selector using one fixed setup, then use the same trained selector to choose passages for an unseen test question and evaluate those selected passages with a second generator—without retraining the selector for that second generator.

Success with both generators would support transfer, though it would not by itself prove that the evidence-selection method is universally better.

## 8. Extra notes on supporting literature

These are short interpretations discussed during the conversation, beyond the brief descriptions in the original project outline:

- **eRAG / Paper 2:** connects passage quality to downstream question-answering performance. It is relevant to how we might measure a passage's contribution, not only to how we rank it by topical relevance.
- **ARES / Paper 3:** trains or uses lightweight automatic evaluators for context relevance, answer relevance, and faithfulness. It is primarily an evaluation tool, not the 50-to-5 selector itself.
- **RAGChecker / Paper 4:** provides detailed diagnostics that help separate retrieval problems from generation problems.
- **Response Quality Assessment for RAG / Paper 6:** focuses on judging the quality and factual support of individual answer claims; useful for evaluation rather than directly constructing the selector.
- **CRUX / Paper 8:** studies whether retrieved context actually contains the information needed for a generated answer, supporting context-coverage evaluation.

## 9. The question to resolve with the professor

The main open question is:

> Does supervision from controlled, measured changes in grounded-answer quality offer a genuinely different and useful training signal from the utility annotations and selection method in Paper 7—and from the downstream passage evaluation in eRAG?

This should be settled before treating the proposed label-generation method as the project's final novelty claim.
