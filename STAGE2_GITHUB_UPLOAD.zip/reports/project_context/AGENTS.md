# Project context

This is Pallav Kamad's COL764 evidence-utility reranking research project.

For work in this directory, read `PROJECT_MEMORY.md` first. It records the original brief, submitted Stage 1 proposal, discussion notes, all ten supplied papers, and the reviewer's subsequent feedback. Consult the original PDFs for exact claims and experimental details.

`REVISED_STAGE1_PROPOSAL.md` is a proposed revision, not an approved replacement for the submitted proposal. `RESOURCE_BUDGET.md` contains dated estimates and assumptions, not measured experiment results or authorization to spend money.

The user wants GPU requirements and API spending estimated. Do not impose or ask for a project deadline. Preserve the original PDFs and `evidence_utility_chat_notes.md` as historical sources.
