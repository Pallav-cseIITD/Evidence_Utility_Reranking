# Proposed novelty: learning changes in marginal passage preference

Research note, 18 October 2026. This remains an unapproved candidate within the professor's original scope. No result, claim of worldwide priority, new theorem, or conference acceptance is established. The literature search is targeted rather than exhaustive.

**Later assessment:** `NOVELTY_ASSESSMENT.md` records the completed limited literature/algebra/cached-annotation audit. It finds insufficient evidence for a standalone methodological novelty claim. The derived squared response objective is a coupled weighting of existing label errors, and preference reversals occur under ordinary coverage. Larger model experiments were deferred by the user. Preserve the candidate below as a proposal rather than treating it as validated.

## The precise candidate

Train a compact selected-set-conditioned scorer using **paired evidence interventions that measure how the relative utility of the same two passages changes when selected evidence changes**. Retain the professor's marginal-utility definition and ordinary greedy inference.

The proposed technical ingredient is a supervision protocol and an explicit training target for the change in preference across contexts. Merely giving the scorer S, detecting complementarity, obtaining downstream rewards, subtracting a baseline, or using a small model is insufficient novelty.

## A fictional example

Question: **In which countries were the directors of Mira Stone's films born?** All names and film titles below are invented.

Keep these two candidate passages unchanged:

- A: Arun Das directed *Silver Harbor*. He was born in India.
- B: Bela Rios directed *Quiet Road*. She was born in Chile.

Construct two partial evidence sets from the same fixed pool:

- S1 contains a passage stating that Mira Stone produced *Silver Harbor*.
- S2 replaces that passage with one stating that Mira Stone produced *Quiet Road*.

Both contexts have the same passage count and can use matched token budgets and rendering. One next passage may be added.

| Selected context | What adding A supports | What adding B supports | Supported preference |
|---|---|---|---|
| S1 | India, through the complete producer-film-director-birthplace connection | No complete connection between Stone and Rios | A over B |
| S2 | No complete connection between Stone and Das | Chile, through the complete connection | B over A |

This is about support in the selected evidence. Rios and Das can both be valid directors of Stone's films in the full corpus. The experiment changes available evidence, not truth or the question.

With an illustrative F that counts correctly generated, fully supported answer claims, an ideal evidence-using reader could yield marginal utilities (A=1, B=0) in S1 and (A=0, B=1) in S2. These numbers are explanatory, not observed model results. The actual fixed reader may fail to use the evidence; that behavior must be measured and distinguished from evidence availability. Correct background knowledge without the producer-film connection does not satisfy the grounding target.

The example demonstrates an established property of set-aware utility. Its existence does not establish our novelty. A set-aware model from prior work may also solve it.

## What would be learned differently?

Let g(S;a,b) = u(a|S,q) - u(b|S,q). Within one context the F(S,q) baseline cancels, so g can also be measured as F(S+a,q) - F(S+b,q).

For a matched pair S1,S2, define the response target:

T = g(S1;a,b) - g(S2;a,b).

The model predicts scores f(q,S,d), so its analogous prediction is:

T_hat = [f(q,S1,a)-f(q,S1,b)] - [f(q,S2,a)-f(q,S2,b)].

A candidate objective combines ordinary marginal or within-context preference training with a loss matching T_hat to measured T. Reliability margins or weights come from repeated generations and audited grounding labels. This is a standard contrast/finite difference and an ordinary regression or preference-learning ingredient, not a newly invented mathematical object.

The extra hypothesis beyond the submitted proposal is that training explicitly on matched context changes helps the learner use S at a fixed total supervision budget. This hypothesis needs comparisons against (1) ordinary marginal training on randomly sampled states and (2) ordinary marginal/pairwise training on the exact same matched examples, without the cross-context target. Otherwise we cannot separate the benefit of data selection from the benefit of the objective.

Use equal-size contexts that differ in one selected passage where possible, a fixed candidate pair, canonical context order, and length/position controls. Preserve random training examples: learning exclusively from reversals may distort deployment behavior. Count the cost of searching for useful interventions, including candidates that never yield a reliable reversal.

## Comparison with the supplied 13 papers

This table summarizes the relevant methods, not a claim that prior systems cannot exhibit context-sensitive behavior.

| Paper | Established contribution relevant here | Boundary of the proposed protocol |
|---|---|---|
| 1: LLM utility judgments | Pointwise/pairwise/listwise prompted utility judgments and pseudo-answer-based improvements | The candidate uses measured paired reader outcomes as explicit context-change supervision, rather than introducing utility judgment |
| 2: eRAG | Per-document singleton answer generation and downstream scoring for retrieval evaluation | Two matched selected contexts and a trained f(q,S,d) are different objects from singleton evaluation labels |
| 3: ARES | Trained evaluation judges and human-assisted statistical evaluation | An evaluation component, rather than this passage-selection training protocol |
| 4: RAGChecker | Claim-level retrieval/generation diagnostics | Claim checking is an established measurement tool, not the candidate novelty |
| 5: RAGTruth | Human hallucination annotations and detector training | Useful validation material, not matched-context passage-preference training |
| 6: conditional conformal factuality | Calibrated response-claim filtering | A different decision object from selecting the input evidence |
| 7: UtilityQwen | Teacher pseudo-answers and selected IDs distilled into a small selector; selected passages propagate through windows | Already context-aware; the proposed distinction is direct paired outcome-change supervision, not compact distillation or context propagation |
| 8: CRUX | Controlled coverage/redundancy diagnostics, cached answerability and greedy coverage | Coverage and greedy selection are established; multi-hop support must be assessed jointly rather than inferred from independent answer-string presence |
| 9: CiteEval | Citation/attribution evaluation | Independent evaluation tool, not the selection contribution |
| 10: risk-aware information-gain reranking | Learned benefit/harm document roles and risk/benefit scoring | A generic harm or contradiction penalty is not our novelty; the candidate explicitly supervises a change across selected contexts |
| 11: RRPO | Reader-quality reward after each growing prefix; RL training of a pointwise f(q,d) reranker | Its rewards reflect combinations, but its scoring network cannot reverse the order of the same two remaining passages from selected-set content; our candidate adds S and paired supervision |
| 12: DynamicRAG | Listwise set/order/count selection, complete-selection generation rewards and DPO | Already learns combinations; the candidate's distinction is the matched context-change target and compact state-conditioned scoring, not downstream supervision |
| 13: InfoGain-RAG | Change in known-answer token confidence for one document versus query-only, distilled into a small scorer | Different signal from measured grounded answer changes for the same candidate pair across two nonempty selected sets |

Primary local methods were rechecked on this turn for Papers 2, 7, 8, 10, 11, 12 and 13, using the original PDFs. Earlier detailed notes for all 13 remain in PROJECT_MEMORY.md. These differences establish comparison points, not automatic methodological novelty.

## Closest additional primary literature

- **[JPR, EMNLP 2021](https://aclanthology.org/2021.emnlp-main.560/)** already conditions passage choices on the selected prefix and trains a dynamic oracle toward uncovered answers. Its main model is T5-base. Explicit set awareness and new-answer coverage are not new.
- **[SCARLet, EMNLP 2025](https://aclanthology.org/2025.emnlp-main.33/)** removes sampled passages, measures known-answer token logits and fits additive ridge attribution coefficients to train a query-document retriever. Perturbation-derived utility and interaction-sensitive labeling already exist. Our candidate concerns the context-specific change in a candidate pair's relative utility rather than one attributed utility per passage.
- **[DPS, arXiv:2508.09497v1](https://arxiv.org/html/2508.09497v1)** uses supporting-passage index supervision and autoregressive selected-index conditioning. It is an important learned set-selection comparison rather than a pointwise straw baseline.
- **[Modeling Contextual Passage Utility for Multihop QA, arXiv:2512.06464v1](https://arxiv.org/html/2512.06464v1)** uses reasoning traces and GPT-4o ordinal utility ratings. Sections 2-2.2 explicitly state that its deployed RoBERTa receives only (q,p), despite context-derived training labels. Thus context-derived supervision must not be confused with selected-context input at inference. Our candidate differs in paired measured interventions and deployed S conditioning; the paper's general motivation already overlaps.
- **[EBCAR, arXiv:2510.13329v2](https://arxiv.org/html/2510.13329v2)** jointly contextualizes candidate embeddings and trains a relevance-based contrastive objective. A lightweight cross-passage architecture alone is not new. Distinguish candidate-pool context from the changing selected set.
- **[LURE-RAG, arXiv:2601.19535v1](https://arxiv.org/html/2601.19535v1)** trains LambdaMART with singleton document utility and a listwise loss. Efficient utility supervision and pairwise/listwise ranking losses already exist.
- **[CUE-R, arXiv:2604.05467v1](https://arxiv.org/html/2604.05467v1)** measures removal/replacement/duplication effects on correctness, grounding proxies and confidence, including a two-support nonadditivity ablation. Intervention analysis and observing multi-hop synergy are not new. The candidate aims to learn a deployed passage-selection policy from paired preference-response targets.
- **[Pair-ID, arXiv:2608.08944v1](https://arxiv.org/html/2608.08944v1)** audits support-addition/nonsupport-deletion responses for the same failed state and repeats across readers, with length/position controls. Its own scope is offline response characterization rather than a learned ranking policy. Controlled paired interventions and cross-reader response analysis cannot be claimed broadly as new.

The searches also surfaced complementary-evidence identification, context grouping, and counterfactual utility ranking for recommendation. Those results reinforce that neither counterfactual training nor complementarity is a new general concept; this note does not claim their full methods were audited. Preprints above are relevant public prior work, with no venue inferred from arXiv alone. Citations identify the versions actually inspected.

## What would establish a publishable contribution?

1. Stable, consequential context-dependent preferences in the professor's natural fixed candidate pools, beyond answer-generation noise, length/position artifacts, and simple diversity/coverage effects.
2. Better grounded claim coverage or attributed correctness at the same evidence-token and full labeling budgets, against both ordinary sampled marginal training and identical-data controls, as well as tuned MMR, submodular coverage and relevant learned utility/set selectors.
3. Improvement on untouched questions, including the same selected evidence passed to a held-out reader; separate claim-support evaluation and human auditing.

A matched unit needs four augmented-context generations to identify the two relative preferences, or six generations if both F(S) baselines are also measured for absolute marginal labels, before repeats and cache reuse. All screening, verification, failed calls, and additional evaluation count toward cost. This is a request-count calculation, not a GPU-runtime or dollar estimate.

The targeted review did not identify the exact combined protocol as a contribution of the inspected methods. That observation does not prove global uniqueness or that the method is sufficiently different for publication. A small reweighting of existing losses may be incremental or ineffective. The project must earn its contribution through the controlled comparisons above, and the protocol should not be presented to the professor as verified first-in-literature work.
