# Assessment: claim-gain/claim-loss evidence selection

18 October 2026. Follow-up to `FOCUSED_NOVELTY_SCREEN.md`.

## Verdict

**The current candidate is insufficiently supported as the main methodological novelty of an ECIR/SIGIR paper. Keep it as a hypothesis or ablation within the original evidence-utility project; do not rewrite the proposal around an established novelty claim.**

The exact combination of measured multi-claim transitions, nonempty selected contexts and compact passage selection was not located in the inspected literature. That bounded observation is not a priority proof. The general repair/harm motivation and paired-outcome prediction are already established, including recent work specifically in RAG. Separate gain/loss heads alone supply no general decision advantage over an equally informed scalar utility predictor at a fixed linear risk preference.

No end-to-end selector experiment has established gains or ineffectiveness. Larger model experiments remain deferred under the user's earlier instruction. This turn completed numerical controls, a cached-annotation negative control, a public-data eligibility check and additional primary-source comparisons. No pretrained weights, answer generation, paid API call or GPU rental was used.

## 1. Closest literature and actual remaining difference

| Work | What its inspected method already does | Boundary relative to this candidate |
|---|---|---|
| [RRPO, ACL 2026](https://aclanthology.org/2026.acl-long.1406/) | Reader-quality reward after selected prefixes. | Different supervision granularity; per-prefix downstream reward is established. Its pointwise architecture alone is not an adequate comparator for a set-aware candidate. |
| [Risk-aware information-gain reranking, WWW 2026](https://doi.org/10.1145/3774904.3792085), supplied Paper 10 | Beneficial/harmful query-document role estimates and risk-sensitive ranking. | Does not implement our nonempty-set, paired multi-claim transitions. Benefit-minus-harm and multiple heads are nevertheless established. See the earlier note for the repository's appendix erratum. |
| [Uplift-RAG, Findings EMNLP 2025](https://aclanthology.org/2025.findings-emnlp.511/) | Before/after document-induced correctness uplift against a no-document baseline; compact point/pair/listwise training. | Our simultaneous gains/losses within a multi-claim answer and selected S would differ. Controlled improvement labels are not new. |
| [Return or Revise?, arXiv:2609.30087v1](https://arxiv.org/html/2609.30087v1), sections 2-3 and appendix A.5 | Observes paired draft/revision correctness, predicts repair/harm/tie before revision and scores repair probability minus harm probability. Compares paired targets with matched alternatives. | This is answer-revision control with a draft and fixed retrieved evidence, not selecting a passage to add to S. However, the broad supervision story of predicting repair and harm from paired RAG outcomes is close prior art. The authors explicitly state that their generated corpus and learned policies are not publicly released. Treat as a preprint, not a verified proceedings paper. |
| [Predicting Partial Answer Quality and Utility in Agentic RAG, arXiv:2609.16453v1](https://arxiv.org/html/2609.16453v1), sections 3-5 | Measures answer-quality changes between retrieval/reasoning iterations and trains compact predictors, with early-stopping decisions. | Different action and aggregate F1 target. Intermediate quality/utility prediction and a small deployed predictor are established. |
| [Same Agent, Different Answers, arXiv:2608.22856v1](https://arxiv.org/html/2608.22856v1), sections 1 and 3 | Repeat-aware RAG answer-churn audit: separates within-state variation from changes across corpus snapshots, including changes hidden by aggregate accuracy. | Corpus updates and answer-level auditing, not paired claim-based passage-selector training. The broader hidden-regression motivation and repeated-output controls already exist. No quantitative result from this preprint is needed for our verdict. |
| [Positive-Congruent Training, CVPR 2021](https://openaccess.thecvf.com/content/CVPR2021/papers/Yan_Positive-Congruent_Training_Towards_Regression-Free_Model_Updates_CVPR_2021_paper.pdf) | Improves accuracy while reducing negative flips on previously correct predictions. | Image-classifier model updates, not RAG context edits. Adjacent prior art establishes the general accuracy-versus-preservation principle, not our exact selector. |
| [RAGChecker](https://arxiv.org/html/2408.08067v1) | Claim-based correctness, support, utilization and noise diagnostics. | Paired transition training would be additional; claim extraction and checking themselves are reused. |

The supplied eRAG/InfoGain-RAG singleton signals, UtilityQwen distillation and DynamicRAG set-level outcome learning remain important. The existing 13-paper comparison has their exact audited methods. Do not characterize all prior selectors as independent, all harm labels as document-intrinsic truth, or aggregate outcome learning as incapable of learning to avoid harmful context.

## 2. What the proposed score really optimizes

For correct, evidence-supported answer-claim sets C0 and C1 before/after insertion:

`G = |C1 minus C0|`, `L = |C0 minus C1|`.

Then:

`D = G-L = |C1|-|C0|` is net coverage change.

`T = G+L = |C0 symmetric_difference C1|` is correct-claim turnover.

For loss penalty lambda:

`G-lambda*L = ((1+lambda)/2)*D - ((lambda-1)/2)*T`.

At lambda=1, the selection score is exactly ordinary marginal correct-supported-claim count. At lambda>1, it trades coverage gain against turnover. This can be a legitimate preference, but changing the preference does not itself demonstrate a better way to optimize the original coverage objective. These identities concern the claim-count component, not every weighted citation/correctness/contradiction metric in the professor's possible F.

The labels are richer than D alone, because D does not determine G and L separately. That was correctly identified in the initial screen. However, for fixed lambda, an optimal squared-error scalar predictor estimates E[G-lambda*L | q,S,d], which equals E[G | q,S,d]-lambda*E[L | q,S,d]. Thus two outputs are not required to represent the same expected decision score. Auxiliary supervision, finite capacity, optimization, probability-of-loss constraints and serving multiple preferences can still matter empirically; this argument does not eliminate those possibilities.

With squared head errors eG,eL:

`eG^2+eL^2 = 0.5*(eG-eL)^2 + 0.5*(eG+eL)^2`.

Separate-head squared training can be understood as net-change prediction plus an auxiliary turnover prediction task. This is not a proof that neural training trajectories coincide. With a frozen feature matrix and identical ridge regularization, however, separate-head predictions combined at lambda are algebraically identical to direct scalar ridge prediction on G-lambda*L. That restricted equivalence was tested below.

### A modified transition reward need not be a set potential

An explicit constructed example gives C(empty)=empty, C({a})={x}, C({b})={y}, C({a,b})={y}. The path a then b has total G=2,L=1; b then a has G=1,L=0. Both reach exactly the same final evidence and answer claims. At lambda=1, both paths score 1. At lambda=2, they score 0 and 1.

Therefore, in general, the nonunit-loss-penalty transition reward cannot be represented as differences of a single order-independent set-quality function. The professor's F-difference formulation telescopes; this modified reward need not. This does not ban risk-aware trajectory preferences, but they must be justified explicitly, especially because deployment normally generates only the final answer and users never observe the provisional prefix answers.

## 3. Experiments actually executed

The [analysis plan](C:/Users/palla/OneDrive/Desktop/sem1_26_27/col764/project/experiments/claim_transition_audit/ANALYSIS_PLAN.md) was saved before numerical execution. A prospective amendment added a same-distribution sampling control after the literature identified repeat variability. Script and plan hashes, environment, input hashes and outputs are in [the result record](C:/Users/palla/OneDrive/Desktop/sem1_26_27/col764/project/experiments/claim_transition_audit/results/audit_results.json).

| Test | Executed result | Valid interpretation |
|---|---|---|
| Exhaustive binary claim-set check | All 65,536 before/after pairs over eight claims satisfied net-change and weighted-score identities exactly. Squared-loss rotation error <=3.56e-15 on 10,000 random residuals. | Confirms the algebra and implementation; not a benchmark, theorem contribution or measured failure prevalence. |
| Matched fixed-feature ridge control | 1,000 simulated training rows, 500 test rows, 25 features, four lambda values and three regularizers. Maximum score difference 2.14e-14; 0 top-choice disagreements over 600 grouped choices across settings. | Separate heads do not inherently improve this matched predictor. Does not cover jointly trained nonlinear encoders or all losses. |
| Same-distribution sampling simulation | 100,000 independent before/after pairs, ten claim indicators with presence probability 0.8, no intervention. Mean G=1.59644, L=1.59483; 66.933% had both gains and losses. Identical-draw pairing gave G=L=0. | Raw transitions can reflect sampling variation when the underlying behavior is unchanged. These are simulated indicators, not LLM failure rates. |
| Cached CRUX negative control | 69,008 DUC04 and 27,638 Multi-News distinct singleton-context/candidate insertions across the existing 150 selected topics. Zero losses at answerability thresholds >=3 and >=4. | Structurally forced by OR coverage. These cached labels cannot test generated-answer loss. This is not evidence that real reader regressions are absent. |
| Constructed risk-preference counterexample | At lambda=3, a one-gain/zero-loss insertion is preferred to a three-gain/one-loss insertion, leaving three rather than four correct supported claims. | Greater preservation can trade away total coverage. This is an intentionally constructed example, not measured RAG harm. |

The sampling expectation is explicit: for independent draws with identical per-claim presence p, E[G]=E[L]=sum p(1-p), while E[G-L]=0. The marginal answer distributions do not uniquely determine the gross transition rates without specifying how responses are paired. Deterministic decoding defines an operational pair and avoids this particular independent-sampling ambiguity; it does not eliminate judge/alignment errors or show that labels transfer across readers. Do not overstate this as nonidentifiability of every deterministic candidate formulation.

### Public-output eligibility check

Read-only public downloads consisted of small official repository inventories, documentation and one cached evaluation file; pinned revisions and hashes are saved in `experiments/claim_transition_audit/public_metadata/`.

- RAGChecker's inspected cached meta-evaluation file has 280 paired system comparisons and aggregate scores. It has no paired insertion design, per-claim support labels or evidence contexts in those records; none qualifies for this experiment.
- The inspected ALCE tree/documentation provides generation configurations, retrieval inputs and human-evaluation summaries. No matched one-passage insertion output corpus was located in that inspected release. The documented human utility score is aggregate; we did not download its large dataset archive or run generation.
- The inspected CRUX run release supplies retrieval/coverage evaluation; the locally cached ratings are singleton answerability.

This is a scoped search, not proof no suitable cached dataset exists anywhere. No controlled real-answer insertion experiment, claim-level human validation, learned compact selector or reader-transfer evaluation was completed. All 16 historical-source hashes (15 PDFs and the original discussion note) were checked unchanged.

## 4. What would change the verdict

A useful future test must first establish repeat-stable, independently verified claim loss on natural ASQA/QAMPARI evidence insertions. Separate omissions from false replacements and ordinary paraphrases. Grounded correct claims should be checked against both references and the actual evidence.

Then compare the proposed model against scalar training directly on G-lambda*L using identical `(q,S,d)` inputs, all outputs/annotations, backbone capacity, search procedure and token budget. Include a scalar model conditioned on lambda if multiple preferences are claimed as an advantage. For a loss-probability constraint, compare a direct probability-of-loss baseline and evaluate its calibration; count all added supervision.

Retain the professor's relevance, tuned MMR, submodular coverage and learned set/utility baselines. Use fixed fused top-50 pools and a frozen labeling reader; test the same selected evidence with a second reader and an independent evaluator. Match final grounded coverage when comparing losses, and compare complete trade-off curves. Count generation, extraction, alignment, verification, screening, repeat and human-audit costs.

An improvement only over an unpenalized scalar model could be explained by a changed objective. An improvement only over a model without S could be explained by set conditioning. Both are inadequate evidence for the specific training contribution.

Current recommendation: retain G/L as interpretable diagnostic labels and a possible auxiliary-training ablation. The methodological publication claim needs evidence beyond the current two-head construction. The completed checks justify withholding the novelty claim; they do not prove every richer claim-transition selector is ineffective or already published.
