# Focused novelty screen: failure, method difference, decisive comparison

18 October 2026. Literature search and experiment design only. This is an unapproved hypothesis, not a replacement proposal. No new model experiments, downloads, training, paid calls or spending occurred in this screen.

**Follow-up:** `CLAIM_TRANSITION_NOVELTY_ASSESSMENT.md` records the subsequent literature/numerical/cached-data audit. The simple gain/loss-head construction is not currently supported as the main methodological novelty. This file preserves the initial candidate and experiment design; its proposed experiments are not completed results.

## Decision

**No confirmed new method has been established.** One narrower candidate deserves a failure-measurement pilot: learning the gains and losses of grounded answer claims separately after inserting a passage into an existing evidence set.

Claim decomposition, negative utility, benefit/harm scoring, multi-task learning and risk constraints are established. Combining these names is insufficient novelty. A second candidate, selecting individually weak passages that help jointly, has especially close prior work and is less attractive as the main contribution.

| Requirement | Status |
|---|---|
| Specific failure | Useful context carrying harmful information is documented. Simultaneous gains and losses of previously correct grounded claims on our tasks remain unmeasured. |
| Precise method difference | Defined below: paired claim-transition labels, a compact selected-context-conditioned predictor, and an explicit gain/loss trade-off. Priority and effectiveness are unestablished. |
| Decisive comparison | Specified below, including scalar training with the same risk preference and full annotation budget. No results are available. |

## 1. Primary candidate: separate claim gains and losses

### Failure and evidence

Illustrative example, not an observed result: the current answer contains three correct, evidence-supported facts. Inserting A gains two new correct supported facts and loses one old fact. Inserting B gains one and retains all three. Both increase correct-supported-claim count by one, but only A loses an existing fact.

This shows information discarded by a net-count label. **It does not prove scalar optimization is wrong, B always gives a better final answer, or existing selectors necessarily choose A.** If only total coverage matters, these answers may legitimately tie. The research question is whether learning this distinction improves coverage versus harm and generalization.

[RAGChecker, NeurIPS 2024](https://arxiv.org/html/2408.08067v1), sections 3 and 4.3-4.4, separates coverage, utilization and relevant-noise sensitivity. It documents useful-context/noise trade-offs. This supports the broader mechanism, not paired before/after claim-loss prevalence on ASQA/QAMPARI.

[Risk-aware information-gain reranking, WWW 2026](https://doi.org/10.1145/3774904.3792085), supplied Paper 10, already models benefit and harm. Sections 4.2-4.5 score query-document pairs with document-role estimates. Thus “we penalize harmful passages” repeats prior work. The narrower candidate concerns conditional changes to an existing set and its answer claims.

The authors' [repository notice](https://github.com/lzz335/hidden_risk_of_reranking) discloses an implementation error in an appendix multi-retriever generalization experiment and loss of later reproduction files. Avoid relying on that experiment's magnitude; the notice alone does not invalidate the main method or motivation.

### Exact proposed change

Keep the original top-50 fusion, frozen labeling reader, controlled insertion/deletion, compact selector, fixed token budget and two-reader evaluation.

Generate answers from `S` and `S+d`. Align factual claims using benchmark references/aliases where possible, and independently check truth and evidence support. Let `C0,C1` be correct supported answer-claim sets before/after insertion. Label:

- `G = |C1 minus C0|`: new correct supported claims.
- `L = |C0 minus C1|`: previously correct supported claims lost.
- Optionally `H = 1[L>0]`: any loss event.

Use semantic claim identity, not exact sentence matching. Audit omissions separately from corruption/contradiction. A supported statement is not automatically true.

Train a small `(q,S,d)` predictor of gains/losses. It predicts outcomes from passages at deployment, without gold answers or per-candidate reader calls. Whether it can predict them accurately is an open empirical question. Select with a development-tuned trade-off, or maximize predicted gain subject to a predicted-loss threshold. Report the full frontier; a threshold is not a formal safety guarantee.

The net-count delta is `G-L`, which cannot recover both components: `(2,1)` and `(1,0)` yield the same scalar. These labels retain information discarded by scalarization, unlike the earlier derived response loss. This elementary fact is neither a new theorem nor proof of benefit.

**A scalar predictor trained directly on `G-lambda*L` is mandatory.** If it matches the richer predictor at the same risk preference, do not claim a contribution from merely increasing the harm penalty.

### Closest comparisons

| Work | Existing overlap | Candidate difference to test |
|---|---|---|
| [RRPO, ACL 2026](https://aclanthology.org/2026.acl-long.1406/) | Aggregate reader-quality reward after each prefix; reader transfer. | Claim-transition supervision. Compare against an equally set-aware scalar model, not only RRPO's pointwise architecture. |
| [Uplift-RAG, Findings EMNLP 2025](https://aclanthology.org/2025.findings-emnlp.511/) | Document-induced correctness uplift against no-document generation; compact point/pair/listwise training. | Nonempty contexts and simultaneous gains/losses within a multi-claim answer. Closed-book subtraction is already established. |
| Paper 10 | Separate beneficial/harmful document-role estimates. | Conditional answer-claim transitions; two heads alone are not novel. |
| RAGChecker | Claim-based correctness/support/noise diagnostics. | Paired transitions supervising a deployed evidence selector. |
| [CUE-R, arXiv:2604.05467v1](https://arxiv.org/html/2604.05467v1) | Interventions and multi-axis evidence-utility diagnostics. | Learned selection with a paired claim-retention target. Its grounding proxy is coarser than claim verification. |
| [Pair-ID, arXiv:2608.08944v1](https://arxiv.org/html/2608.08944v1) | Crossed addition/deletion audit, matched controls, reader dependence. | Different learning target and deployed policy. Matched intervention analysis is established; no quantitative claim from this preprint is needed here. |

eRAG, InfoGain-RAG, UtilityQwen and DynamicRAG remain relevant. Their singleton, distillation or aggregate-outcome differences do not prove worldwide novelty; consult the earlier 13-paper comparison for exact methods.

### Decisive experiment, once model work resumes

First measure the failure on 100-200 ASQA/QAMPARI questions, shared natural fused top-50 pools, two predetermined partial sets per question and four candidate insertions per state. Include ordinary insertions, not only mined failures. Repeat a subset, use length/position-matched sham controls, and independently human-audit claim alignment and support. A paraphrase is not a lost fact; generation variability is not a stable insertion effect.

Report simultaneous gain/loss frequency, losses hidden by positive net utility, omission versus corruption, and reader dependence, with question-level uncertainty. Two states and four insertions require up to ten distinct contexts per question; two readers imply 2,000-4,000 answer generations before caching, repeats, shams, claim checks and human audits. These are planning counts, not executed calls or a complete spending estimate.

Then compare at matched model capacity, token budget, data and total annotation cost:

1. Ordinary scalar marginal training, optionally including the earlier paired-context baseline.
2. Scalar training directly on `G-lambda*L`, fairly tuned.
3. Separate gain/loss supervision and selection.
4. The same supervision with selected `S` hidden.
5. Relevance, tuned MMR, submodular coverage, a credible learned set selector and Paper 10's risk-aware method.

Scalar baselines receive every before/after output used by the candidate. Count extraction/verification/screening costs too. Compare both identical-output-data and equal-total-cost settings if richer annotations cost more. Match rendering and answer limits; report answer length and latency.

Success means fewer lost/corrupted correct claims **at matched final grounded coverage**, or more grounded coverage **at matched loss rate**, on held-out questions and a second reader. Include attributed correctness and citation metrics. Merely answering less is not success.

Drop the method claim if a same-risk scalar model matches it, or if the failure disappears under repeated-generation and sham controls. A substantial diagnostic result could remain a different contribution.

## 2. Screened alternative: jointly useful weak passages

Failure: two individually weak passages complete a reasoning chain together, so immediate greedy gains can prune both. Candidate change: measure `F(S), F(S+a), F(S+b), F(S+a+b)` and train a context-dependent joint-benefit predictor with bounded pair additions. The second-order difference is standard mathematics.

Close priors make this crowded:

- [Generative Context Pair Selection, EMNLP 2021](https://aclanthology.org/2021.emnlp-main.561/), full method inspected: context-pair compatibility and question-generation likelihood already support joint pair selection.
- [ParaSet/SetCE, arXiv:2607.05712v1](https://arxiv.org/html/2607.05712v1), methods and appendices inspected: cached-embedding lightweight set scoring, a cross-encoder and beam exploration. Labels order perturbed sets by gold-evidence recall then precision, rather than measured answer changes. This is a major new baseline.
- [RepoShapley, arXiv:2601.03378v1](https://arxiv.org/html/2601.03378v1), section 3.3 inspected: singleton likelihood probes, nonlinear surrogate/Shapley attribution and bounded generator verification of pairs/triples. Its limitations explicitly discuss jointly useful individually weak chunks missed by its proposal pool. Code completion is adjacent prior art, not an identical QA task.
- [QUBO evidence selection, arXiv:2607.12334v1](https://arxiv.org/html/2607.12334v1), section 3: static requirement support and pair-complementarity terms. Its ablations caution that extra interaction terms need not improve answer scores.

A decisive experiment must compare ordinary greedy selection, conventional beam/pair search and explicit interaction training at the same outcome-model, annotation and search budgets, including ParaSet/SetCE. Beating only greedy does not isolate a training contribution.

Decision: retain as diagnostics/baselines; currently harder to defend as the main novelty.

## Search boundary

Primary methods were checked across set scoring, pair selection, conditional utility, claim-level risk, reader priors and order interventions. This is not exhaustive priority verification. [Mixture-of-Intervention, arXiv:2412.10684v1](https://arxiv.org/html/2412.10684v1), section 3, already separates utility from position effects through permutations, so generic order debiasing is excluded too.

No exact claim-transition selector match was identified among inspected methods. This is a bounded search result, not confirmed originality. Its occurrence, practical importance and benefit over same-data/same-risk baselines remain necessary before rewriting around it.
