# Assessment of the proposed training approach

18 October 2026. This assessment combines a targeted literature review, an algebraic analysis, and a limited CPU diagnostic on released CRUX annotations. The user subsequently requested that the larger GPU experiments be skipped. No selector was trained and no answer generator was run.

## Verdict

**The approach fits the professor's scope, but there is currently insufficient evidence to defend it as a standalone methodological novelty for ECIR/SIGIR.**

Its exact paired-context training protocol differs from the procedures inspected, but the general ingredients have substantial prior art. The extra squared response loss is a coupled weighting of existing marginal-prediction errors. Preference reversals also arise under ordinary claim coverage. Consequently, neither a reversal example nor a new name for this loss establishes the research contribution.

This is not a proof that the training strategy cannot help. A useful sampling or training bias may still improve efficiency or generalization, and an empirical contribution is possible. Those benefits remain unmeasured because the relevant training experiments were deferred. The present evidence supports a cautious candidate, not an established new method.

## What was checked against the literature

The complete supplied-paper mapping remains in [the 13-paper comparison](NOVELTY_EXAMPLE_AND_PRIOR_WORK.md). The most consequential overlaps and actual boundaries are below.

| Prior work | What already exists | What the candidate would still have to establish |
|---|---|---|
| [RRPO, ACL 2026](https://aclanthology.org/2026.acl-long.1406/) | Reader-quality feedback after every selected prefix; compact outcome-trained reranking and cross-reader testing. Equations 3-5 use a pointwise f(q,d) scorer. | Selected-state-dependent scoring can differ architecturally, but this difference is already represented elsewhere in set-aware selection. Beating a state-hidden comparator alone is insufficient. |
| [JPR, EMNLP 2021](https://aclanthology.org/2021.emnlp-main.560/) | Compact autoregressive selection conditioned on the selected prefix, with a dynamic oracle promoting uncovered answers. | A novel benefit of the particular intervention-based training protocol, beyond existing context-dependent coverage selection. |
| [SCARLet, EMNLP 2025](https://aclanthology.org/2025.emnlp-main.33/) | Sample passage-presence changes; measure known-answer token logits; fit additive utility attribution and train a query-document retriever. | A beneficial context-specific response objective or acquisition rule beyond perturbation-based utility supervision. Do not characterize SCARLet as interaction-blind. |
| UtilityQwen, supplied Paper 7 | Teacher pseudo-answer/selected-ID distillation, small selector and propagation of previously selected passages. | The value of measured paired outcome changes, rather than compactness or selected-context propagation. |
| DynamicRAG, supplied Paper 12 | Learned selection of document combinations, order and count using complete-selection generation rewards and DPO. | A specific improvement from matched interventions under the same full supervision budget, rather than outcome-supervised set selection itself. |
| eRAG and InfoGain-RAG, supplied Papers 2 and 13 | Singleton generation-quality labels or query-only versus query-plus-document confidence labels. | The additional contribution of context-sensitive supervision, compared at equal cost. |
| [Contextual passage utility, arXiv:2512.06464v1](https://arxiv.org/html/2512.06464v1) | Reasoning-trace-derived ordinal utility judgments. Section 2.2 explicitly gives the deployed model only (q,p), despite context-derived labels. | Measured paired interventions and deployed selected-set conditioning differ, but the general motivation is already studied. |
| [DPS, arXiv:2508.09497v1](https://arxiv.org/html/2508.09497v1) | Autoregressive passage-index selection trained from supporting-evidence labels, including inter-passage dependencies. | Benefit over an actual learned set selector, not only independent scoring. |
| [CUE-R, arXiv:2604.05467v1](https://arxiv.org/html/2604.05467v1) | Removal/replacement/duplication interventions across multiple outcome measures, plus two-support nonadditivity diagnostics. | A learned selection benefit; intervention analysis and showing joint evidence effects are established. |
| [Pair-ID, arXiv:2608.08944v1](https://arxiv.org/html/2608.08944v1) | Same-state crossed support-addition/nonsupport-deletion audits, matched controls and cross-reader response analysis. | The audit itself is not a deployed ranking policy, but paired intervention analysis is not new. |
| [CRUM, arXiv:2110.09059](https://arxiv.org/abs/2110.09059) | Recommendation reranking using counterfactual list context, a utility evaluator and pairwise swaps. | Broad counterfactual/context-sensitive utility learning is established in adjacent IR. This is adjacent prior art, not evidence that its recommender system already implements our exact RAG protocol. |

The ACM version of Utility-Oriented Reranking with Counterfactual Context (DOI 10.1145/3671004) was not accessible through the web reader. Its 2021 author preprint CRUM was inspected. RewardRank's related-work characterization is not treated as a substitute for that inaccessible original. Likewise, do not infer peer-reviewed venues for the arXiv-only sources above.

The searches did not identify an exact copy of the complete proposed training protocol among inspected sources. That does not establish exhaustive worldwide priority, originality relative to general contrastive/structured learning, or sufficient substance for a conference paper.

## Mathematical check: what does the extra target add?

Take four ordinary marginal labels in two selected contexts:

`y = [u(a|S1), u(b|S1), u(a|S2), u(b|S2)]`.

The proposed response target is `T = y1 - y2 - y3 + y4`. It is already fully determined by those four labels. For relative preferences, both F(S) baselines cancel, so the same target can be obtained from four augmented-context answer scores. Six answer scores are required if both absolute marginal baselines are also needed.

Let `e = predictions - y` and `c = [1,-1,-1,1]`. For the squared-loss version:

`ordinary loss + lambda * response loss`

`= sum(e_i^2) + lambda * (c^T e)^2`

`= e^T (I + lambda*c*c^T) e`.

Thus the response term increases the penalty for a particular correlated pattern of mistakes. This is a **coupled quadratic weighting**, not generally four separate per-example scalar weights. It changes the learning bias and may help a capacity-limited or noisy learner. It supplies no additional independent observation once all four ordinary labels are available.

If all four ordinary predictions fit exactly, response loss is automatically zero. Also `(c^T e)^2 <= 4*sum(e_i^2)`. These observations do not make every cross-entropy/preference-learning formulation equivalent; the exact quadratic rewriting applies to the specified squared loss.

Numerical verification used 10,000 seeded residual vectors and lambda values 0, 0.25, 1 and 4. The maximum difference between the two equivalent calculations was 8.53e-14, consistent with floating-point roundoff. Known-case checks also recovered a pure-coverage preference reversal, all-zero ties and disjoint context/candidate sampling.

**Implication:** describe this as a candidate regularizer or training strategy. Do not describe the derived target as newly observed information, a new causal estimator, or a new theorem.

## Actual local diagnostic: preference reversals from plain coverage

Source: the [official CRUX data release](https://huggingface.co/datasets/DylanJHJ/crux), revision `7c2ab688c9f164410978e81cafad4124185e5b3a`, linked by the [authors' repository](https://github.com/DylanJoo/crux). Six small files totaling 8,972,882 bytes were downloaded. URLs, hashes and sizes are preserved in the source manifest. No raw report texts or entire Wikipedia corpus were downloaded.

The analysis plan was saved before computing reversal outcomes. It selected all 50 DUC04 topics and 100 Multi-News topic IDs by an outcome-independent SHA-256 ordering. All 150 were eligible. Report pseudo-documents were excluded; at most 50 natural chunks per topic were retained by document-ID order. Three seeds supplied 256 sampled designs each per topic. Within a design, contexts had equal chunk counts and differed by one passage; the same two candidates were evaluated in both contexts.

This uses **cached answerability ratings and union coverage**, not generated answers. An aspect is covered if any selected passage has a published rating >=3. There is no multi-hop AND operation, no reader inference and no learned selector. It is therefore a deliberately simple test of whether a reversal implies a new interaction phenomenon.

| Annotation-based diagnostic | DUC04 | Multi-News |
|---|---:|---:|
| Topics | 50 | 100 |
| Sampled paired-context designs | 38,400 | 76,800 |
| Unique ordered membership designs | 38,398 | 67,904 |
| Strict preference reversals | 1,185 | 2,068 |
| Reversals / all sampled designs | 3.09% | 2.69% |
| Topic-bootstrap 95% interval for reversal rate | 2.65%-3.54% | 1.98%-3.49% |
| Reversals / comparisons strict in both contexts | 4.95% | 5.05% |
| Topics containing a sampled reversal | 50/50 | 74/100 |

At the prespecified stricter >=4 rating threshold, the corresponding overall reversal rates were 2.70% and 2.54%. Designs include repeated samples; intervals resample topics rather than pretending every within-topic design is independent. These are diagnostic rates for this sampling design, not population rates for QAMPARI, ASQA, HotpotQA or natural top-50 fused retrieval.

**Interpretation:** changing a preferred passage can arise entirely from ordinary redundancy and uncovered-aspect coverage. A reversal is therefore not, by itself, evidence of multi-hop complementarity beyond coverage or a new methodological contribution. The calculation does not show that MMR solves every such case, nor that our selector cannot outperform a coverage proxy on real generated answers.

## Annotation sensitivity

DUC04 has published Llama 3.1 and Llama 3.3 answerability annotations on the same chunks. On the identical primary designs, 454 of 1,185 primary reversals also reversed under the second annotations; 453 retained the same direction. Direction-matched retention was 38.23%.

Overall reversal/no-reversal agreement was 96.37%, but predicting no reversal for every case would agree with the primary annotations 96.91% of the time. The high raw agreement is dominated by non-reversals and is not evidence of reliable rare-event labeling.

This demonstrates sensitivity to the two released annotation files and their versions/procedures. It is not an estimate of human label accuracy, repeated-generation noise, or transfer between two answer generators. Their differences cannot be assigned solely to model identity without controlling the annotation procedures. It motivates independent auditing before selectively mining rare reversal labels.

## What was not run

- No selector training, pretrained model download or answer-generator calls.
- No natural BM25+dense top-50 construction or evidence-token/ordering experiment.
- No QAMPARI/ASQA/HotpotQA end-to-end quality comparison.
- No cross-generator answer evaluation, human audit or citation-checker validation.
- No API or rented-GPU spending.

The available computer has an NVIDIA RTX 2050 with 4 GB VRAM and approximately 7.4 GiB system RAM; only approximately 0.7 GiB RAM was available during inspection. This is a contemporaneous environment observation, not a theoretical minimum for the project. Larger model runs were deferred at the user's request, rather than declared impossible on all 4 GB GPUs.

## The deferred experiment that could change the verdict

Keep the professor's pipeline and grounded-answer reward. Use frozen question splits, one common BM25+dense top-50 pool, identical evidence-token budgets, fixed training reader, independent evaluation and a held-out reader receiving the same selected evidence.

The decisive learned comparisons are:

1. State-hidden scorer with ordinary utility labels.
2. State-conditioned scorer with ordinary labels from randomly sampled contexts.
3. State-conditioned scorer with ordinary marginal/pairwise training on the exact paired-context labels used by the proposed method.
4. The same scorer and labels plus the proposed response regularizer.
5. Tuned MMR, submodular coverage and credible existing learned utility/set selectors.

Comparing 2 versus 3 isolates context acquisition; 3 versus 4 isolates the extra loss. Equalize the full cost of generating, screening, repeating and verifying labels, not only the number of retained reversal examples. Random contexts must remain represented. Evaluate a prespecified practical quality gain, question-level intervals, multiple training seeds and actual inference latency; tune all methods using development only. Include cases where verified support requires joining passages, because independent OR-coverage cases alone cannot establish a multi-hop advantage.

Do not spend a second training campaign proving the quadratic rewriting: it is already an exact identity. Any claim about the regularizer must concern its useful learning bias, not that the equivalent expression is a different algorithm.

The defensible claim, if those experiments succeed, would concern a demonstrated quality-versus-label-cost improvement from a precisely specified training strategy. If the identical-data baseline matches it, the method-specific claim should be dropped. If only the diagnostic remains, present it as a bounded empirical finding within the professor's allowed backoff scope.

## Reproducibility

- Plan: `experiments/novelty_audit/ANALYSIS_PLAN.md`.
- Runnable CPU calculation: `experiments/novelty_audit/run_diagnostics.py` (Python plus NumPy).
- Full outputs, selected IDs, hashes and settings: `experiments/novelty_audit/results/diagnostic_results.json`.
- Per-topic results and illustrative real-annotation designs: neighboring JSONL files.
- Public input URLs/revision/hashes: `experiments/novelty_audit/data/crux/source_manifest.json`.

The ordinary response identities were checked on all sampled designs. The final run repeated the original sampling after descriptive reporting checks were added; the primary rates did not change. This audit is complete at its stated limited scope. The user-deferred model experiment remains unperformed, so no positive learned-system novelty is established.
