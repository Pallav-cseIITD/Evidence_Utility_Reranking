# Evidence Utility Reranking for Grounded Generation

Pallav Kamad | 2023CS51067 | COL764

**Repository:** https://github.com/Pallav-cseIITD/Evidence_Utility_Reranking

## Stage 2 deliverables

**Final combined submission:** [Stage 2 report with all 50 cases](reports/stage2/STAGE2_FINAL_REPORT.pdf). This supersedes the earlier separate PDFs for submission.

- [Six-page initial pilot report](reports/stage2/STAGE2_REPORT.pdf), with [editable Markdown](reports/stage2/STAGE2_REPORT.md).
- [50-case qualitative audit](reports/stage2/FAILURE_AUDIT_50.pdf), [full evidence browser](reports/stage2/failure_audit_50.html), and [verification CSV](reports/stage2/failure_audit_50.csv).
- [Original Stage 1 proposal](reports/stage1_proposal.pdf).
- [Self-contained Kaggle notebook](experiments/failure_pilot/Evidence_Utility_Kaggle_Start.ipynb).

## What has actually run

100-question CPU coverage preflight; 8-question GPU smoke test with two compact readers, two generation seeds, 12 conditions; 384 logical records and 348 generated outputs. A separate 88-call controlled calibration is complete. Neither reader passes its calibration gate. No selector is trained. Post-run format sensitivity is disclosed and original strict scores are retained.

The 50-case audit is **assistant case-level review**, not independent human annotation or 50 independent questions. Human verification fields remain blank. The returned 120-row human-audit sheet is also unfilled. The author must verify/correct the cases; do not represent this package as completed human annotation.

## Reproduce saved-output checks locally

Python 3.10+ is sufficient for the standard-library diagnostics and analysis tests; GPU dependencies are needed only for inference. From the repository root:

```sh
cd experiments/failure_pilot
python -m unittest test_integrity test_returned_analysis -v
python analyze_returned_run.py --run-root runs/ir_run1_20261018
python local_diagnostic.py
```

The frozen 200-question pools, source manifests, exact model revisions, raw output records and original/post-run summaries are included. The local diagnostic reads these fixed pools. `prepare_data.py` recreates source downloads if needed; it does not silently substitute another sample. Review its source URLs and manifests before downloading. Large upstream raw retrieval archives are deliberately excluded.

## Run the GPU pilot

Upload `experiments/failure_pilot/Evidence_Utility_Kaggle_Start.ipynb` to a GPU notebook and follow its instructions. Its source and frozen eight-question payload are embedded. Read `KAGGLE_START_HERE.md` first. Model versions are pinned in `sources/model_revisions.json`; observed package versions are recorded in the returned run's `raw/environment.json`. The original run used transformers 4.51.3, accelerate 1.6.0, torch 2.11.0+cu128 and NumPy 2.1.3. Install the CUDA-compatible PyTorch build for the actual host rather than assuming this exact wheel works everywhere.

`calibration_v2.py` reproduces the additional controls; its original outputs are under `runs/ir_run1_20261018/calibration_v2/raw/`. GPU reproduction can consume substantial free quota. No paid API key is required.

## Data and scoring limits

Official QAMPARI release: https://github.com/samsam3232/qampari . Upstream data, retrieval snippets, model checkpoints and third-party metadata remain subject to their original terms; this repository does not relicense them. Included frozen passage excerpts support reproducibility. Model weights and third-party paper PDFs are not included. Exact proof-span overlap is a diagnostic rather than complete semantic entailment, and unmatched reference names are not automatically false answers. Natural sparse/dense cached corpus alignment still needs confirmation.

## Reports and maintenance

`reports/project_context/` preserves dated reasoning, budgets and rejected/unapproved ideas. Read `PROJECT_MEMORY.md` there for history. These historical files are not evidence of completed experiments; the Stage 2 report and immutable run artifacts record current measured results. Budget figures are planning estimates and are not authorization to spend.

Commit a dated entry to CHANGELOG.md with each substantive experiment or analysis change. Keep original raw logs immutable, retain a config/hash manifest, and never commit API keys, model caches, browser session links or credentials. Repository publication and future maintenance are performed by the author.

The document-build scripts in `tools/` are preserved as delivery-generation provenance; they assume the original workspace layout and Windows Calibri fonts. The report Markdown is portable and editable independently.
