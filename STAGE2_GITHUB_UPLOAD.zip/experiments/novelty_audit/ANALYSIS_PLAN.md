# Limited novelty audit: plan fixed before diagnostic outcomes

Date: 18 October 2026. The user requests a novelty assessment through comparisons and experiments, then says to skip the larger GPU experiments for now. This audit therefore uses literature, algebra, and inexpensive calculations on existing public annotations. It will not train a language model, call an answer generator, or claim to validate the full proposed system.

## Questions

1. Does the proposed cross-context target supply information absent from ordinary marginal labels?
2. Can the proposed preference-reversal example arise from plain claim coverage, without reader reasoning or non-additive evidence support?
3. How much does disagreement between two published annotation models affect such a diagnostic?

## Data and sampling

- Use the pinned public CRUX snapshot recorded in `data/crux/source_manifest.json`.
- DUC04: all 50 topics. Multi-News: select 100 topic IDs by the ascending SHA-256 hash of `novelty-audit-v1:<topic_id>`, before looking at their coverage/reversal outcomes.
- Exclude report pseudo-documents. Keep only natural chunks (document IDs containing `#`). Cap at 50 chunks by deterministic document ID order. This is an annotation-pool diagnostic, NOT the professor's BM25+dense top-50 retrieval protocol.
- Fewer than four natural chunks means a topic cannot supply the paired-context design. Report all exclusions and denominators. Do not replace excluded topics by outcome-selected alternatives.
- Ratings are thresholded at >=3 for the primary calculation; >=4 is a declared sensitivity analysis. These are cached LLM answerability ratings, not new human labels or actual answer quality.
- Two published annotation files are available for DUC04 (Llama 3.1 and 3.3). Compare their results on the same chunk IDs and sampled contexts. They are annotators, NOT two answer generators.

## Paired contexts

For each eligible topic, sample 256 designs for each seed in [17,29,43]. Hold candidate chunks a,b fixed. Sample a common base of zero, one or two chunks, then distinct context chunks x,y. Let S1=base+x and S2=base+y. All indices in the design are distinct; both contexts have the same size.

F_proxy(S) = fraction of subquestions with at least one selected chunk rated above the threshold. This is ordinary monotone union coverage. It does not represent multi-hop AND support, generation, attribution correctness, contradiction, or the latest proposed grounded-answer F1 reward.

Calculate each candidate's marginal coverage and both within-context preference gaps. A strict reversal requires nonzero gaps of opposite signs. Record ties, both-context strict comparisons, reversal rates, and topic-level distributions. Resample topics, rather than treating within-topic designs as independent, for bootstrap intervals.

## Algebra and numerical checks

For residuals e=(e1a,e1b,e2a,e2b), the squared response error is (c^T e)^2, c=(1,-1,-1,1). Adding it to ordinary marginal MSE gives e^T(I+lambda cc^T)e. Verify equality numerically for 10,000 seeded random residual vectors and lambda in [0,0.25,1,4]. This check establishes reweighting of an existing error direction for this squared-loss version; it does not establish equivalence to every preference loss, nor that the reweighting cannot improve learning.

On the actual cached-coverage designs, verify:

- marginal gaps equal the difference between augmented set scores;
- the cross-context response equals the signed sum of four marginal labels;
- if ordinary labels are fitted exactly, response error is zero;
- the response squared error is at most four times the sum of squared marginal errors.

## Interpretation limits and decision

A nonzero reversal rate under pure coverage shows that reversals alone do not demonstrate a new interaction mechanism beyond coverage/diversity. An algebraically derived response label does not provide a new independent supervisory observation. Neither fact rules out a useful sampling strategy or regularizer. A positive research contribution still requires the deferred equal-data/equal-cost learned-system experiments with real grounded answers and held-out readers.

No claim of exhaustive literature novelty, no measured quality gain, and no trained-selector superiority will be made from this limited audit.

## Descriptive reporting amendment after the first run

The first result showed high agreement dominated by non-reversals. Add a trivial always-no-reversal reference, pooled conditional retention, direction-matched retention, and unique-design counts so that repeated designs and class imbalance are visible. These additions do not change topic selection, sampled designs, thresholds or the reversal definition. They are descriptive checks rather than new evidence of a learned method's performance.
