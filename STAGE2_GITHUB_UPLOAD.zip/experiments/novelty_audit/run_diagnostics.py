"""CPU-only diagnostic using released CRUX labels; no model training/inference."""
from __future__ import annotations

import argparse
import collections
import datetime
import hashlib
import json
import platform
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent


def load_ratings(path: Path):
    grouped = collections.defaultdict(dict)
    reports = 0
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            row = json.loads(line)
            if "#" not in row["docid"]:
                reports += 1
                continue
            if row["docid"] in grouped[row["id"]]:
                raise ValueError("Duplicate natural chunk")
            grouped[row["id"]][row["docid"]] = row["rating"]
    return grouped, reports


def stable_seed(topic: str, seed: int) -> int:
    value = hashlib.sha256(f"{topic}:{seed}".encode()).digest()
    return int.from_bytes(value[:8], "little")


def sample_designs(topic: str, n: int, count: int):
    designs = []
    for seed in [17, 29, 43]:
        rng = np.random.default_rng(stable_seed(topic, seed))
        for _ in range(count):
            base_size = int(rng.integers(0, min(2, n - 4) + 1))
            selected = rng.choice(n, size=base_size + 4, replace=False).tolist()
            base = selected[:base_size]
            x, y, a, b = selected[base_size:]
            designs.append((seed, base, x, y, a, b))
    return designs


def evaluate_designs(matrix, designs):
    nclaims = matrix.shape[1]
    records = []
    identity_error = 0.0
    for seed, base, x, y, a, b in designs:
        s1, s2 = base + [x], base + [y]
        covered1, covered2 = matrix[s1].any(axis=0), matrix[s2].any(axis=0)
        u1a = np.count_nonzero(matrix[a] & ~covered1)
        u1b = np.count_nonzero(matrix[b] & ~covered1)
        u2a = np.count_nonzero(matrix[a] & ~covered2)
        u2b = np.count_nonzero(matrix[b] & ~covered2)
        gap1, gap2 = int(u1a - u1b), int(u2a - u2b)
        scores = [np.count_nonzero(covered1 | matrix[a]),
                  np.count_nonzero(covered1 | matrix[b]),
                  np.count_nonzero(covered2 | matrix[a]),
                  np.count_nonzero(covered2 | matrix[b])]
        expected = (scores[0] - scores[1]) - (scores[2] - scores[3])
        identity_error = max(identity_error, abs((gap1-gap2)-expected))
        labels=np.array([u1a,u1b,u2a,u2b],dtype=float)/nclaims
        response=(gap1-gap2)/nclaims
        if not np.isclose(labels@np.array([1.,-1.,-1.,1.]),response,atol=1e-12):
            raise AssertionError("Response is not the contrast of ordinary labels")
        if float((labels-labels)@np.array([1.,-1.,-1.,1.]))!=0.0:
            raise AssertionError("Exact marginal fit did not imply exact response fit")
        records.append({"seed": seed, "base": base, "x": x, "y": y,
                        "a": a, "b": b, "gap1": gap1, "gap2": gap2,
                        "response": response,
                        "marginals": labels,
                        "reversal": gap1*gap2 < 0,
                        "both_strict": gap1 != 0 and gap2 != 0})
    return records, identity_error


def bootstrap_topic_means(values, seed=101, repeats=2000):
    values = np.asarray(values, dtype=float)
    if not len(values):
        return None
    rng = np.random.default_rng(seed)
    estimates = values[rng.integers(0,len(values),size=(repeats,len(values)))].mean(axis=1)
    return np.quantile(estimates,[0.025,0.975]).tolist()


def algebra_check():
    rng = np.random.default_rng(20261018)
    errors = rng.normal(size=(10000,4))
    c = np.array([1.0,-1.0,-1.0,1.0])
    contrast_error = errors@c
    squared = (errors**2).sum(axis=1)
    results = []
    for lam in [0.0,0.25,1.0,4.0]:
        direct = squared + lam*contrast_error**2
        weight = np.eye(4)+lam*np.outer(c,c)
        rewritten = np.einsum("ni,ij,nj->n", errors,weight,errors)
        diff = float(np.max(np.abs(direct-rewritten)))
        if not np.allclose(direct,rewritten,rtol=1e-12,atol=1e-12):
            raise AssertionError("Quadratic identity failed")
        results.append({"lambda":lam,"maximum_absolute_difference":diff,
                        "weight_eigenvalues":np.linalg.eigvalsh(weight).tolist()})
    if np.any(contrast_error**2 > 4*squared+1e-10):
        raise AssertionError("Cauchy-Schwarz bound failed")
    return {"residual_vectors":len(errors),"identities":results,
            "maximum_response_to_total_squared_error_ratio":float(np.max(contrast_error**2/squared)),
            "exact_fit_response_error":0.0,
            "interpretation":"Squared auxiliary response loss reweights a direction of existing marginal residuals; no independent labels."}


def known_case_checks():
    # A two-aspect union-coverage problem has a preference reversal with no
    # reasoning interaction: context x covers a's aspect and y covers b's.
    matrix=np.array([[1,0],[0,1],[1,0],[0,1]],dtype=bool)
    record,_=evaluate_designs(matrix,[(17,[],0,1,2,3)])
    if (record[0]["gap1"],record[0]["gap2"])!=(-1,1):
        raise AssertionError("Known pure-coverage reversal was not recovered")
    zero,_=evaluate_designs(np.zeros((4,2),dtype=bool),[(17,[],0,1,2,3)])
    if zero[0]["reversal"] or zero[0]["both_strict"]:
        raise AssertionError("All-zero coverage produced a strict preference")
    for _,base,x,y,a,b in sample_designs("known",6,20):
        indices=base+[x,y,a,b]
        if len(set(indices))!=len(indices):
            raise AssertionError("Context/candidate overlap in design")
    return {"pure_coverage_reversal":True,"all_zero_ties":True,"design_indices_disjoint":True}


def run(config):
    data = ROOT/"data/crux"
    duc, duc_reports = load_ratings(data/"crux-mds-duc04/judge/ratings.Llama-3.1-70B-Instruct.0-1.jsonl")
    duc_alt, _ = load_ratings(data/"crux-mds-duc04/judge/v2/ratings.Llama-3.3-70B-Instruct.0-1.jsonl")
    news, news_reports = load_ratings(data/"crux-mds-multi_news/judge/ratings.Llama-3.1-70B-Instruct.0-1.jsonl")
    news_ids = sorted(news, key=lambda q:hashlib.sha256(f"novelty-audit-v1:{q}".encode()).hexdigest())[:config.news_topics]
    selected = [("duc04",q,duc[q]) for q in sorted(duc)] + [("multi_news",q,news[q]) for q in news_ids]
    results = {"status":"limited_annotation_diagnostic_not_model_validation",
               "run_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "python":platform.python_version(),"numpy":np.__version__,
               "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               "analysis_plan_sha256":hashlib.sha256((ROOT/"ANALYSIS_PLAN.md").read_bytes()).hexdigest(),
               "configuration":{"seeds":[17,29,43],"designs_per_seed_topic":config.designs,
                                "thresholds":[3,4],"candidate_cap":50,"news_topics":config.news_topics},
               "source_snapshot":json.loads((data/"source_manifest.json").read_text()),
               "source_counts":{"duc04_topics":len(duc),"multi_news_topics":len(news),
                                "excluded_report_rows":duc_reports+news_reports},
               "algebra":algebra_check(),"known_case_checks":known_case_checks(),
               "coverage_diagnostic":{},"annotation_disagreement":{}}
    topic_rows = []
    example_rows = []
    selected_ids = []
    for threshold in [3,4]:
        per_dataset = collections.defaultdict(list)
        agreement_rows=[]
        for dataset,q,docs in selected:
            ids = sorted(docs)[:50]
            if len(ids)<4:
                if threshold==3: selected_ids.append({"dataset":dataset,"id":q,"eligible":False,"chunks":len(ids)})
                continue
            if threshold==3: selected_ids.append({"dataset":dataset,"id":q,"eligible":True,"chunks":len(ids)})
            raw=np.asarray([docs[d] for d in ids],dtype=int)
            matrix=raw>=threshold
            designs=sample_designs(q,len(ids),config.designs)
            records,error=evaluate_designs(matrix,designs)
            if error != 0: raise AssertionError("Measured marginal response identity failed")
            reversals=sum(r["reversal"] for r in records)
            strict=sum(r["both_strict"] for r in records)
            row={"dataset":dataset,"id":q,"threshold":threshold,"chunks":len(ids),
                 "subquestions":matrix.shape[1],"designs":len(records),"reversals":reversals,
                 "both_strict":strict,"reversal_rate":reversals/len(records),
                 "reversal_rate_given_both_strict":reversals/strict if strict else None,
                 "maximum_identity_error":error}
            row["unique_membership_designs"]=len({(tuple(sorted(r["base"])),r["x"],r["y"],r["a"],r["b"]) for r in records})
            topic_rows.append(row);per_dataset[dataset].append(row)
            if threshold==3 and len(example_rows)<12:
                for r in records:
                    if r["reversal"]:
                        example_rows.append({"dataset":dataset,"id":q,"claim_threshold":threshold,
                                             "candidate_a":ids[r["a"]],"candidate_b":ids[r["b"]],
                                             "context1":[ids[i] for i in r["base"]+[r["x"]]],
                                             "context2":[ids[i] for i in r["base"]+[r["y"]]],
                                             "gap1_claims":r["gap1"],"gap2_claims":r["gap2"],
                                             "note":"Pure OR coverage from cached annotations; no generated answers."})
                        break
            if dataset=="duc04":
                missing=[d for d in ids if d not in duc_alt[q]]
                if missing: raise ValueError("Alternative annotation lacks matched chunks")
                matrix2=np.asarray([duc_alt[q][d] for d in ids],dtype=int)>=threshold
                alt,_=evaluate_designs(matrix2,designs)
                status1=np.array([r["reversal"] for r in records])
                status2=np.array([r["reversal"] for r in alt])
                signs1=np.array([[np.sign(r["gap1"]),np.sign(r["gap2"])] for r in records])
                signs2=np.array([[np.sign(r["gap1"]),np.sign(r["gap2"])] for r in alt])
                agreement_rows.append({"id":q,"reversal_status_agreement":float(np.mean(status1==status2)),
                                       "both_annotators_reversal_rate":float(np.mean(status1&status2)),
                                       "either_annotator_reversal_rate":float(np.mean(status1|status2)),
                                       "preference_sign_agreement_including_ties":float(np.mean(signs1==signs2)),
                                       "primary_reversal_retention":float(np.sum(status1&status2)/np.sum(status1)) if np.any(status1) else None,
                                       "designs":len(records),"primary_reversals":int(status1.sum()),
                                       "secondary_reversals":int(status2.sum()),
                                       "both_reversals":int((status1&status2).sum()),
                                       "either_reversals":int((status1|status2).sum()),
                                       "direction_matched_reversals":int((status1&status2&np.all(signs1==signs2,axis=1)).sum())})
        summaries={}
        for name,rows in per_dataset.items():
            n=sum(r["designs"] for r in rows);rev=sum(r["reversals"] for r in rows);strict=sum(r["both_strict"] for r in rows)
            summaries[name]={"eligible_topics":len(rows),"designs":n,"reversals":rev,
                             "unique_membership_designs":sum(r["unique_membership_designs"] for r in rows),
                             "reversal_rate":rev/n,"both_strict":strict,
                             "reversal_rate_given_both_strict":rev/strict if strict else None,
                             "topics_with_reversals":sum(r["reversals"]>0 for r in rows),
                             "topic_mean_reversal_rate_ci95":bootstrap_topic_means([r["reversal_rate"] for r in rows])}
        results["coverage_diagnostic"][str(threshold)]=summaries
        total_designs=sum(r["designs"] for r in agreement_rows)
        primary=sum(r["primary_reversals"] for r in agreement_rows)
        both=sum(r["both_reversals"] for r in agreement_rows)
        either=sum(r["either_reversals"] for r in agreement_rows)
        direction_matched=sum(r["direction_matched_reversals"] for r in agreement_rows)
        results["annotation_disagreement"][str(threshold)]={"topics":len(agreement_rows),
            "pooled":{"designs":total_designs,"primary_reversals":primary,"both_reversals":both,
                      "direction_matched_reversals":direction_matched,
                      "primary_reversal_retention":both/primary if primary else None,
                      "direction_matched_primary_reversal_retention":direction_matched/primary if primary else None,
                      "reversal_jaccard":both/either if either else None,
                      "always_no_reversal_accuracy_against_primary":1-primary/total_designs},
            "means":{key:float(np.mean([r[key] for r in agreement_rows if r[key] is not None]))
                     for key in agreement_rows[0] if key not in {"id","designs","primary_reversals","secondary_reversals","both_reversals","either_reversals","direction_matched_reversals"}},"per_topic":agreement_rows}
    results["selected_topics"]=selected_ids
    results["limitations"]=["No generator inference or selector training.",
                            "CRUX coverage proxy rather than grounded answer F1.",
                            "No BM25+dense retrieval or token-length/order control.",
                            "Annotation model replication is not reader transfer.",
                            "Sampled designs include repeats; topic bootstrap is used for intervals.",
                            "Nonzero reversals can be explained entirely by ordinary coverage."]
    output=ROOT/"results";output.mkdir(parents=True,exist_ok=True)
    (output/"diagnostic_results.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
    (output/"per_topic.jsonl").write_text("".join(json.dumps(r)+"\n" for r in topic_rows),encoding="utf-8")
    (output/"reversal_examples.jsonl").write_text("".join(json.dumps(r)+"\n" for r in example_rows),encoding="utf-8")
    print(json.dumps({"status":results["status"],"coverage":results["coverage_diagnostic"],
                      "annotation_agreement":{k:{"means":v["means"],"pooled":v["pooled"]} for k,v in results["annotation_disagreement"].items()},
                      "algebra":results["algebra"],"exclusions":sum(not x["eligible"] for x in selected_ids)},indent=2))


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--news-topics",type=int,default=100)
    parser.add_argument("--designs",type=int,default=256)
    run(parser.parse_args())
