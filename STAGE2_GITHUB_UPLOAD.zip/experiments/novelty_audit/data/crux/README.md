---
license: apache-2.0
language:
- en
tags:
- retrieval
pretty_name: crux
---

# CRUX dataset 
The CRUX data has the following structure:
```
crux                        # root
├── crux-mds-duc04          
│   ├── judge               # crux ratings (answerability judgements)
│   ├── qrels               # crux diversity qrels
│   ├── report              # **oracle ground-truth** RAG result
│   ├── run                 # first-stage results
│   ├── subtopics           # crux sub-questions
│   └── topic               # crux queries (report requests)
│
├── crux-mds-multi_news
├── crux-neuclir
├── crux-ragtime
├── crux-biogen
├── crux-researchy
```
Regarding the corpus, please refer to [CRUX-mds-corpus](https://huggingface.co/datasets/DylanJHJ/crux-mds-corpus).



# Update
- 2025-10-06: Upload two crux-mds subsets: crux-mds-duc04 and crux-mds-multi_news. We recommend to use the loading script in [crux-repo](https://github.com/DylanJoo/crux)

# Download data
```shell
git lfs install
git clone https://huggingface.co/datasets/DylanJHJ/crux
export CRUX_ROOT=/mydataset/crux
```
# Data overview

| Subset (splits)             | #Topics | #Sub-questions | #Docs  | Note                                          |
|-----------------------------|---------|----------------|--------|-----------------------------------------------|
| crux-mds-duc04 (test)       | 30      | 15             | 0.5M   | TREC DUC 2004                                 |
| crux-mds-multi_news (test)  | 4983\*  | 10             | 0.5M   | [Paper](https://aclanthology.org/P19-1102/)   |
| crux-neuclir (test)         | 19/21   | 13.63          | 10M    | TREC NeuCLIR 2024 Report Generation           |
| crux-ragtime (test)         | ??      | ?????          | ??M    | TREC RAGTIME 2025 Report Generation           |
| crux-biogen (test)          | ??      | ??             | ??M    | TREC BioGen 2025 Answer Generation            |
| crux-researchy (test)       | ????    | ??             | ??M    | [Paper](https://arxiv.org/abs/2402.17896)     |
\* We only evaluate 100 topics in the current snapshot. The full set is TBD.

In addition, we also provide a training set for the researchy subset.
| Subset (splits)             | #Topics | #Sub-questions | #Docs  | Note                                          |
|-----------------------------|---------|----------------|--------|-----------------------------------------------|
| crux-researchy (train)      | 90000   | ??             | ??M    | TBD                                           |


# Citation
```bibtex
@misc{ju2025controlledretrievalaugmentedcontextevaluation,
      title={Controlled Retrieval-augmented Context Evaluation for Long-form RAG}, 
      author={Jia-Huei Ju and Suzan Verberne and Maarten de Rijke and Andrew Yates},
      year={2025},
      eprint={2506.20051},
      archivePrefix={arXiv},
      primaryClass={cs.IR},
      url={https://arxiv.org/abs/2506.20051}, 
}
```
