# Failure-first pilot: prospective plan

Date: 18 October 2026. Status: execution preparation; no verified improvement yet.

The user has approved the three-step investigation and offered a Kaggle notebook. This resumes preparation for real model experiments. It does not authorize paid services, publication, or treating a hypothesis as a result. Original project sources remain unchanged.

## 1. Data and isolation

- Use the official QAMPARI **development** questions and their released natural BM25 and DPR rankings. Do not use the `*_gold` retrieval files or insert reference evidence. Do not read the test split during exploration.
- Join questions by checked identifiers and normalized question text. Assert compatible passage identities; record conflicts rather than silently merging them.
- Deduplicate identical passages; reciprocal-rank fuse the two released rankings with constant 60 and retain exactly 50 where available. Freeze this pool for every selector. These are the original authors' cached retrieval runs, not newly trained retrievers.
- Choose 200 questions by an outcome-independent SHA-256 order of `COL764-failure-pilot-v1|question_id`. The first 100 are discovery, the next 100 are confirmation. Sampling precedes answer generation. Do not move questions between groups after inspecting results.
- Model smoke test: the first eight discovery questions. No learned selector is trained on these questions. Training, if justified, must use separate training questions.
- Preserve raw downloaded members, archive metadata, hashes, sample IDs, configurations and code hashes. Only download needed development members via byte ranges; verify ZIP CRCs.

## 2. First local check: candidate-pool and selection diagnosis

**Prospective data-availability amendment, before selection outcomes:** both natural retrieval files contain the same 990 development IDs; ten official questions lack cached retrieval. All 200 questions already selected from the original 1,000-question hash order are available, so no sample is replaced. Save the ten unavailable IDs. BM25 uses page/chunk IDs while DPR uses numeric IDs. Namespace both schemes and deduplicate only exact normalized title/text matches; never equate different IDs by appearance. Corpus snapshot alignment has not been independently established, so label these cached-release results as a preflight. A publication-level confirmation should verify aligned retrieval provenance or repeat with aligned indexes. Different ID formats alone do not prove different snapshot dates.

Before any generator run, compare fusion top-k, lexical MMR, and a reference-alias coverage diagnostic at k=5. Run k=3,8,10 as secondary checks. Lexical MMR is a cheap preliminary baseline; the GPU pilot must also use tuned dense MMR and a relevance cross-encoder.

Reference-alias occurrence is **not** proof of relation support, correct generated claims, or citation quality. An alias-coverage selector uses gold answers and is a diagnostic oracle proxy, not a deployable method. Its greedy solution is not a global upper bound. Report the union's alias coverage separately from attainable selection quality. Any gaps here motivate inspection only.

Run a diagnostic exact maximum-coverage solver on the small fixed-k alias game if feasible, with time limits and optimality bounds. A constructed or proxy greedy failure is not a new algorithmic contribution. Lookahead, submodularity, complementary selection and set-aware scoring already have prior art.

## 3. Kaggle smoke test before the larger experiment

Freeze two ungated reader families and record repository revisions. Initial candidates are Qwen2.5-3B-Instruct and SmolLM2-1.7B-Instruct; confirm quality before scaling. Use identical evidence and rendering for both readers, a fixed prompt, short answers with passage IDs, and no gold answers in prompts.

The first run should generate actual answers for eight discovery questions and all smoke-test evidence sets. Export raw prompts, outputs, configurations, durations and failures. If readers cannot follow the format or reliably answer questions with clearly sufficient evidence, stop and change reader configuration before the main pilot. Do not treat a weak reader's random errors as a new evidence-selection failure.

Use a common evidence-token cap, counting titles and IDs, and log actual reader-token lengths. Match the selected evidence across readers; record family-specific prompt lengths. k alone is not a token budget. A conservative frozen per-passage rendering is allowed if it fits both readers' cap; do not silently truncate only one method's evidence.

## 4. Failure identification with real reader outputs

After the smoke test is inspected, extend to 100 discovery questions. Compare relevance, tuned dense MMR, submodular/reference coverage diagnostics, a credible released compact utility selector where compatible, and ordinary measured marginal selection. Label approximations must be named as approximations.

Classify: retrieval ceiling; redundant answer coverage; complementary evidence; unsupported but memorized answers; reader instability; order/length effects; and evaluator error. Existing categories are not novelty claims. Seek a reproducible residual failure that strong baselines still exhibit.

For insertion/deletion probes hold question, candidate pool, passage rendering and decoding fixed; use nonempty selected sets. Count all baseline, candidate, screening, repeated, evaluation and failed generation calls. Separate sampled marginal probes from exhaustive next-candidate search.

Do not infer support merely because a correct entity occurs in a cited passage. Use independently audited claim/evidence decisions, with relation support and valid citations. Automatic support judgments are provisional until calibrated against human checks. Do not use the labeling reader as its own final judge. Repeated draws and no-change controls estimate ordinary generation variation.

## 5. Method decision and decisive comparison

Only propose a modification after inspecting the failure. Write the mechanism, expected remedy, closest prior methods and falsifying comparison before evaluating confirmation questions. Do not invent a loss term and then search for favorable cases.

Use the same backbone, data access, evidence budget, optimization allowance and complete annotation expenditure for ordinary marginal training and the modification. Separate training-data acquisition changes from objective changes with same-data controls. Include relevance, tuned MMR, submodular coverage, ordinary set-aware marginal training, and relevant existing learned set/utility selectors. A fixed-linear-target reparameterization does not need redundant training.

Primary endpoint: supported correct answer coverage at a common evidence-token cap, with attributed precision/contradiction reported separately. Secondary: answer correctness, redundancy, retrieval metrics, latency and full label cost. Evaluate the identical selected evidence with a held-out reader family without retuning.

Report per-question paired differences and question-level bootstrap confidence intervals; do not count passages or repeated generations as independent questions. Lock the primary comparison before confirmation. The 100-question confirmation subset is exploratory-scale and does not guarantee power. No pass/fail threshold alone establishes publishability.

## 6. Budget and advancement gates

- No paid API, rental or external annotator operation is enabled.
- Full 50-to-5 measured greedy requires 240 candidate-set generations plus one initial baseline per question and reader/repetition, with compatible caching.
- Five sampled contexts and four additions each require at most 25 set generations per question before repeats/judging. This does not perform exhaustive greedy selection.
- Smoke-test and full-pilot budgets are distinct; save incremental outputs so a Kaggle interruption does not discard results.
- Advance to training only after a stable, sufficiently prevalent failure is established and a precise, literature-distinct remedy is justified. Otherwise report that no verified methodological improvement was found.
- Revise the proposal with results that actually exist. Mark unrun experiments and unverified hypotheses explicitly. Never turn a lexical coverage result into a grounded-generation claim.
