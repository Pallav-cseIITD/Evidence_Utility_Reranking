"""Audit saved reader outputs; no model/API calls and no raw-file changes."""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
from pathlib import Path
import statistics

from benchmark import (alias_masks, digest, load_jsonl, normalize, parse_answer_output,
                       proof_masks, reference_metrics, union_mask, write_jsonl)
from run_kaggle import messages_for


def extract_content(text):
    """Explicit structural sensitivity parser. No repairs to incomplete JSON."""
    original, error = parse_answer_output(text)
    if error is None:
        return original, "strict", None
    stripped = text.strip()
    if stripped.startswith("```"):
        parts = stripped.split("\n", 1)
        if len(parts) != 2:
            return None, "unextractable", "Unclosed opening code fence"
        stripped = parts[1].strip()
        if stripped.endswith("```"):
            stripped = stripped[:-3].strip()
    if not stripped.startswith(("{", "[")):
        return None, "unextractable", "No JSON value at output start"
    try:
        root, end = json.JSONDecoder().raw_decode(stripped)
    except (json.JSONDecodeError, ValueError) as exc:
        return None, "unextractable", "Incomplete/invalid JSON: " + str(exc)
    suffix = stripped[end:].strip()
    if "{" in suffix or "[" in suffix:
        return None, "unextractable", "Possible additional structured answer in suffix"
    if isinstance(root, list):
        wrapped = {"answers": root}
        mode = "complete_prefix_list" if suffix else "top_level_list"
    elif isinstance(root, dict):
        wrapped = root
        mode = "complete_prefix_object" if suffix else "fenced_object"
    else:
        return None, "unextractable", "Unexpected JSON root type"
    answers, schema_error = parse_answer_output(json.dumps(wrapped, ensure_ascii=False))
    if schema_error:
        return None, "unextractable", "Wrong answer schema: " + schema_error
    return answers, mode, suffix or None


def measured(row, answers, evidence):
    metrics = reference_metrics(row, answers or [])
    gold = [{normalize(a) for a in g["aliases"]} for g in row["answers"]]
    evidence_masks = dict(zip([d["id"] for d in evidence],
        proof_masks(row, [{"title": "", "text": d["rendered"]} for d in evidence])))
    supported = set()
    for answer in answers or []:
        matching = {i for i, variants in enumerate(gold) if normalize(answer["answer"]) in variants}
        for i in matching:
            if any(evidence_masks.get(c, 0) & (1 << i) for c in answer["citations"]):
                supported.add(i)
    metrics["exact_proof_attributed_indices"] = sorted(supported)
    metrics["exact_proof_attributed_recall"] = len(supported) / len(gold)
    citations = [c for a in answers or [] for c in a["citations"]]
    allowed = {d["id"] for d in evidence}
    metrics["valid_citation_id_fraction"] = sum(c in allowed for c in citations) / len(citations) if citations else None
    return metrics


def question_mean(items, field):
    groups = collections.defaultdict(list)
    for item in items:
        value = item[field]
        if value is not None:
            groups[item["qid"]].append(float(value))
    return statistics.mean(statistics.mean(g) for g in groups.values()) if groups else None


def analyze(run_root, pilot_root):
    run_root, pilot_root = Path(run_root), Path(pilot_root)
    raw = run_root / "raw"
    records = list(load_jsonl(raw / "generations.jsonl"))
    pools = list(load_jsonl(raw / "smoke_pools.jsonl"))
    rendered = list(load_jsonl(raw / "rendered_pools.jsonl"))
    questions = {r["qid"]: r for r in pools}
    render_by_id = {r["qid"]: r for r in rendered}
    environment = json.loads((raw / "environment.json").read_text(encoding="utf-8"))
    selections = json.loads((raw / "selections.json").read_text(encoding="utf-8"))
    attempts = list(load_jsonl(raw / "generation_attempts.jsonl"))
    sample = json.loads((raw / "sample_manifest.json").read_text(encoding="utf-8"))
    assert [r["qid"] for r in pools] == sample["smoke_test_ids"]
    assert all(q not in sample["confirmation_ids"] for q in questions)
    assert len(questions) == 8 and len(records) == 384
    assert all(r["split"] == "discovery" and len(r["passages"]) == 50 for r in pools)
    local_pools = list(load_jsonl(pilot_root / "data" / "pools.jsonl"))[:8]
    assert pools == local_pools, "Returned sample differs from frozen data"
    source_names = ["benchmark.py", "run_kaggle.py", "prepare_data.py", "local_diagnostic.py", "test_integrity.py"]
    assert all((raw / name).read_bytes() == (pilot_root / name).read_bytes() for name in source_names)
    assert len({r["record_id"] for r in records}) == 384
    readers = sorted({r["reader"] for r in records})
    methods = sorted({r["method"] for r in records})
    grid = {(r["qid"], r["reader"], r["method"], r["seed"]) for r in records}
    expected = {(q, reader, method, seed) for q in questions for reader in readers for method in methods for seed in [17, 29]}
    assert grid == expected and len(methods) == 12
    cache = {}
    completed = set()
    for r in records:
        assert r["record_id"] == digest(r["qid"] + r["method"] + r["cache_key"])
        assert r["decoding"] == environment["decoding"]
        assert r["model_revision"] == environment["models"][r["reader"]]["revision"]
        assert max(r["evidence_tokens_by_reader"]) <= 1280
        if r.get("attempt_id"):
            completed.add(r["attempt_id"])
        if r["cache_key"] in cache:
            old = cache[r["cache_key"]]
            for key in ["output", "messages", "seed", "reader", "prompt_sha256", "input_tokens", "output_tokens"]:
                assert old[key] == r[key], (r["record_id"], key)
        cache[r["cache_key"]] = r
        expected_messages = messages_for(questions[r["qid"]]["question"], r["evidence"], r["method"] == "closed_book_CONTROL")
        assert r["messages"] == expected_messages, "Prompt mismatch"
        if r["method"] not in ["closed_book_CONTROL", "shuffled_question_context_CONTROL"]:
            indices = selections[r["qid"]]["selections"][r["method"]]
            expected_docs = [render_by_id[r["qid"]]["passages"][i] for i in sorted(indices)]
            assert [d["rendered"] for d in r["evidence"]] == [d["rendered"] for d in expected_docs]
    assert len(cache) == len(attempts) == 348
    assert {a["attempt_id"] for a in attempts} == completed
    for q in questions:
        for method in methods:
            matched = [r for r in records if r["qid"] == q and r["method"] == method]
            assert len({json.dumps(r["evidence"], sort_keys=True) for r in matched}) == 1
    identity = {"models": environment["models"], "decoding": environment["decoding"], "seeds": environment["seeds"],
                "data_sha256": hashlib.sha256((raw / "smoke_pools.jsonl").read_bytes()).hexdigest(),
                "code_sha256": hashlib.sha256((raw / "run_kaggle.py").read_bytes()).hexdigest(),
                "benchmark_sha256": hashlib.sha256((raw / "benchmark.py").read_bytes()).hexdigest()}
    assert digest(json.dumps(identity, sort_keys=True)) == environment["run_signature"]
    analyzed = []
    for r in records:
        strict, strict_error = parse_answer_output(r["output"])
        content, mode, detail = extract_content(r["output"])
        row = questions[r["qid"]]
        a = {"record_id": r["record_id"], "qid": r["qid"], "reader": r["reader"],
             "method": r["method"], "seed": r["seed"], "cache_hit": r["cache_hit"],
             "strict_valid": strict_error is None, "strict_error": strict_error,
             "strict_valid_empty": strict_error is None and not strict,
             "content_extractable": content is not None, "content_mode": mode,
             "content_detail": detail, "content_valid_empty": content is not None and not content,
             "truncated": r["hit_max_new_tokens"], "evidence_tokens": max(r["evidence_tokens_by_reader"]),
             "strict_answers": strict, "content_answers": content,
             "strict_metrics": measured(row, strict, r["evidence"]),
             "content_metrics": measured(row, content, r["evidence"])}
        analyzed.append(a)
    groups = {}
    for reader in readers:
        for method in methods + ["ALL"]:
            group = [a for a in analyzed if a["reader"] == reader and (method == "ALL" or a["method"] == method)]
            flat = []
            for a in group:
                flat.append({"qid": a["qid"], "strict_valid": a["strict_valid"],
                    "strict_valid_empty": a["strict_valid_empty"], "extractable": a["content_extractable"],
                    "content_valid_empty": a["content_valid_empty"], "truncated": a["truncated"],
                    "strict_recall": a["strict_metrics"]["reference_recall"],
                    "content_recall_zero_if_unextractable": a["content_metrics"]["reference_recall"],
                    "content_precision_zero_if_unextractable": a["content_metrics"]["reference_precision"],
                    "exact_proof_attributed_recall_zero_if_unextractable": a["content_metrics"]["exact_proof_attributed_recall"],
                    "content_recall_conditional_on_extractable": a["content_metrics"]["reference_recall"] if a["content_extractable"] else None})
            groups[reader + "|" + method] = {"records": len(group),
                "n_questions": len({a["qid"] for a in group}),
                "modes": dict(collections.Counter(a["content_mode"] for a in group)),
                **{key: question_mean(flat, key) for key in flat[0] if key != "qid"}}
    # Compare original strict summary values without rewriting them.
    original = json.loads((raw / "smoke_summary.json").read_text(encoding="utf-8"))
    for key, old in original["groups"].items():
        assert abs(groups[key]["strict_recall"] - old["reference_recall"]) < 1e-12
        assert abs(groups[key]["strict_valid"] - old["format_valid"]) < 1e-12
    by_condition = {(a["reader"], a["qid"], a["method"], a["seed"]): a for a in analyzed}
    transitions = []
    for reader in readers:
        for q in questions:
            for addition in ["probe_add_ce3", "probe_add_diverse3"]:
                for seed in [17, 29]:
                    before = by_condition[reader, q, "probe_base2", seed]
                    after = by_condition[reader, q, addition, seed]
                    transition = {"reader": reader, "qid": q, "addition": addition, "seed": seed,
                                  "both_extractable": before["content_extractable"] and after["content_extractable"],
                                  "both_strict_valid": before["strict_valid"] and after["strict_valid"]}
                    for metric in ["matched_gold_indices", "exact_proof_attributed_indices"]:
                        b = set(before["content_metrics"][metric]); a = set(after["content_metrics"][metric])
                        transition[metric] = {"before": sorted(b), "after": sorted(a),
                                              "gain": sorted(a-b), "loss": sorted(b-a), "delta": len(a)-len(b)}
                    transitions.append(transition)
    repeats = []
    for reader in readers:
        for q in questions:
            for method in methods:
                a, b = [by_condition[reader, q, method, seed] for seed in [17, 29]]
                row = {"reader": reader, "qid": q, "method": method,
                       "both_extractable": a["content_extractable"] and b["content_extractable"]}
                for metric in ["matched_gold_indices", "exact_proof_attributed_indices"]:
                    aa, bb = set(a["content_metrics"][metric]), set(b["content_metrics"][metric])
                    row[metric] = {"symmetric_difference": len(aa^bb), "delta": len(bb)-len(aa)}
                repeats.append(row)
    runtime = {}
    for reader in readers:
        unique = [r for r in records if r["reader"] == reader and not r["cache_hit"]]
        times = sorted(r["seconds"] for r in unique)
        runtime[reader] = {"new_generations": len(unique), "logical_records": sum(r["reader"] == reader for r in records),
                           "input_tokens": sum(r["input_tokens"] for r in unique),
                           "output_tokens": sum(r["output_tokens"] for r in unique),
                           "summed_generation_seconds": sum(times), "median_call_seconds": statistics.median(times)}
    headroom = []
    for row in rendered:
        docs = [{"title": "", "text": d["rendered"]} for d in row["passages"]]
        aliases, proofs = alias_masks(row, docs), proof_masks(row, docs)
        item = {"qid": row["qid"], "question": row["question"], "gold_answers": len(row["answers"]),
                "all50_alias_count": union_mask(aliases, range(50)).bit_count(),
                "all50_exact_proof_count": union_mask(proofs, range(50)).bit_count(), "methods": {}}
        for method, selected in selections[row["qid"]]["selections"].items():
            item["methods"][method] = {"alias_count": union_mask(aliases, selected).bit_count(),
                                       "exact_proof_count": union_mask(proofs, selected).bit_count()}
        headroom.append(item)
    summary = {"status": "Completed smoke run; post-run format sensitivity; no new selector evaluated",
        "integrity": {"logical_records": len(records), "unique_generations": len(cache), "cache_hits": sum(r["cache_hit"] for r in records),
                      "generation_attempts": len(attempts), "incomplete_attempts": 0, "source_files_match": True,
                      "expected_grid_complete": True, "shared_evidence_verified": True, "confirmation_used": False,
                      "maximum_logged_evidence_tokens": max(a["evidence_tokens"] for a in analyzed)},
        "groups": groups, "runtime": runtime,
        "limitations": ["Eight discovery questions, not independent 384-question evidence.",
            "Content extraction is a disclosed post-run sensitivity analysis.",
            "Unextractable outputs count as zero in all-output scores and as missing in extraction-conditional scores.",
            "Exact annotated-proof attribution misses alternative valid support.",
            "Reference-unmatched entities are not automatically false facts.",
            "No human annotations returned; assistant inspection is not a human audit.",
            "Released utility selectors and ordinary marginal training were not evaluated.",
            "Two seed draws do not establish reliable marginal labels or broad reader transfer."],
        "analysis_code_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "analysis_plan_sha256": hashlib.sha256((run_root / "ANALYSIS_PLAN.md").read_bytes()).hexdigest()}
    out = run_root / "analysis"; out.mkdir(exist_ok=True)
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_jsonl(out / "per_output.jsonl", analyzed)
    write_jsonl(out / "insertion_transitions.jsonl", transitions)
    write_jsonl(out / "same_state_repeats.jsonl", repeats)
    write_jsonl(out / "rendered_coverage.jsonl", headroom)
    print(json.dumps({"integrity": summary["integrity"], "runtime": runtime,
        "reader_aggregates": {reader: groups[reader + "|ALL"] for reader in readers}}, indent=2))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-root", type=Path, default=Path(__file__).resolve().parent / "runs" / "ir_run1_20261018")
    args = parser.parse_args()
    analyze(args.run_root, Path(__file__).resolve().parent)
