# Run the first GPU check

Use `Evidence_Utility_Kaggle_Start.ipynb` in this folder. It contains the experiment code and the eight selected questions, so no companion data upload is needed.

1. Create a notebook at https://www.kaggle.com/code . Keep it private.
2. In the notebook editor choose **File → Import Notebook** and upload `Evidence_Utility_Kaggle_Start.ipynb`.
3. In notebook settings, turn **Internet** on and select an available **GPU**. A single 16 GB GPU is enough; two GPUs are optional.
4. Choose **Run All**. Leave the session running until it finishes or reports an error.
5. Download **evidence_pilot_results.zip** from the final cell or the notebook's output files. Attach that ZIP to the project chat. If it fails before producing a ZIP, send the error text.

No password, secret key, or public notebook link is required. Official notebook help: https://www.kaggle.com/docs/notebooks . If Kaggle requires account verification before enabling GPU or Internet, complete its own account setup first.

The first run downloads roughly 10 GB of public model weights and uses your available Kaggle GPU quota. It does not use paid APIs, rent GPUs, train a selector, publish a notebook, or run the confirmation set. The smoke test is capped at eight questions, two reader families, two sampled repetitions, 384 logical generations before exact-cache savings, and a three-hour execution limit after setup. Model/package downloads can take additional time. This is a cap, not a measured runtime estimate.

The output includes raw answers/citations, the evidence supplied to each reader, reference-match diagnostics, a conservative annotated-proof attribution measure, timings, token counts, model revisions, and a blank blinded audit sheet. Results are saved incrementally. A failed or interrupted generation attempt is logged separately where the program has reached that stage.

Local data and scoring checks pass. The notebook's GPU execution has not yet been tested. First we will inspect whether the readers can use clear evidence and whether the measurements are reliable. Then we will run the larger pilot, identify a residual failure, design a targeted remedy, and compare it with ordinary marginal training and strong existing selectors before claiming an improvement in the revised proposal.
