"""Real QAMPARI retrieval preflight, not an end-to-end RAG experiment."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import numpy as np
from benchmark import (alias_masks, coverage_greedy, lexical_mmr, load_jsonl,
                       proof_masks, union_mask, write_jsonl)


def exact_coverage(masks, k=5, node_limit=20000):
    """Bounded branch-and-bound in a unit-cost OR-coverage diagnostic game."""
    full = union_mask(masks, range(len(masks)))
    seed = coverage_greedy(masks, k)
    best = union_mask(masks, seed)
    unique = sorted(set(masks) - {0}, key=lambda m: (-m.bit_count(), m))
    # Under equal unit cost, a strict subset mask is dominated.
    undominated = [m for m in unique if not any(m != n and m & n == m for n in unique)]
    suffix = [0] * (len(undominated) + 1)
    for i in range(len(undominated) - 1, -1, -1):
        suffix[i] = suffix[i + 1] | undominated[i]
    nodes, hit_limit = 0, False

    def search(i, left, covered):
        nonlocal best, nodes, hit_limit
        if covered.bit_count() > best.bit_count():
            best = covered
        if best == full or left == 0 or i == len(undominated):
            return
        if (covered | suffix[i]).bit_count() <= best.bit_count():
            return
        gains = sorted(((m & ~covered).bit_count() for m in undominated[i:]), reverse=True)
        if covered.bit_count() + sum(gains[:left]) <= best.bit_count():
            return
        if nodes >= node_limit:
            hit_limit = True
            return
        nodes += 1
        search(i + 1, left - 1, covered | undominated[i])
        search(i + 1, left, covered)
    search(0, k, 0)
    return {"best_count": best.bit_count(), "greedy_count": union_mask(masks, seed).bit_count(),
            "optimal_certified": not hit_limit or best == full, "nodes": nodes,
            "upper_bound_count": best.bit_count() if not hit_limit or best == full else full.bit_count()}


def bootstrap(values):
    values = np.asarray(values, dtype=float)
    rng = np.random.default_rng(76418)
    means = values[rng.integers(0, len(values), size=(5000, len(values)))].mean(axis=1)
    return {"mean": float(values.mean()), "question_bootstrap_95pct": np.quantile(means, [.025, .975]).tolist()}


def run(root):
    root = Path(root)
    # Confirmation questions are deliberately not analyzed here.
    rows = [r for r in load_jsonl(root / "data" / "pools.jsonl") if r["split"] == "discovery"]
    results = []
    for row in rows:
        aliases, proofs = alias_masks(row), proof_masks(row)
        gold_n = len(row["answers"])
        result = {"qid": row["qid"], "question": row["question"], "gold_answers": gold_n,
                  "pool_alias_count": union_mask(aliases, range(50)).bit_count(),
                  "pool_exact_proof_count": union_mask(proofs, range(50)).bit_count(), "systems": {}}
        for k in [3, 5, 8, 10]:
            selections = {f"fusion_{k}": list(range(k)),
                          f"lexical_mmr05_{k}": lexical_mmr(row, k),
                          f"alias_greedy_DIAGNOSTIC_{k}": coverage_greedy(aliases, k),
                          f"proof_greedy_DIAGNOSTIC_{k}": coverage_greedy(proofs, k)}
            for name, chosen in selections.items():
                if len(chosen) != k or len(set(chosen)) != k:
                    raise AssertionError("Invalid selection")
                result["systems"][name] = {"indices": chosen,
                    "alias_count": union_mask(aliases, chosen).bit_count(),
                    "exact_proof_count": union_mask(proofs, chosen).bit_count()}
        result["exact_alias_game_k5"] = exact_coverage(aliases)
        results.append(result)
    systems = list(results[0]["systems"])
    summary = {
        "status": "Cached natural-retrieval preflight only; no reader outputs or learned improvement",
        "n_discovery": len(rows), "n_confirmation_analyzed": 0,
        "retrieval_snapshot_alignment": "Not independently verified; namespaced release IDs",
        "mean_gold_answers": statistics.mean(r["gold_answers"] for r in results),
        "pool_alias_recall": bootstrap([r["pool_alias_count"] / r["gold_answers"] for r in results]),
        "pool_exact_proof_recall": bootstrap([r["pool_exact_proof_count"] / r["gold_answers"] for r in results]),
        "systems": {name: {
            "alias_recall": bootstrap([r["systems"][name]["alias_count"] / r["gold_answers"] for r in results]),
            "exact_proof_recall": bootstrap([r["systems"][name]["exact_proof_count"] / r["gold_answers"] for r in results])}
            for name in systems},
        "alias_greedy_over_fusion_k5": bootstrap([
            (r["systems"]["alias_greedy_DIAGNOSTIC_5"]["alias_count"] - r["systems"]["fusion_5"]["alias_count"]) / r["gold_answers"]
            for r in results]),
        "proof_greedy_over_fusion_k5": bootstrap([
            (r["systems"]["proof_greedy_DIAGNOSTIC_5"]["exact_proof_count"] - r["systems"]["fusion_5"]["exact_proof_count"]) / r["gold_answers"]
            for r in results]),
        "queries_alias_greedy_improves_fusion": sum(r["systems"]["alias_greedy_DIAGNOSTIC_5"]["alias_count"] > r["systems"]["fusion_5"]["alias_count"] for r in results),
        "queries_proof_greedy_improves_fusion": sum(r["systems"]["proof_greedy_DIAGNOSTIC_5"]["exact_proof_count"] > r["systems"]["fusion_5"]["exact_proof_count"] for r in results),
        "queries_better_alias_set_than_greedy_found": sum(r["exact_alias_game_k5"]["best_count"] > r["exact_alias_game_k5"]["greedy_count"] for r in results),
        "alias_game_optimality_certified_queries": sum(r["exact_alias_game_k5"]["optimal_certified"] for r in results),
        "limitations": ["Alias occurrence need not support the queried relationship.",
            "Exact proof matching misses paraphrases and alternative support.",
            "Reference-guided selectors are gold-aware diagnostics, not deployable models.",
            "Selections use fixed k, not yet a matched model-token budget.",
            "Lexical MMR is not a tuned neural diversity baseline.",
            "These results neither prove methodological novelty nor answer-quality improvements."]}
    output = root / "results"
    output.mkdir(exist_ok=True)
    write_jsonl(output / "local_per_question.jsonl", results)
    by_id = {r["qid"]: r for r in rows}
    ranked = sorted(results, key=lambda r: (
        -(r["systems"]["proof_greedy_DIAGNOSTIC_5"]["exact_proof_count"] - r["systems"]["fusion_5"]["exact_proof_count"]), r["qid"]))[:5]
    write_jsonl(output / "inspection_examples.jsonl", [
        {"diagnostic": r, "source_question": by_id[r["qid"]]} for r in ranked])
    summary["code_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    summary["benchmark_sha256"] = hashlib.sha256((root / "benchmark.py").read_bytes()).hexdigest()
    (output / "local_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k not in ["systems", "limitations"]}, indent=2))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    run(parser.parse_args().root)
