"""Fetch only official QAMPARI development members, with bounded HTTP ranges.

No paid services, model inference, train/test downloads, or gold-augmented pools.
"""
from __future__ import annotations

import argparse
import collections
import datetime as dt
import hashlib
import io
import json
from pathlib import Path
import struct
import time
import urllib.error
import urllib.request
import zipfile

QUESTION_URL = "https://aggreg-qa.s3.amazonaws.com/qampari.zip"
RETRIEVAL_URL = "https://aggreg-qa.s3.amazonaws.com/qampari_with_contexts.zip"
MEMBERS = {
    "questions": (QUESTION_URL, None, "qampari_data/dev_data.jsonl"),
    "bm25": (RETRIEVAL_URL, "qampari_preds/qampari_fid_bm25.zip",
             "qampari_v2/qampari_fid_format/full_dev_data.jsonl.gz"),
    "dpr": (RETRIEVAL_URL, "qampari_preds/qampari_fid_dpr.zip",
            "qampari_v2/qampari_dpr_retriever/full_dev_data.jsonl.gz"),
}


def sha256_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def request(url, headers=None, method="GET"):
    for attempt in range(4):
        try:
            return urllib.request.urlopen(urllib.request.Request(
                url, headers={"User-Agent": "COL764-QAMPARI-Pilot/1.0", **(headers or {})},
                method=method), timeout=90)
        except (urllib.error.URLError, TimeoutError):
            if attempt == 3:
                raise
            time.sleep(1 + attempt)


class RangeSource:
    """A shared, bounded block cache; never requests the whole archive."""
    def __init__(self, url, block_size=4 * 1024 * 1024):
        self.url = url
        self.block_size = block_size
        self.cache = collections.OrderedDict()
        self.network_bytes = 0
        with request(url, method="HEAD") as r:
            self.size = int(r.headers["Content-Length"])
            self.etag = r.headers.get("ETag")
            self.last_modified = r.headers.get("Last-Modified")

    def read_at(self, start, count):
        if start < 0 or count < 0 or start + count > self.size:
            raise ValueError("Out-of-bounds HTTP range")
        chunks = []
        while count:
            block_start = start // self.block_size * self.block_size
            if block_start not in self.cache:
                end = min(self.size, block_start + self.block_size) - 1
                headers = {"Range": f"bytes={block_start}-{end}"}
                if self.etag:
                    headers["If-Match"] = self.etag
                with request(self.url, headers) as r:
                    expected = f"bytes {block_start}-{end}/{self.size}"
                    if r.status != 206 or r.headers.get("Content-Range") != expected:
                        raise RuntimeError("Server did not honor the exact byte range")
                    if self.etag and r.headers.get("ETag") != self.etag:
                        raise RuntimeError("Archive changed during download")
                    data = r.read(end - block_start + 2)
                if len(data) != end - block_start + 1:
                    raise RuntimeError("Truncated or oversized byte range")
                self.network_bytes += len(data)
                self.cache[block_start] = data
                while len(self.cache) > 3:
                    self.cache.popitem(last=False)
            self.cache.move_to_end(block_start)
            data = self.cache[block_start]
            offset = start - block_start
            take = min(count, len(data) - offset)
            if take <= 0:
                raise RuntimeError("Invalid cached byte range")
            chunks.append(data[offset:offset + take])
            start += take
            count -= take
        return b"".join(chunks)


class RangeView(io.RawIOBase):
    def __init__(self, source, base=0, size=None):
        self.source = source
        self.base = base
        self.size = source.size - base if size is None else size
        self.position = 0

    def readable(self):
        return True

    def seekable(self):
        return True

    def tell(self):
        return self.position

    def seek(self, offset, whence=0):
        new = (offset if whence == 0 else self.position + offset if whence == 1
               else self.size + offset if whence == 2 else None)
        if new is None or new < 0:
            raise ValueError("Invalid seek")
        self.position = new
        return new

    def read(self, count=-1):
        count = max(0, min(self.size - self.position,
                          self.size if count < 0 else count))
        if count > 128 * 1024 * 1024:
            raise RuntimeError("Unexpectedly large read; refusing full-archive download")
        data = self.source.read_at(self.base + self.position, count)
        self.position += len(data)
        return data


def nested_view(source, outer_member):
    view = RangeView(source)
    if outer_member is None:
        return view
    with zipfile.ZipFile(view) as outer:
        info = outer.getinfo(outer_member)
        if info.compress_type != zipfile.ZIP_STORED:
            raise RuntimeError("Nested archive is compressed; cannot safely range-seek it")
        header = source.read_at(info.header_offset, 30)
        fields = struct.unpack("<4s5H3I2H", header)
        if fields[0] != b"PK\x03\x04":
            raise RuntimeError("Bad nested ZIP local header")
        base = info.header_offset + 30 + fields[-2] + fields[-1]
        return RangeView(source, base, info.file_size)


def fetch(root):
    root = Path(root)
    raw = root / "data" / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    manifest_path = raw / "manifest.json"
    previous = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    sources = {}
    manifest = {"downloaded_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                "purpose": "Natural development rankings; no gold augmentation", "files": []}
    old_files = {x["label"]: x for x in previous.get("files", [])}
    for label, (url, outer, member) in MEMBERS.items():
        destination = raw / ("questions.jsonl" if label == "questions" else f"{label}.jsonl.gz")
        old = old_files.get(label)
        if old and destination.exists() and sha256_file(destination) == old["sha256"]:
            print(f"Reusing verified {label}: {destination.stat().st_size:,} bytes", flush=True)
            manifest["files"].append(old)
            continue
        if url not in sources:
            sources[url] = RangeSource(url)
        source = sources[url]
        view = nested_view(source, outer)
        with zipfile.ZipFile(view) as archive:
            info = archive.getinfo(member)
            if info.file_size > 128 * 1024 * 1024 or "gold" in member:
                raise RuntimeError("Unexpected member; refusing download")
            temporary = destination.with_suffix(destination.suffix + ".partial")
            print(f"Downloading {label}: {info.file_size:,} member bytes", flush=True)
            with archive.open(info) as inp, temporary.open("wb") as out:
                for block in iter(lambda: inp.read(1024 * 1024), b""):
                    out.write(block)
            # Reading to EOF checks the inner member CRC through ZipExtFile.
            if temporary.stat().st_size != info.file_size:
                raise RuntimeError("Member size mismatch")
            temporary.replace(destination)
            record = {"label": label, "url": url, "outer_member": outer,
                      "member": member, "archive_etag": source.etag,
                      "archive_last_modified": source.last_modified,
                      "archive_bytes": source.size, "member_crc32": info.CRC,
                      "bytes": info.file_size, "sha256": sha256_file(destination),
                      "path": str(destination.relative_to(root))}
            manifest["files"].append(record)
        manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    manifest["network_bytes_this_run"] = sum(x.network_bytes for x in sources.values())
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"Verified all development members; transferred {manifest['network_bytes_this_run']:,} bytes", flush=True)
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    fetch(args.root)
