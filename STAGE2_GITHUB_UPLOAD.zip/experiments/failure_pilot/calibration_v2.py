"""Small reader calibration using cached models; no selector training or APIs.

Controlled checks are constructed capability tests, not research findings.
"""
from __future__ import annotations
import copy
import datetime as dt
import gc
import hashlib
import json
from pathlib import Path
import re
import sys
import time
import zipfile

ORIGINAL = Path('/kaggle/working/evidence_pilot')
OUTPUT = Path('/kaggle/working/evidence_pilot_calibration_v2')
READERS = ['Qwen/Qwen2.5-3B-Instruct', 'HuggingFaceTB/SmolLM2-1.7B-Instruct']

sys.path.insert(0, str(ORIGINAL))
from benchmark import normalize, parse_answer_output, load_jsonl
from run_kaggle import messages_for


def extract_json_content(text):
    answers, error = parse_answer_output(text)
    if error is None:
        return answers, 'strict_json'
    text = text.strip()
    if text.startswith('```'):
        parts = text.split('\n', 1)
        if len(parts) != 2:
            return None, 'unextractable'
        text = parts[1].strip()
        if text.endswith('```'):
            text = text[:-3].strip()
    if not text.startswith(('{', '[')):
        return None, 'unextractable'
    try:
        value, end = json.JSONDecoder().raw_decode(text)
    except (ValueError, json.JSONDecodeError):
        return None, 'unextractable'
    if any(c in text[end:] for c in ['{', '[']):
        return None, 'ambiguous_suffix'
    if isinstance(value, list):
        value = {'answers': value}
    answers, error = parse_answer_output(json.dumps(value))
    return (answers, 'structural_json_extraction') if error is None else (None, 'wrong_schema')


def parse_lines(text):
    text = text.strip()
    if text.startswith('```') and text.endswith('```') and '\n' in text:
        text = text.split('\n', 1)[1][:-3].strip()
    if text.upper() == 'NONE':
        return [], 'none'
    answers = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        # Formatting-only removal; do not infer or edit names/citations.
        if line.startswith('- '):
            line = line[2:]
        match = re.fullmatch(r'(.+?)\s*\|\s*(D\d{2}(?:\s*,\s*D\d{2})*)\s*', line)
        if not match:
            return None, 'bad_line_format'
        answers.append({'answer': match.group(1).strip(),
                        'citations': [c.strip() for c in match.group(2).split(',')]})
    return (answers, 'lines') if answers else (None, 'empty_unparsed')


def line_messages(question, evidence):
    system = (
        'This is a multi-answer evidence task. List ALL distinct answers supported by the current '
        'passages, even if the question uses singular wording. Each answer must satisfy EVERY '
        'condition in the question. A name appearing in a passage is not enough. '
        'Do not use facts from memory or copy answers from the examples. '
        'Output one answer per line using: answer name | cited passage IDs separated by commas. '
        'Output NONE if the current evidence supports no answer. Do not output JSON, headings, '
        'explanations, or names of people/places when the question asks for something else.')
    return [
        {'role': 'system', 'content': system},
        {'role': 'user', 'content': 'Question: Which animals are described as nocturnal?\n'
         'Evidence:\n[D01] The silver fox is nocturnal.\n[D02] The river hare is nocturnal.\n'
         '[D03] The meadow lark is diurnal.'},
        {'role': 'assistant', 'content': 'silver fox | D01\nriver hare | D02'},
        {'role': 'user', 'content': 'Question: Which animals are described as nocturnal?\n'
         'Evidence:\n[D01] The meadow lark is diurnal.'},
        {'role': 'assistant', 'content': 'NONE'},
        {'role': 'user', 'content': 'Question: ' + question + '\nEvidence:\n' +
         '\n\n'.join(d['rendered'] for d in evidence) + '\nList all supported answers, or NONE.'},
    ]


def document(number, text):
    return {'id': f'D{number:02d}', 'rendered': f'[D{number:02d}] {text}'}


def controls():
    question = 'Which films were directed by Mira Sen and written by Leon Reed?'
    direct = [document(1, 'Cedar Road is a film directed by Mira Sen and written by Leon Reed.'),
              document(2, 'Harbor Lights is a film directed by Mira Sen and written by Leon Reed.'),
              document(3, 'Copper Sky is a film directed by Mira Sen and written by Julia Moss.')]
    bridge = [document(1, 'Mira Sen wrote the films Cedar Road and Harbor Lights.'),
              document(2, 'Cedar Road was directed by Leon Reed.'),
              document(3, 'Harbor Lights was directed by Elena Park.')]
    museums = ['Birch Museum', 'Maple Museum', 'Elm Gallery', 'Willow Hall', 'Oak Museum']
    return [
        {'case_id': 'control_direct_two', 'question': question, 'evidence': direct,
         'gold': {'Cedar Road': ['D01'], 'Harbor Lights': ['D02']}},
        {'case_id': 'control_partial_condition_negative', 'question': question,
         'evidence': [direct[2]], 'gold': {}},
        {'case_id': 'control_irrelevant_negative', 'question': question,
         'evidence': [document(1, 'Lake Arlen is a freshwater lake in a mountain valley.')], 'gold': {}},
        {'case_id': 'control_join_two',
         'question': 'Which directors directed films written by Mira Sen?', 'evidence': bridge,
         'gold': {'Leon Reed': ['D01', 'D02'], 'Elena Park': ['D01', 'D03']}},
        {'case_id': 'control_missing_bridge_negative',
         'question': 'Which directors directed films written by Mira Sen?',
         'evidence': [bridge[1]], 'gold': {}},
        {'case_id': 'control_list_five', 'question': 'Which museums are located in Alder Bay?',
         'evidence': [document(i, f'{name} is a museum located in Alder Bay.') for i, name in enumerate(museums, 1)] +
                     [document(6, 'Spruce Museum is located in Birch Harbor.')],
         'gold': {name: [f'D{i:02d}'] for i, name in enumerate(museums, 1)}},
    ]


def grade_control(case, answers):
    if answers is None:
        return {'exact_answer_set': False, 'all_required_citations': False, 'parseable': False}
    expected = {normalize(name): set(cites) for name, cites in case['gold'].items()}
    predicted = {}
    for item in answers:
        predicted.setdefault(normalize(item['answer']), set()).update(item['citations'])
    exact = set(expected) == set(predicted)
    valid_ids = {d['id'] for d in case['evidence']}
    citation_ok = exact and all(expected[name] <= predicted[name] <= valid_ids for name in expected)
    return {'exact_answer_set': exact, 'all_required_citations': citation_ok, 'parseable': True}


def export():
    target = OUTPUT.parent / 'evidence_calibration_v2_results.zip'
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
        for p in sorted(OUTPUT.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:
                archive.write(p, p.relative_to(OUTPUT))
    print('Download calibration results:', target, flush=True)
    return target


def run():
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    OUTPUT.mkdir(exist_ok=True)
    revisions = json.loads((ORIGINAL / 'model_revisions.json').read_text())
    cases = controls()
    rendered = list(load_jsonl(ORIGINAL / 'rendered_pools.jsonl'))
    selections = json.loads((ORIGINAL / 'selections.json').read_text())
    for i, row in enumerate(rendered):
        selected = selections[row['qid']]['selections']['reference_proof_greedy_DIAGNOSTIC']
        cases.append({'case_id': 'real_proof_' + row['qid'], 'question': row['question'],
                      'source_qid': row['qid'], 'evidence_source_qid': row['qid'],
                      'evidence': [row['passages'][j] for j in sorted(selected)], 'gold': None})
        other = rendered[(i + 1) % len(rendered)]
        selected = selections[other['qid']]['selections']['relevance_ce_top5']
        cases.append({'case_id': 'real_shuffled_' + row['qid'], 'question': row['question'],
                      'source_qid': row['qid'], 'evidence_source_qid': other['qid'],
                      'evidence': [other['passages'][j] for j in sorted(selected)], 'gold': None})
    (OUTPUT / 'cases.json').write_text(json.dumps(cases, indent=2), encoding='utf-8')
    provenance = {'utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'model_revisions': revisions,
                  'decoding': {'do_sample': False, 'max_new_tokens': 512},
                  'source_generations_sha256': hashlib.sha256((ORIGINAL / 'generations.jsonl').read_bytes()).hexdigest(),
                  'calibration_code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'scope': 'Reader/prompt calibration only, not a novel evidence selector',
                  'logical_call_cap': 88, 'seconds_cap': 2400,
                  'gate': 'At least 5/6 exact synthetic controls including all three negative controls; inspect real outputs separately.'}
    (OUTPUT / 'environment.json').write_text(json.dumps(provenance, indent=2), encoding='utf-8')
    path = OUTPUT / 'outputs.jsonl'
    previous = list(load_jsonl(path)) if path.exists() else []
    done = {r['record_id'] for r in previous}
    all_records = list(previous)
    started = time.monotonic()
    for reader in READERS:
        tokenizer = AutoTokenizer.from_pretrained(reader, revision=revisions[reader]['revision'])
        model = AutoModelForCausalLM.from_pretrained(reader, revision=revisions[reader]['revision'],
            trust_remote_code=False, torch_dtype=torch.float16, device_map={'': 'cuda:0'}, attn_implementation='sdpa').eval()
        configuration = copy.deepcopy(model.generation_config)
        configuration.do_sample = False; configuration.temperature = 1.0; configuration.top_p = 1.0
        configuration.top_k = 50; configuration.max_new_tokens = 512
        for case in cases:
            for variant in ['original_json', 'list_lines_v2']:
                messages = (messages_for(case['question'], case['evidence']) if variant == 'original_json'
                            else line_messages(case['question'], case['evidence']))
                prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
                record_id = hashlib.sha256(json.dumps({'reader': reader, 'revision': revisions[reader]['revision'],
                    'case': case['case_id'], 'variant': variant, 'prompt': prompt, 'decoding': provenance['decoding']}, sort_keys=True).encode()).hexdigest()
                if record_id in done:
                    continue
                if len(all_records) >= 88 or time.monotonic() - started > 2400:
                    raise RuntimeError('Calibration cap reached; use saved partial outputs')
                inputs = tokenizer(prompt, return_tensors='pt', add_special_tokens=False).to('cuda:0')
                if inputs['input_ids'].shape[1] + 512 > 4096:
                    raise RuntimeError('Calibration prompt too long; no silent truncation')
                tick = time.monotonic()
                with torch.inference_mode():
                    tokens = model.generate(**inputs, generation_config=configuration,
                        pad_token_id=tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id)
                new = tokens[0, inputs['input_ids'].shape[1]:]
                output = tokenizer.decode(new, skip_special_tokens=True)
                answers, parse_status = extract_json_content(output) if variant == 'original_json' else parse_lines(output)
                record = {'record_id': record_id, 'reader': reader, 'model_revision': revisions[reader]['revision'],
                          'case_id': case['case_id'], 'variant': variant, 'messages': messages,
                          'output': output, 'answers': answers, 'parse_status': parse_status,
                          'input_tokens': int(inputs['input_ids'].shape[1]), 'output_tokens': len(new),
                          'seconds': time.monotonic() - tick, 'hit_max_new_tokens': len(new) == 512,
                          'control_grade': grade_control(case, answers) if case['gold'] is not None else None}
                with path.open('a', encoding='utf-8') as f:
                    f.write(json.dumps(record, ensure_ascii=False) + '\n')
                all_records.append(record); done.add(record_id)
            print(reader.split('/')[-1], case['case_id'], len(all_records), '/88 completed', flush=True)
        del model, tokenizer
        gc.collect(); torch.cuda.empty_cache()
    summary = {'status': 'Controlled calibration, no selector improvement claim', 'records': len(all_records), 'groups': {}}
    for reader in READERS:
        for variant in ['original_json', 'list_lines_v2']:
            subset = [r for r in all_records if r['reader'] == reader and r['variant'] == variant and r['control_grade'] is not None]
            passed = [r['case_id'] for r in subset if r['control_grade']['exact_answer_set'] and r['control_grade']['all_required_citations']]
            negatives = [r for r in subset if 'negative' in r['case_id']]
            gate = len(passed) >= 5 and all(r['control_grade']['exact_answer_set'] for r in negatives)
            summary['groups'][reader + '|' + variant] = {'synthetic_controls_passed': len(passed), 'out_of': 6,
                'passed_ids': passed, 'capability_gate': gate,
                'negative_controls_passed': sum(r['control_grade']['exact_answer_set'] for r in negatives)}
    (OUTPUT / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    for name in ['smoke_pools.jsonl', 'rendered_pools.jsonl', 'selections.json', 'model_revisions.json']:
        (OUTPUT / name).write_bytes((ORIGINAL / name).read_bytes())
    print(json.dumps(summary, indent=2), flush=True)
    return summary


if __name__ == '__main__':
    from IPython.display import display, FileLink
    import traceback
    try:
        run()
    except Exception:
        OUTPUT.mkdir(exist_ok=True)
        (OUTPUT / 'error.txt').write_text(traceback.format_exc(), encoding='utf-8')
        raise
    finally:
        result = export()
        display(FileLink(result.name))
