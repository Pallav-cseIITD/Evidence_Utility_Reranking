"""Build one self-contained Kaggle notebook; no companion upload is needed."""
import base64
import hashlib
import io
import json
from pathlib import Path
import zipfile
from benchmark import load_jsonl

ROOT = Path(__file__).resolve().parent


def cell(kind, source):
    item = {"cell_type": kind, "metadata": {}, "source": source.splitlines(keepends=True),
            "id": hashlib.sha256(source.encode()).hexdigest()[:10]}
    if kind == "code":
        item.update(execution_count=None, outputs=[])
    return item


def build():
    all_rows = list(load_jsonl(ROOT / "data" / "pools.jsonl"))
    smoke = all_rows[:8]
    assert len(smoke) == 8 and all(r["split"] == "discovery" for r in smoke)
    buffer = io.BytesIO()
    sources = ["benchmark.py", "run_kaggle.py", "prepare_data.py", "local_diagnostic.py", "test_integrity.py", "PLAN.md"]
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for name in sources:
            z.writestr(name, (ROOT / name).read_bytes())
        z.writestr("smoke_pools.jsonl", "".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n" for r in smoke))
        z.writestr("model_revisions.json", (ROOT / "sources" / "model_revisions.json").read_bytes())
        z.writestr("sample_manifest.json", (ROOT / "data" / "sample_manifest.json").read_bytes())
        z.writestr("raw_source_manifest.json", (ROOT / "data" / "raw" / "manifest.json").read_bytes())
    raw = buffer.getvalue()
    encoded = base64.b64encode(raw).decode()
    payload_hash = hashlib.sha256(raw).hexdigest()
    install = '''import os, sys, subprocess
from pathlib import Path
import torch
assert torch.cuda.is_available(), "Enable a GPU in Kaggle notebook settings, then rerun."
assert torch.cuda.get_device_properties(0).total_memory >= 12 * 1024**3, "Use a GPU with at least 12 GiB."
os.chdir('/kaggle/working')
os.environ['HF_HOME'] = '/kaggle/working/hf-cache'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
os.environ['HF_HUB_DISABLE_XET'] = '1'
subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q',
                       'transformers==4.51.3', 'accelerate==1.6.0',
                       'huggingface-hub==0.30.2', 'safetensors>=0.5.3'])
print('GPU:', torch.cuda.get_device_name(0))
print('Ready. No paid APIs or secret keys are used.')
'''
    unpack = f'''import base64, hashlib, io, json, zipfile
ROOT = Path('/kaggle/working/evidence_pilot')
ROOT.mkdir(parents=True, exist_ok=True)
PAYLOAD = {encoded!r}
raw = base64.b64decode(PAYLOAD)
assert hashlib.sha256(raw).hexdigest() == {payload_hash!r}, 'Notebook payload checksum mismatch'
with zipfile.ZipFile(io.BytesIO(raw)) as bundle:
    for member in bundle.infolist():
        target = (ROOT / member.filename).resolve()
        assert ROOT.resolve() in target.parents, 'Unexpected package path'
        target.write_bytes(bundle.read(member))
sys.path.insert(0, str(ROOT))
print('Loaded eight frozen discovery questions with 50 natural BM25+DPR candidates each.')
print('Sources, sample IDs and model revisions are included in the output package.')
import unittest
checks = unittest.defaultTestLoader.discover(str(ROOT), pattern='test_integrity.py')
check_result = unittest.TextTestRunner(verbosity=1).run(checks)
assert check_result.wasSuccessful(), 'Local integrity checks failed; do not start model generation.'
'''
    execute = '''import traceback
from IPython.display import display, FileLink
from run_kaggle import run, export_results
try:
    run(ROOT)
except Exception:
    (ROOT / 'error.txt').write_text(traceback.format_exc(), encoding='utf-8')
    raise
finally:
    archive = export_results(ROOT)
    display(FileLink(archive.name))
'''
    cells = [cell("markdown", """# Evidence-utility project: first GPU smoke test

This is the first step of the approved failure-first investigation. It does **not** train a new method or claim verified improvements.

1. Keep the notebook private. Enable **Internet** and an available **GPU** in notebook settings (one 16 GB GPU is sufficient).
2. Run all cells. Public model downloads total roughly 10 GB; no API key or paid service is used. The code limits this smoke test to eight questions, two reader families, two sampled repetitions, at most 384 logical generations and a three-hour run cap.
3. Download **evidence_pilot_results.zip** from the last cell or notebook output files and return it to the project chat. If a cell fails, share its error; partial results are packaged if generation has started.

The eight questions are from a frozen 200-question development sample. The other 100-question confirmation group is not evaluated. Top-50 pools use official cached natural BM25 and DPR rankings, not gold-augmented retrieval. Passage ID namespaces differ and corpus snapshot alignment is not independently verified; this is a preflight, not final publication evidence.

Comparisons: fused relevance, a small relevance cross-encoder, three untuned dense-MMR settings, clearly marked gold-aware name/proof coverage diagnostics, passage insertion probes, and closed-book/shuffled-context controls. Gold answer lists never enter reader prompts. Reader outputs, token counts, timings, seeds, revisions, and prompts are saved incrementally. Reference matches and valid citation IDs are **not** proof of supported answers. A conservative exact reference-proof attribution proxy and a blinded support-audit sheet are exported; the exact-span proxy misses paraphrased and alternative evidence.

If the models cannot reliably use sufficient evidence, we will adjust the reader setup before extending to the 100-question discovery pilot. Larger experiments and the revised proposal follow the actual results.
"""), cell("code", install), cell("markdown", "## Load the frozen pilot package\nThe next cell contains compressed public data and experiment sources. No additional file upload is needed.\n"),
             cell("code", unpack), cell("markdown", "## Run readers and save results\nModels run one at a time. The second GPU, if present, is optional. Progress prints after each question. The final link contains results, not the large model weights.\n"),
             cell("code", execute)]
    cells[3]["metadata"] = {"jupyter": {"source_hidden": True}}
    notebook = {"nbformat": 4, "nbformat_minor": 5,
                "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                             "language_info": {"name": "python", "version": "3.11"},
                             "accelerator": "GPU"}, "cells": cells}
    destination = ROOT / "Evidence_Utility_Kaggle_Start.ipynb"
    destination.write_text(json.dumps(notebook, indent=1, ensure_ascii=False), encoding="utf-8")
    for i, item in enumerate(cells):
        if item["cell_type"] == "code":
            compile("".join(item["source"]), f"notebook_cell_{i}", "exec")
    manifest = {"notebook": destination.name, "bytes": destination.stat().st_size,
                "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
                "payload_sha256": payload_hash, "smoke_qids": [r["qid"] for r in smoke],
                "sources": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources},
                "validation": "Code cells compile; local data/scoring controls run separately. GPU execution not yet performed."}
    (ROOT / "notebook_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in manifest.items() if k != "sources"}, indent=2))
    return destination


if __name__ == "__main__":
    build()
