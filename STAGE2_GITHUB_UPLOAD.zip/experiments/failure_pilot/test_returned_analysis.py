import unittest
from analyze_returned_run import extract_content
from calibration_v2 import controls, grade_control, parse_lines


class ReturnedAnalysisTests(unittest.TestCase):
    def test_structural_extraction_keeps_answer_and_citation(self):
        for text in ['[{"answer":"X","citations":["D01"]}]',
                     '{"answers":[{"answer":"X","citations":["D01"]}]}. Explanation.',
                     '```json\n[{"answer":"X","citations":["D01"]}]\n```']:
            answers, mode, detail = extract_content(text)
            self.assertEqual(answers, [{'answer': 'X', 'citations': ['D01']}])
        for text in ['{"answers":[{"answer":"X"', 'prose {"answers":[]}',
                     '{"answers":[]} {"answers":[{"answer":"Y","citations":[]}]}',
                     '{"answers":[{"answer":"X","citations":[1]}]}']:
            self.assertIsNone(extract_content(text)[0])

    def test_empty_and_invalid_are_distinct(self):
        self.assertEqual(extract_content('[]')[0], [])
        self.assertIsNone(extract_content('not JSON')[0])
        self.assertEqual(parse_lines('NONE')[0], [])
        self.assertIsNone(parse_lines('No answer')[0])

    def test_line_records_and_no_implicit_citation_repair(self):
        self.assertEqual(parse_lines('Alpha | D01,D02\nBeta | D03')[0],
                         [{'answer': 'Alpha', 'citations': ['D01', 'D02']}, {'answer': 'Beta', 'citations': ['D03']}])
        self.assertIsNone(parse_lines('Alpha | 1')[0])
        self.assertIsNone(parse_lines('Alpha | D01\nSome extra prose')[0])

    def test_known_control_grade_requires_joint_support_and_valid_empty(self):
        join = next(c for c in controls() if c['case_id'] == 'control_join_two')
        right = [{'answer': 'Leon Reed', 'citations': ['D01', 'D02']},
                 {'answer': 'Elena Park', 'citations': ['D01', 'D03']}]
        self.assertTrue(grade_control(join, right)['all_required_citations'])
        right[0]['citations'] = ['D02']
        self.assertFalse(grade_control(join, right)['all_required_citations'])
        negative = next(c for c in controls() if c['case_id'] == 'control_irrelevant_negative')
        self.assertFalse(grade_control(negative, None)['exact_answer_set'])
        self.assertTrue(grade_control(negative, [])['exact_answer_set'])


if __name__ == '__main__':
    unittest.main()
