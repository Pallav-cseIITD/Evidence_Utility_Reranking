"""Shared pure-Python data, selection and reference-match helpers.

Alias occurrence is a diagnostic proxy, never a support/entailment judgment.
"""
from __future__ import annotations
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import string
import unicodedata

SAMPLE_SALT = "COL764-failure-pilot-v1|"


def digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def normalized_question(text):
    return " ".join(unicodedata.normalize("NFKC", text).casefold().split())


def normalize(text):
    text = unicodedata.normalize("NFKC", text).lower()
    text = "".join(c for c in text if c not in string.punctuation)
    text = re.sub(r"\b(a|an|the)\b", " ", text)
    return " ".join(text.split())


def token_set(text):
    return set(re.findall(r"\w+", text.lower()))


def load_jsonl(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def make_pool(question, bm25, dpr, n=50):
    for row in (bm25, dpr):
        if str(row["id"]) != str(question["qid"]):
            raise ValueError("Question identifier mismatch")
        if normalized_question(row["question"]) != normalized_question(question["question_text"]):
            raise ValueError(f"Retrieval query mismatch: {question['qid']}")
    docs = {}
    content_ids = {}
    raw_id_contents = {}
    duplicates = 0
    for method, row in [("bm25", bm25), ("dpr", dpr)]:
        seen = set()
        # ctxs is the natural ranking. positive_ctxs contains gold and is never read here.
        for rank, ctx in enumerate(row["ctxs"], 1):
            raw_pid = str(ctx["id"])
            # Released sparse/dense identifiers use different schemes. Never
            # infer cross-run identity from an unqualified numeric/string ID.
            pid = method + ":" + raw_pid
            content = " ".join(ctx["title"].split()) + "\n" + " ".join(ctx["text"].split())
            key = digest(content)
            if pid in raw_id_contents and raw_id_contents[pid] != key:
                raise ValueError(f"Conflicting passage text for {pid} in {question['qid']}")
            raw_id_contents[pid] = key
            canonical = content_ids.setdefault(key, pid)
            if canonical in seen:
                duplicates += 1
                continue
            seen.add(canonical)
            item = docs.setdefault(canonical, {
                "pid": canonical, "title": ctx["title"], "text": ctx["text"],
                "rrf_score": 0.0, "bm25_rank": None, "dpr_rank": None,
                "content_sha256": key, "source_ids": {}})
            item["source_ids"][method] = raw_pid
            item[method + "_rank"] = rank
            item["rrf_score"] += 1.0 / (60 + rank)
    ordered = sorted(docs.values(), key=lambda d: (
        -d["rrf_score"], d["bm25_rank"] or 10**9,
        d["dpr_rank"] or 10**9, d["pid"]))[:n]
    if len(ordered) != n:
        raise ValueError(f"Only {len(ordered)} passages for {question['qid']}")
    for rank, doc in enumerate(ordered, 1):
        doc["id"] = f"D{rank:02d}"
        doc["fusion_rank"] = rank
    answers = []
    for answer in question["answer_list"]:
        aliases = sorted(set([answer["answer_text"], *answer.get("aliases", [])]))
        answers.append({"answer": answer["answer_text"], "aliases": aliases,
                        "proofs": answer.get("proof", [])})
    return {"qid": question["qid"], "question": question["question_text"],
            "answers": answers, "passages": ordered,
            "retrieval": {"fusion": "RRF", "constant": 60, "pool_size": n,
                          "bm25_candidates": len(bm25["ctxs"]),
                          "dpr_candidates": len(dpr["ctxs"]),
                          "duplicates_within_rankings": duplicates,
                          "gold_augmentation": False,
                          "cross_run_identity": "namespaced IDs; exact normalized title/text deduplication",
                          "snapshot_alignment": "not independently verified; cached-release preflight"}}


def prepare(root):
    root = Path(root)
    raw = root / "data" / "raw"
    questions = {str(r["qid"]): r for r in load_jsonl(raw / "questions.jsonl")}
    if len(questions) != 1000:
        raise ValueError(f"Expected 1,000 development questions, found {len(questions)}")
    sample = sorted(questions, key=lambda qid: digest(SAMPLE_SALT + qid))[:200]
    sampled = set(sample)
    bm25 = {}
    seen_bm25, seen_dpr = set(), set()
    for row in load_jsonl(raw / "bm25.jsonl.gz"):
        qid = str(row["id"])
        if qid in seen_bm25:
            raise ValueError("Duplicate BM25 question")
        seen_bm25.add(qid)
        if qid in sampled:
            bm25[qid] = row
    pools = {}
    for row in load_jsonl(raw / "dpr.jsonl.gz"):
        qid = str(row["id"])
        if qid in seen_dpr:
            raise ValueError("Duplicate DPR question")
        seen_dpr.add(qid)
        if qid in sampled:
            pools[qid] = make_pool(questions[qid], bm25.pop(qid), row)
    if seen_bm25 != seen_dpr or not seen_bm25 <= set(questions):
        raise ValueError("Sparse/dense development identifiers differ or contain unknown questions")
    if not sampled <= seen_bm25 or set(pools) != sampled:
        raise ValueError("A preselected question lacks retrieval; do not silently resample")
    ordered = []
    for i, qid in enumerate(sample):
        row = pools[qid]
        row["split"] = "discovery" if i < 100 else "confirmation"
        row["sample_index"] = i
        ordered.append(row)
    output = root / "data" / "pools.jsonl"
    write_jsonl(output, ordered)
    record = {"source_split": "official development", "salt": SAMPLE_SALT,
              "rule": "ascending SHA-256(salt + qid)", "n": 200,
              "discovery_ids": sample[:100], "confirmation_ids": sample[100:],
              "smoke_test_ids": sample[:8],
              "available_retrieval_questions": len(seen_bm25),
              "unavailable_development_ids": sorted(set(questions) - seen_bm25),
              "sampled_questions_missing_retrieval": 0,
              "raw_files": json.loads((raw / "manifest.json").read_text())["files"],
              "pools_sha256": hashlib.sha256(output.read_bytes()).hexdigest()}
    (root / "data" / "sample_manifest.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
    return ordered


def alias_masks(row, passages=None):
    passages = row["passages"] if passages is None else passages
    aliases = [{normalize(a) for a in answer["aliases"] if normalize(a)} for answer in row["answers"]]
    masks = []
    for passage in passages:
        text = " " + normalize(passage["title"] + " " + passage["text"]) + " "
        mask = 0
        for i, variants in enumerate(aliases):
            if any(" " + a + " " in text for a in variants):
                mask |= 1 << i
        masks.append(mask)
    return masks


def union_mask(masks, selected):
    result = 0
    for i in selected:
        result |= masks[i]
    return result


def proof_masks(row, passages=None):
    """Conservative exact occurrence of an annotated reference proof span.

    Misses paraphrased/alternative support. Does not judge generated answers.
    """
    passages = row["passages"] if passages is None else passages
    proofs = [{normalize(p["proof_text"]) for p in answer.get("proofs", [])
               if len(normalize(p.get("proof_text", "")).split()) >= 5}
              for answer in row["answers"]]
    masks = []
    for passage in passages:
        text = " " + normalize(passage["title"] + " " + passage["text"]) + " "
        mask = 0
        for i, variants in enumerate(proofs):
            if any(" " + p + " " in text for p in variants):
                mask |= 1 << i
        masks.append(mask)
    return masks


def coverage_greedy(masks, k=5):
    selected, covered = [], 0
    while len(selected) < min(k, len(masks)):
        i = max((j for j in range(len(masks)) if j not in selected),
                key=lambda j: ((masks[j] & ~covered).bit_count(), -j))
        selected.append(i)
        covered |= masks[i]
    return selected


def lexical_mmr(row, k=5, weight=0.5):
    docs = row["passages"]
    tokens = [token_set(d["title"] + " " + d["text"]) for d in docs]
    minimum, maximum = min(d["rrf_score"] for d in docs), max(d["rrf_score"] for d in docs)
    relevance = [(d["rrf_score"] - minimum) / max(maximum - minimum, 1e-12) for d in docs]
    chosen = []
    while len(chosen) < min(k, len(docs)):
        def value(i):
            redundancy = max((len(tokens[i] & tokens[j]) / max(1, len(tokens[i] | tokens[j]))
                              for j in chosen), default=0)
            return (weight * relevance[i] - (1 - weight) * redundancy, -i)
        chosen.append(max((i for i in range(len(docs)) if i not in chosen), key=value))
    return chosen


def lexical_selections(row):
    return {"fusion_top5": list(range(5)),
            "lexical_mmr_05": lexical_mmr(row),
            "reference_alias_greedy_DIAGNOSTIC": coverage_greedy(alias_masks(row))}


def parse_answer_output(text):
    """Parse a strict schema; never silently repair malformed model answers."""
    stripped = text.strip()
    if stripped.startswith("```json") and stripped.endswith("```"):
        stripped = stripped[7:-3].strip()
    elif stripped.startswith("```") and stripped.endswith("```"):
        stripped = stripped[3:-3].strip()
    try:
        result = json.loads(stripped)
        if not isinstance(result, dict) or set(result) != {"answers"} or not isinstance(result["answers"], list):
            raise ValueError("Expected an object with an answers list")
        for item in result["answers"]:
            if (not isinstance(item, dict) or set(item) != {"answer", "citations"}
                or not isinstance(item["answer"], str) or not item["answer"].strip()
                or not isinstance(item["citations"], list)
                or not all(isinstance(c, str) for c in item["citations"])):
                raise ValueError("Invalid answer/citations schema")
        return result["answers"], None
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        return [], str(exc)


def reference_metrics(row, answers):
    gold = [{normalize(v) for v in a["aliases"]} for a in row["answers"]]
    predicted = set(normalize(a["answer"]) for a in answers if normalize(a["answer"]))
    covered = {i for i, variants in enumerate(gold) if predicted & variants}
    matched = {p for p in predicted if any(p in variants for variants in gold)}
    precision = len(matched) / len(predicted) if predicted else 0.0
    recall = len(covered) / len(gold) if gold else 0.0
    return {"reference_precision": precision, "reference_recall": recall,
            "reference_f1": 2 * precision * recall / (precision + recall) if precision + recall else 0.0,
            "matched_gold_indices": sorted(covered), "predicted_unique": len(predicted),
            "note": "Reference match only. Missing references and unsupported correct answers require audit."}
