"""Meaningful data/scoring controls. No claim these test GPU compatibility."""
import io
import itertools
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
from benchmark import (alias_masks, make_pool, parse_answer_output, proof_masks,
                       reference_metrics, union_mask)
from local_diagnostic import exact_coverage
from prepare_data import RangeView
from run_kaggle import common_render, messages_for, summarize


class IntegrityTests(unittest.TestCase):
    def test_bounded_exact_solver_against_exhaustive_enumeration(self):
        for masks in itertools.product(range(8), repeat=4):
            expected = max(union_mask(masks, pair).bit_count() for pair in itertools.combinations(range(4), 2))
            result = exact_coverage(list(masks), 2)
            self.assertTrue(result["optimal_certified"])
            self.assertEqual(result["best_count"], expected)

    def test_namespaces_and_exact_content_deduplication(self):
        question = {"qid": "q", "question_text": "Question?", "answer_list": []}
        bm = [{"id": str(i), "title": "sparse", "text": str(i)} for i in range(60)]
        dp = [{"id": str(i), "title": "dense", "text": str(i)} for i in range(60)]
        dp[0] = {"id": "999", "title": "sparse", "text": "0"}
        pool = make_pool(question, {"id": "q", "question": "Question?", "ctxs": bm},
                         {"id": "q", "question": "Question?", "ctxs": dp})
        self.assertEqual(len(pool["passages"]), 50)
        first = pool["passages"][0]
        self.assertEqual(first["source_ids"], {"bm25": "0", "dpr": "999"})
        self.assertAlmostEqual(first["rrf_score"], 2 / 61)
        with self.assertRaises(ValueError):
            make_pool(question, {"id": "q", "question": "Different", "ctxs": bm},
                      {"id": "q", "question": "Question?", "ctxs": dp})

    def test_reference_occurrence_is_not_support_and_has_boundaries(self):
        row = {"answers": [{"aliases": ["Heat"], "proofs": [{"proof_text": "Heat was illustrated by the named artist"}]}],
               "passages": [{"title": "Other", "text": "A heather plant."},
                            {"title": "Other", "text": "Heat is an unrelated physical process."}]}
        self.assertEqual(alias_masks(row), [0, 1])
        self.assertEqual(proof_masks(row), [0, 0])

    def test_strict_output_schema_and_reference_metrics(self):
        answers, error = parse_answer_output('{"answers":[{"answer":"The Heat","citations":["D01"]}]}')
        self.assertIsNone(error)
        self.assertEqual(reference_metrics({"answers": [{"aliases": ["Heat"]}]}, answers)["reference_recall"], 1)
        for bad in ['Here is JSON: {"answers":[]}', '{"answers":[{"answer":"X","citations":"D01"}]}', '{}']:
            self.assertIsNotNone(parse_answer_output(bad)[1])

    def test_common_evidence_cap_and_no_reference_prompt_leak(self):
        class CharacterTokenizer:
            def encode(self, text, **kwargs):
                return list(text)
        row = {"question": "Q?", "answers": [{"answer": "GOLD_SENTINEL"}],
               "passages": [{"id": "D01", "title": "Title", "text": "word " * 200}]}
        rendered = common_render(row, [CharacterTokenizer(), CharacterTokenizer()])
        doc = rendered["passages"][0]
        self.assertLessEqual(len(doc["rendered"]), 240)
        self.assertGreater(doc["truncated_characters"], 0)
        prompt = json.dumps(messages_for("Q?", [doc]))
        self.assertNotIn("GOLD_SENTINEL", prompt)

    def test_nested_zip_range_views_and_crc(self):
        inner_bytes = io.BytesIO()
        with zipfile.ZipFile(inner_bytes, "w", compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr("dev.jsonl", b'{"id":1}\n' * 50)
        outer_bytes = io.BytesIO()
        with zipfile.ZipFile(outer_bytes, "w", compression=zipfile.ZIP_STORED) as z:
            z.writestr("inner.zip", inner_bytes.getvalue())
        raw = outer_bytes.getvalue()
        class MemorySource:
            size = len(raw)
            def read_at(self, start, count):
                return raw[start:start + count]
        source = MemorySource()
        with zipfile.ZipFile(RangeView(source)) as z:
            info = z.getinfo("inner.zip")
            import struct
            fields = struct.unpack("<4s5H3I2H", raw[info.header_offset:info.header_offset + 30])
            base = info.header_offset + 30 + fields[-2] + fields[-1]
        with zipfile.ZipFile(RangeView(source, base, info.file_size)) as z:
            self.assertEqual(z.read("dev.jsonl"), b'{"id":1}\n' * 50)

    def test_repetitions_are_averaged_within_questions_and_audit_is_blinded(self):
        proof = "X was credited with making the first example"
        rows = [{"qid": qid, "question": "Q?", "answers": [{"aliases": ["X"],
                "proofs": [{"proof_text": proof}] if qid == "q1" else []}]} for qid in ["q1", "q2"]]
        records = []
        for i, (qid, response) in enumerate([("q1", "X"), ("q1", "Y"), ("q2", "X")]):
            records.append({"qid": qid, "reader": "fixture", "method": "fixture", "record_id": str(i),
                            "output": json.dumps({"answers": [{"answer": response, "citations": ["D01"]}]}),
                            "cache_hit": False, "hit_max_new_tokens": False,
                            "evidence": [{"id": "D01", "rendered": proof if qid == "q1" else "Fixture evidence"}]})
        temp_parent = Path(__file__).resolve().parent / "test_tmp"
        temp_parent.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=temp_parent) as tmp:
            root = Path(tmp)
            self.assertIn(temp_parent.resolve(), root.resolve().parents)
            (root / "generations.jsonl").write_text("\n".join(json.dumps(r) for r in records), encoding="utf-8")
            result = summarize(root, rows)
            self.assertEqual(result["groups"]["fixture|fixture"]["n_questions"], 2)
            self.assertEqual(result["groups"]["fixture|fixture"]["reference_recall"], .75)
            self.assertEqual(result["groups"]["fixture|fixture"]["exact_reference_proof_attributed_recall"], .25)
            header = (root / "human_audit_BLINDED.csv").read_text(encoding="utf-8-sig").splitlines()[0]
            self.assertNotIn("reference_alias_match", header)
            self.assertNotIn("reader", header)


if __name__ == "__main__":
    unittest.main()
