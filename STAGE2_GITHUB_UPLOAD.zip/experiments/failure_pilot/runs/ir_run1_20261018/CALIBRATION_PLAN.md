# Small calibration before extending the pilot

18 October 2026. Written before the calibration outputs. The returned run shows structural-format failures, copied prompt placeholders, and weak use of available multi-answer evidence. This is a repair of the experimental setup, not a proposed research contribution.

Reuse the two cached reader models and pinned revisions from `ir_run1`. Preserve the original source files, outputs and scores. Add a separate calibration cell/folder in the same private notebook. No paid API, new model download, training, sharing change or confirmation-set use is involved.

Compare the original prompt with a fixed list-answer prompt using two worked demonstrations (one multiple-answer example and one no-supported-answer example). The revised prompt asks for one `answer | citations` record per line or `NONE`. This changes instructions, examples and output format together; it is not an isolated causal test of one formatting component and cannot justify a novelty claim.

Both prompts use greedy decoding and the same maximum of 512 output tokens. The original run sampled at temperature 0.3; do not attribute original-to-calibration differences solely to the prompt. The **within-calibration** prompt comparisons hold decoding fixed.

Use six constructed capability controls: two direct answers under conjunction constraints; a one-condition-only negative; unrelated evidence; a two-answer evidence-join case; its missing-bridge negative; and five directly supported answers with a distractor. These constructed cases have fully known answer sets and required support IDs. They are implementation/capability tests, not natural benchmark results or new multi-hop evidence findings.

Add the same eight discovery questions with their reference-proof-greedy evidence and shuffled-question evidence. These real cases have incomplete references; inspect them separately. No gold-answer list is included in prompts. No confirmation questions are touched.

There are 22 cases x two prompts x two readers = **88 maximum calls**, with a 40-minute execution cap. Save every raw output, prompt, tokens, time, model revision, decoding setting and parser status. Grade constructed controls by exact answer set and inclusion of the required supporting IDs; unparsed answers cannot count as a correct empty output.

Engineering gate: at least five of the six controls correct, including all three negatives; independently inspect real output quality and format before scaling. This small gate is not statistical evidence of reliability. If a reader still fails, replace or further calibrate it before using it as a label source. Record any failure without favorable case selection. No new selector or publishable improvement will be claimed from this calibration.
