# Returned smoke-run analysis

18 October 2026. Input ZIP SHA-256: fb7ccbbc8770ababddc3b1b091ff3113c9421573a116b64ac216a963055f1124.

This plan is written after receipt of the smoke summary and inspection of a few raw outputs, before computing recovered-content scores. It is a **post-run diagnostic amendment**, not a prospective registered experiment or a new confirmatory comparison. All original archive bytes and scores remain unchanged under `raw/`.

## Integrity and coverage

- Verify CRCs, source-file hashes against the shipped notebook, the frozen eight question IDs, two reader revisions, seeds 17/29 and twelve methods. Check all 384 logical records, cache keys, 348 generation attempts, unique identifiers and compatible cached outputs.
- Reconstruct raw prompts from the saved evidence where possible; verify fixed evidence per method across readers and repetitions, canonical order, evidence caps, and absence of reference-answer lists. Verify models, decoding and shared-source data. Record any discrepancies explicitly.
- Count actual unique generation tokens/time separately from logical output records; cache hits are not new generations. Notebook UI execution time is 859.086 seconds; this is a visible cell time, not a measured total allocated-GPU-hour bill.

## Formatting sensitivity: no semantic repairs

The shipped strict parser remains the original measure of exact schema compliance. It treated malformed outputs as empty answer lists, which conflates parsing failure with abstention in its existing `empty` and reference metrics. Report these limitations and distinguish valid empty answers from unparsed records.

For a separate content diagnostic, accept a complete JSON value at the beginning of the output after optional code-fence removal. Accept either the exact original `{"answers": [...]}` object or a top-level list of the same typed answer/citation objects. A complete value followed by punctuation/prose can be extracted, with the suffix recorded, only if the suffix has no opening `{` or `[` that could contain additional structured answers. Label this explicitly as complete-prefix extraction. Do not change names or citations, repair incomplete JSON, infer truncated entries, coerce citation types, or choose between competing answers. Unrecoverable records remain missing for content analysis, and are separately scored as zero in an all-output operational metric for comparability. Do not quietly exclude them to improve method rankings.

Report exact format-valid, structurally extractable, genuine empty, unextractable, and truncated rates by reader/method. Recovered-content numbers are exploratory sensitivity analysis; they do not replace the original prereader plan or establish a new method's effectiveness.

## Outcomes and failure inspection

- Recompute reference-answer recall/precision and conservative exact-reference-proof attribution for both parsers. Names not in the reference are benchmark-unmatched, not automatically false facts. A literal proof match is sufficient only under the reference annotation and does not measure all valid support.
- Compare selectors at shared evidence-token caps; include the actual lengths. Oracle-guided coverage is diagnostic and never a learned improvement. All eight questions are discovery; do not claim significance or inspect reserved confirmation data.
- For each insertion probe, compare the exact same baseline state and each addition at each seed. Report parseability changes separately from content changes. Compare between-state changes to same-state seed variability. Two seeds and eight questions cannot establish stable population interaction effects.
- Inspect representative raw answers with their actual cited passages, including gold-aware proof selections, irrelevant-context controls, and cases where extractable answers change. Record this as assistant inspection, **not human annotation**. No human audit has been returned.
- Examine whether valid citation IDs coincide with semantic support. Citation ID validity alone is not attribution quality.

## Decision gate

Decide whether these readers/prompts/measurements are ready to scale. A formatting fix or stronger reader is an experimental repair, not research novelty. Do not claim superiority over a learned utility baseline absent from this run. If the smoke test is inadequate, prepare a small corrected calibration test before the 100-question main pilot; use explicit positive/negative evidence controls and unambiguous output formatting. No new method, selector training or proposal novelty claim should be inferred merely from these eight questions.
