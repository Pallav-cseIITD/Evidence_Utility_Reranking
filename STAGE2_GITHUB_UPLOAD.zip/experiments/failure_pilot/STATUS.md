# Current update: 18 October 2026

The Kaggle smoke run has completed (384 logical / 348 generated records; eight discovery questions). A separate 88-call calibration has completed; neither compact reader passes. No selector has been trained. Original and post-run structural-extraction metrics, calibration outputs and provenance are in `runs/ir_run1_20261018/`. The Stage 2 report and 50-case assistant-reviewed audit are in `../../stage2_delivery/`. Independent human annotations completed: zero. Earlier preparation status below is historical.

---

# Failure-first investigation: current evidence

18 October 2026. User approved the investigation and offered Kaggle compute. No new method or improved proposal has yet been validated.

## What has actually run

Downloaded the official QAMPARI development questions and the natural BM25/DPR development retrieval files using bounded byte-range reads. Only about 133 MB was transferred from the large archives, including range-cache overhead. No training/test retrieval or gold-augmented file was downloaded. The three extracted members have ZIP CRC checks and saved SHA-256 hashes.

Both retrieval files contain the same 990 of the 1,000 official development IDs. All 200 preselected hash-sampled questions are available, so none was replaced. Each ranking supplies 200 candidates. Fused and froze 50 natural candidates per selected question, using RRF constant 60, namespaced source IDs and exact title/text deduplication. Different passage-ID schemes are observed; identical snapshot/chunk provenance has not been independently verified. These cached-release results are a preflight; aligned-index confirmation remains required for a strong publication claim.

The first 100 sampled questions are discovery. The next 100 are reserved for confirmation and have not been analyzed for selection or answer outcomes. The GPU smoke test uses the first eight discovery questions.

## Local results on the 100 discovery questions

These comparisons use five passages, **not yet a matched reader-token budget**. They measure literal reference occurrence, without generating answers.

| Selection | Mean reference-answer-name coverage | Mean exact annotated-proof-span coverage |
|---|---:|---:|
| Fused top five | 20.05% | 6.70% |
| Preliminary lexical MMR, weight 0.5 | 17.75% | 5.01% |
| Gold-aware answer-name coverage greedy, diagnostic only | 48.99% | 13.66% |
| Gold-aware annotated-proof coverage greedy, diagnostic only | 30.52% | 21.37% |
| All 50 candidates, pool diagnostic | 51.29% | 21.94% |

A correct name can occur without the relationship requested by the question. Conversely, exact proof matching misses paraphrases and other valid supporting passages. Neither column is generated-answer correctness, full semantic support recall, or citation precision. The all-50 exact-proof number is not an upper bound on true support. Gold-aware selections are evidence-availability diagnostics, not learned methods or deployable improvements.

The gold-aware proof selector retains more annotated proofs than fused top five on 54/100 questions. The paired mean increase is 14.67 percentage points (question bootstrap 95% interval 11.11–18.42). This shows selection headroom in these cached pools; it does not show that an implementable selector will realize that improvement or that an existing learned utility selector fails.

The exact unit-cost **answer-name OR-coverage** game was solved on all 100 questions. Ordinary coverage greedy was optimal on 99; one question had a better set. This particular proxy gives little support for making improved combinatorial search our central contribution. It says nothing decisive about nonmonotone reader quality or multi-hop complementarity. Complementarity and better-than-greedy search already have prior art.

Example requiring inspection: “Who directed the movie that Aline Brosh McKenna wrote for the screen?” Fused top five contains several biography/general passages; its literal annotated-proof count is zero. Five other natural candidates contain five reference proof spans. Lexical MMR also has zero exact spans here. This is an illustrative discovery case, not proof that those baseline passages contain no alternative valid evidence. It was selected for a large diagnostic gap and is not a representative random example.

Machine-readable results: `results/local_summary.json`, `results/local_per_question.jsonl`, and `results/inspection_examples.jsonl`. Code/input hashes and a prospective plan are saved. The exact coverage solver was checked against exhaustive enumeration of 4,096 small games. Seven local integrity tests cover joining, namespacing, reference matching, proof/alias distinctions, strict output parsing, token rendering, nested ZIP reads, question-level averaging and audit blinding.

## GPU experiment prepared, not executed

`Evidence_Utility_Kaggle_Start.ipynb` is self-contained. It uses pinned Qwen2.5-3B-Instruct and SmolLM2-1.7B-Instruct, sequentially on one GPU, and a frozen relevance cross-encoder/embedding model. Common passage text is capped for **both** reader tokenizers; every evidence set is checked against 1,280 evidence tokens, including titles and IDs. There is no silent strategy-specific truncation.

The smoke test compares fused top five, relevance cross-encoder, three untuned dense-MMR weights, gold-aware name/proof diagnostics, controlled insertion probes, and closed-book/shuffled-context controls. Two sampled seeds are saved separately and averaged within questions. It allows at most 384 logical generations before exact-cache savings, with a 400-new-call and three-hour execution cap. No paid API or rented GPU is configured. These are planned limits, not measured usage.

The smoke test does **not** yet include a released learned utility baseline or a trained ordinary marginal selector. It cannot establish superiority over RRPO, DynamicRAG, InfoGain-RAG, UtilityQwen or other set-aware methods. The released UtilityQwen checkpoint was located at `hengranZhang/UtilityQwen1.7B`, in the `UtilityQwen1.7B-model_checkpoint` subfolder; its wrapper/protocol must be checked before the main pilot. Do not load its repository root as though it were the checkpoint directory.

The notebook exports raw outputs and prompts, evidence, exact model revisions, token counts, durations, generation attempts, a conservative reference-proof attribution proxy, and a blank blinded human audit sheet. Reference matches and valid citation IDs are not general grounding judgments. GPU compatibility and reader quality remain untested until Kaggle runs.

## What remains before changing the proposal's method claim

1. Run and inspect the eight-question smoke test; inspect or replace inadequate readers before scaling.
2. Complete the 100-question discovery pilot with strong learned utility/set-aware baselines and reliable independent support checks. Identify a stable residual failure and quantify its prevalence, including no-change/length/order controls.
3. Design a precise modification for that failure, compare literature at the mechanism level, and lock the falsifying comparison before confirmation. Keep data acquisition and objective changes separable.
4. Train on separate training questions; compare at the same backbone, supervision expenditure and evidence budget. Evaluate the identical selected evidence with a held-out reader. Report supported coverage, attributed precision, contradiction, latency and cost, with question-level uncertainty.
5. Update the revised proposal with the actual failure and measured remedy, or report that no verified novel improvement was found. Do not insert a speculative improvement as an experimental result.

The original submitted PDF and historical notes remain unchanged. The 15 October proposed revision remains an unapproved candidate, not an established method. No new reader generation, selector training or paid operation has yet run in this investigation.
