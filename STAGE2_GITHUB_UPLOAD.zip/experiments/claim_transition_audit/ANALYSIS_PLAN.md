# Claim-transition candidate: limited audit plan

Recorded 18 October 2026, before executing this audit's numerical checks. Larger model training/generation remains deferred. No model weights, paid services or new answer generation will be used.

## Questions

1. What changes mathematically when gain G and loss L are predicted separately rather than predicting G-lambda*L?
2. Can the already downloaded monotone CRUX answerability annotations test generated-answer claim loss at all?
3. Are public cached outputs available for the same reader/question with nested evidence sets, permitting a real descriptive insertion analysis without inference?

## Fixed numerical checks

- Exhaustively enumerate pairs of binary claim-presence vectors over eight claims (65,536 before/after pairs). Verify net change G-L, turnover G+L, weighted-utility decomposition and squared two-head-loss rotation. Include zero-change, pure gains, pure losses and simultaneous gains/losses.
- Seed 20261018. Fit matched ridge predictors for G and L versus a direct scalar G-lambda*L predictor using identical feature matrices, regularization and train/test splits. Check lambda in {0,1,2,4}, ridge penalties {0.1,1,10}. This is an algebra/implementation control with simulated targets, not a RAG performance experiment.
- Construct a finite synthetic insertion example showing that an extra penalty for losing a currently correct claim can prefer a smaller final claim set than net coverage. Report it explicitly as a counterexample to a universal improvement claim, not observed benchmark harm.
- Reuse the 50 DUC04 and the fixed 100 Multi-News topic IDs selected in the earlier CRUX audit. For each topic inspect every singleton and every single-candidate insertion after it, with at most 50 natural chunks retained by doc-ID order and answerability threshold >=3 (>=4 sensitivity). Use OR coverage. Count losses and simultaneous gain/loss. These values are negative controls: zero losses cannot refute non-monotonic generated answers.

## Public-output eligibility (before outcomes)

Investigate official RAGChecker, CRUX and ALCE releases. An insertion diagnostic requires same question, same frozen reader/configuration, a shared reference-claim representation, and evidence sets differing by one passage; other changes must be held fixed. Non-nested sets, different readers, or answer-revision prompts do not qualify as controlled insertion evidence. Do not silently relax these criteria to manufacture a result. Document unavailable/ineligible data.

If eligible data are found, save an explicit amendment specifying files, splits, canonical claim matching, evidence support checks, controls and uncertainty before calculating claim-transition outcomes. Public outputs without adequate claim truth/support annotations can support only a clearly named proxy. No end-to-end learned-selector or cross-reader-transfer conclusion follows from this audit.

## Decision limits

### Prospective amendment before numerical execution

The literature review identified repeat-aware answer churn as an important control. Add a simulation of 100,000 pairs of ten binary claim-presence indicators with probability 0.8 each. Both arms have identical distributions and no evidence intervention. Compare independent pairing with identical-draw pairing, recording mean G/L, net change, any-loss and simultaneous-gain/loss rates. Verify against the analytic independent-draw expectations. This tests a labeling confound in a specified simulation; it measures no LLM failure rate. Fixed seed 20261018. The stochastic pairing convention must be distinguished from deterministic decoding, for which this ambiguity need not apply.

Distinguish an exact prior-art match, crowded ingredients, and an empirical contribution. Mathematical equivalence of matched linear predictors does not imply equivalence of every neural architecture, nonlinear loss, capacity-limited model or risk constraint. Absence of matched cached outputs is a data limitation, not evidence of method ineffectiveness or novelty. Preserve all historical sources and proposals.
