"""Limited CPU audit; numerical controls and cached annotations, no LLM calls."""
from __future__ import annotations

import collections
import datetime
import hashlib
import json
import platform
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[1]
PREVIOUS = PROJECT / "experiments/novelty_audit"
SEED = 20261018


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def transitions(before, after):
    before, after = np.asarray(before, dtype=bool), np.asarray(after, dtype=bool)
    return ((~before & after).sum(axis=-1), (before & ~after).sum(axis=-1))


def exact_checks():
    vectors = ((np.arange(256)[:, None] >> np.arange(8)) & 1).astype(bool)
    before = np.repeat(vectors, 256, axis=0)
    after = np.tile(vectors, (256, 1))
    gain, loss = transitions(before, after)
    delta = after.sum(axis=1).astype(int) - before.sum(axis=1)
    turnover = np.count_nonzero(before != after, axis=1)
    assert np.array_equal(delta, gain - loss)
    assert np.array_equal(turnover, gain + loss)
    weighted_errors = {}
    for lam in [0, 1, 2, 4]:
        direct = gain - lam * loss
        rotated = ((1 + lam) / 2) * delta - ((lam - 1) / 2) * turnover
        error = float(np.max(np.abs(direct - rotated)))
        assert error < 1e-12
        weighted_errors[str(lam)] = error
    rng = np.random.default_rng(SEED)
    residuals = rng.normal(size=(10000, 2))
    left = np.sum(residuals**2, axis=1)
    right = 0.5 * ((residuals[:, 0] - residuals[:, 1])**2
                   + (residuals[:, 0] + residuals[:, 1])**2)
    rotation_error = float(np.max(np.abs(left - right)))
    assert rotation_error < 1e-10
    examples = [([1, 0], [1, 1], (1, 0)),
                ([1, 1], [1, 0], (0, 1)),
                ([1, 0], [0, 1], (1, 1)),
                ([0, 0], [0, 0], (0, 0))]
    for a, b, expected in examples:
        assert tuple(map(int, transitions(a, b))) == expected
    return {"before_after_pairs": len(gain),
            "pairs_with_simultaneous_gain_loss": int(np.count_nonzero((gain > 0) & (loss > 0))),
            "net_identity_max_error": int(np.max(np.abs(delta - (gain - loss)))),
            "weighted_identity_max_errors": weighted_errors,
            "squared_loss_rotation_max_error": rotation_error,
            "known_cases_passed": len(examples),
            "interpretation": "Algebra checks, not a benchmark or new theorem."}


def ridge_control():
    rng = np.random.default_rng(SEED)
    x = rng.normal(size=(1500, 24))
    x = np.column_stack([np.ones(len(x)), x])
    logits = np.clip(x @ rng.normal(scale=0.15, size=(25, 2)), -4, 4)
    targets = rng.binomial(8, 1 / (1 + np.exp(-logits)))
    train, test = x[:1000], x[1000:]
    y = targets[:1000].astype(float)
    records = []
    for penalty in [0.1, 1.0, 10.0]:
        gram = train.T @ train + penalty * np.eye(train.shape[1])
        joint = np.linalg.solve(gram, train.T @ y)
        dual_predictions = test @ joint
        for lam in [0, 1, 2, 4]:
            contrast = np.array([1.0, -float(lam)])
            scalar = np.linalg.solve(gram, train.T @ (y @ contrast))
            combined = dual_predictions @ contrast
            direct = test @ scalar
            error = float(np.max(np.abs(combined - direct)))
            assert np.allclose(combined, direct, rtol=1e-11, atol=1e-11)
            top_dual = np.argmax(combined.reshape(-1, 10), axis=1)
            top_scalar = np.argmax(direct.reshape(-1, 10), axis=1)
            mismatches = int(np.count_nonzero(top_dual != top_scalar))
            assert mismatches == 0
            records.append({"ridge_penalty": penalty, "lambda": lam,
                            "prediction_max_absolute_difference": error,
                            "groups_of_10": len(top_dual), "top1_disagreements": mismatches})
    return {"data": "Simulated binary-count targets, not RAG labels",
            "training_rows": len(train), "test_rows": len(test),
            "feature_columns_including_intercept": train.shape[1], "settings": records}


def no_intervention_control():
    rng = np.random.default_rng(SEED)
    before = rng.random((100000, 10)) < 0.8
    after = rng.random((100000, 10)) < 0.8
    gain, loss = transitions(before, after)
    same_gain, same_loss = transitions(before, before)
    p, m = 0.8, 10
    expected_g = m * p * (1 - p)
    expected_any = 1 - (1 - p * (1 - p))**m
    expected_mixed = 1 - 2 * (1 - p * (1 - p))**m + (p*p + (1-p)**2)**m
    out = {"data": "Simulation with identical before/after distributions and no evidence intervention",
           "pairs": len(before), "claims_per_answer": m, "claim_presence_probability": p,
           "independent_pairing": {"mean_gain": float(gain.mean()), "mean_loss": float(loss.mean()),
                                   "mean_net": float((gain - loss).mean()),
                                   "any_loss_rate": float(np.mean(loss > 0)),
                                   "simultaneous_gain_loss_rate": float(np.mean((gain > 0) & (loss > 0)))},
           "analytic_independent_expectations": {"mean_gain": expected_g, "mean_loss": expected_g,
                                                 "mean_net": 0.0, "any_loss_rate": expected_any,
                                                 "simultaneous_gain_loss_rate": expected_mixed},
           "identical_draw_pairing": {"mean_gain": float(same_gain.mean()),
                                      "mean_loss": float(same_loss.mean())},
           "interpretation": "Positive gross transitions can be sampling turnover; no measured LLM rates."}
    assert abs(out["independent_pairing"]["mean_gain"] - expected_g) < 0.02
    assert abs(out["independent_pairing"]["mean_loss"] - expected_g) < 0.02
    assert abs(out["independent_pairing"]["simultaneous_gain_loss_rate"] - expected_mixed) < 0.01
    return out


def counterexamples():
    # Both are exact, explicitly constructed examples, not generated answers.
    initial = {"a", "b"}
    finals = {"A": {"b", "c", "d", "e"}, "B": {"a", "b", "f"}}
    table = {}
    for name, after in finals.items():
        g, l = len(after - initial), len(initial - after)
        table[name] = {"gain": g, "loss": l, "final_count": len(after),
                       "net_count_gain": g-l, "gain_minus_3_loss": g-3*l}
    assert max(table, key=lambda a: table[a]["final_count"]) == "A"
    assert max(table, key=lambda a: table[a]["gain_minus_3_loss"]) == "B"
    claims = {frozenset(): set(), frozenset({"a"}): {"x"},
              frozenset({"b"}): {"y"}, frozenset({"a", "b"}): {"y"}}
    paths = []
    for order in [("a", "b"), ("b", "a")]:
        selected, total_g, total_l = frozenset(), 0, 0
        for d in order:
            next_set = selected | {d}
            total_g += len(claims[next_set] - claims[selected])
            total_l += len(claims[selected] - claims[next_set])
            selected = next_set
        paths.append({"passage_order": list(order), "final_correct_claims": sorted(claims[selected]),
                      "sum_gain": total_g, "sum_loss": total_l,
                      "score_lambda1": total_g-total_l, "score_lambda2": total_g-2*total_l})
    assert paths[0]["score_lambda1"] == paths[1]["score_lambda1"]
    assert paths[0]["score_lambda2"] != paths[1]["score_lambda2"]
    return {"status": "Constructed counterexamples, not benchmark measurements",
            "risk_preference_can_trade_coverage": table,
            "nonunit_loss_penalty_can_be_path_dependent": paths}


def load_ratings(path):
    grouped = collections.defaultdict(dict)
    for line in path.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if "#" in row["docid"]:
            assert row["docid"] not in grouped[row["id"]]
            grouped[row["id"]][row["docid"]] = row["rating"]
    return grouped


def crux_negative_control():
    old = json.loads((PREVIOUS / "results/diagnostic_results.json").read_text())
    selected = old["selected_topics"]
    assert len(selected) == 150 and all(x["eligible"] for x in selected)
    data = PREVIOUS / "data/crux"
    paths = {"duc04": data / "crux-mds-duc04/judge/ratings.Llama-3.1-70B-Instruct.0-1.jsonl",
             "multi_news": data / "crux-mds-multi_news/judge/ratings.Llama-3.1-70B-Instruct.0-1.jsonl"}
    manifest = json.loads((data / "source_manifest.json").read_text())
    for source in manifest["files"]:
        relative = Path(source["path"])
        assert sha(PROJECT / relative) == source["sha256"]
    ratings = {name: load_ratings(path) for name, path in paths.items()}
    per_topic = []
    summaries = []
    for threshold in [3, 4]:
        for dataset in paths:
            rows = []
            for entry in selected:
                if entry["dataset"] != dataset:
                    continue
                docs = ratings[dataset][entry["id"]]
                ids = sorted(docs)[:50]
                matrix = np.array([docs[d] for d in ids]) >= threshold
                # Ordered singleton-context / distinct-candidate insertions.
                after = matrix[:, None, :] | matrix[None, :, :]
                before = np.broadcast_to(matrix[:, None, :], after.shape)
                gain, loss = transitions(before, after)
                mask = ~np.eye(len(ids), dtype=bool)
                g, l = gain[mask], loss[mask]
                assert np.all(l == 0)
                row = {"dataset": dataset, "id": entry["id"], "threshold": threshold,
                       "chunks": len(ids), "subquestions": matrix.shape[1],
                       "insertions": len(g), "positive_gain": int(np.count_nonzero(g > 0)),
                       "any_loss": int(np.count_nonzero(l > 0)),
                       "simultaneous_gain_loss": int(np.count_nonzero((g > 0) & (l > 0))),
                       "sum_gain": int(g.sum())}
                rows.append(row); per_topic.append(row)
            summaries.append({"dataset": dataset, "threshold": threshold, "topics": len(rows),
                              **{k: sum(r[k] for r in rows) for k in
                                 ["insertions", "positive_gain", "any_loss", "simultaneous_gain_loss", "sum_gain"]}})
    return {"data": "Released cached answerability OR coverage, not generated-answer claims",
            "summary": summaries, "source_revision": manifest["revision"],
            "source_hashes": {str(p.relative_to(PROJECT)): sha(p) for p in paths.values()},
            "previous_selected_topics_sha256": sha(PREVIOUS / "results/diagnostic_results.json"),
            "interpretation": "Loss is structurally zero under monotone OR coverage. This data cannot test the candidate failure."}, per_topic


def cached_output_eligibility():
    metadata = ROOT / "public_metadata"
    cached = json.loads((metadata / "ragchecker_cached.json").read_text())
    assert isinstance(cached, list) and len(cached) == 280
    same_named = sum(r["model1"]["model_name"] == r["model2"]["model_name"] for r in cached)
    has_context = sum(any("context" in k or "retrieved" in k for k in r) for r in cached)
    has_claim_labels = sum(any("claims" in k for k in r) for r in cached)
    trees = {n: json.loads((metadata / f"{n}_tree.json").read_text()) for n in ["alce", "ragchecker", "crux"]}
    result = {"scope": "Inspected pinned repository trees, linked release documentation and one cached metric file; not all public data worldwide",
              "ragchecker": {"comparison_rows": len(cached), "same_model_name_pairs": same_named,
                             "rows_with_top_level_context_fields": has_context,
                             "rows_with_top_level_claim_fields": has_claim_labels,
                             "eligible_controlled_insertion_rows_in_inspected_file": 0,
                             "reason": "Paired system responses and aggregate metrics; no insertion-design or per-claim truth/support records in this file."},
              "alce": {"reason": "Inspected tree has generation configs and human-evaluation summaries; no controlled one-passage insertion output corpus located. README describes running models to create result files. Human utility scores are aggregate 1-5 labels."},
              "crux": {"reason": "Inspected run release contains retrieval rankings/coverage metrics; downloaded ratings are singleton answerability, not paired answer generations."},
              "pinned_tree_shas": {n: t["sha"] for n, t in trees.items()}}
    return result


def main():
    results = {"status": "limited_numerical_and_cached_annotation_audit_not_selector_validation",
               "run_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "python": platform.python_version(), "numpy": np.__version__, "seed": SEED,
               "script_sha256": sha(__file__), "plan_sha256": sha(ROOT / "ANALYSIS_PLAN.md"),
               "exact_checks": exact_checks(), "matched_ridge": ridge_control(),
               "no_intervention_simulation": no_intervention_control(),
               "constructed_counterexamples": counterexamples(),
               "cached_output_eligibility": cached_output_eligibility()}
    negative, rows = crux_negative_control()
    results["crux_negative_control"] = negative
    original_inventory = json.loads((PROJECT / "project_knowledge/source_inventory.json").read_text())
    checked = []
    for source in original_inventory["sources"] + original_inventory.get("additional_sources", []):
        path = PROJECT / source["path"]
        assert sha(path) == source["sha256"]
        checked.append(source["path"])
    results["original_source_hashes_verified"] = checked
    out = ROOT / "results"; out.mkdir(exist_ok=True)
    (out / "audit_results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    (out / "crux_per_topic.jsonl").write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")
    summary = {"exact_checks": results["exact_checks"],
               "ridge_max_prediction_difference": max(r["prediction_max_absolute_difference"] for r in results["matched_ridge"]["settings"]),
               "ridge_top1_disagreements": sum(r["top1_disagreements"] for r in results["matched_ridge"]["settings"]),
               "simulation": results["no_intervention_simulation"],
               "crux": negative["summary"], "original_sources_verified": len(checked)}
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
